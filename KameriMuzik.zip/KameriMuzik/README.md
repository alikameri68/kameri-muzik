# Kamerî Müzik

Kamerî Kitaplık'ın tasarım dilini taşıyan, tamamen native bir müzik ve video oynatıcı.
WebView yok: arayüz Jetpack Compose, oynatma Media3 (ExoPlayer) ile yazıldı.

## Ne var

- Cihazdaki müzik ve videoları tarar (Müzik, Video, Beğeniler sekmeleri, arama)
- Arka planda çalma, bildirim ve kilit ekranı kontrolleri, kulaklık tuşları
- Kulaklık çıkınca duraklatma, başka uygulama ses alınca ses odağı yönetimi
- Mini oynatıcıdan tam ekrana parmağı takip eden, kesintisiz geçiş
- Kapaktan alınıp uygulama paletine çekilen ortam ışığı
- Dokunsal geri bildirimli ilerleme çubuğu
- Video: çift dokunuşla 10 saniye sarma, tam ekran, küçük pencere (PiP),
  görüntüyü kapatıp yalnız sesle devam etme
- Karıştırma ve tekrar modları, beğeniler
- Gece (varsayılan), Siyah ve Krem temaları

## APK nasıl alınır (bilgisayarsız)

1. GitHub'da boş bir depo aç, bu klasörün içindekileri `main` dalına yükle.
2. Depoda **Actions** sekmesine gir; "APK" iş akışı kendiliğinden çalışır.
3. İş bitince sayfanın altındaki **Artifacts** bölümünden `KameriMuzik-debug` dosyasını indir,
   içindeki APK'yı kur.

Her derleme farklı bir hata ayıklama anahtarıyla imzalanır; bu yüzden yeni APK'yı
kurmadan önce eskisini kaldırman gerekebilir. Kalıcı çözüm, depoya sabit bir imza
anahtarı eklemektir.

## Yapı

```
app/src/main/java/com/kameri/muzik/
  App.kt                 Görsel yükleyici (video karesi desteğiyle)
  MainActivity.kt        Tek ekran, küçük pencere geçişi
  MainViewModel.kt       Kitaplık, beğeniler, tema
  data/                  MediaStore taraması, tercih kaydı
  playback/              Arka plan oynatma servisi
  player/                Arayüzün servise bağlantısı
  ui/                    Kitaplık, oynatıcı, tam ekran video, ortak parçalar
  ui/theme/              Renkler, yazı tipleri, hareket eğrileri
```

## Yazı tipleri

Literata ve Plus Jakarta Sans, SIL Open Font License 1.1 ile dağıtılır
(`licenses/` klasörüne bakın).
