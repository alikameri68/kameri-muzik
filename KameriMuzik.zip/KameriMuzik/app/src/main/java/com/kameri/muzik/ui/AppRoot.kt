package com.kameri.muzik.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import com.kameri.muzik.MainViewModel
import com.kameri.muzik.PipState
import com.kameri.muzik.ui.theme.KType
import com.kameri.muzik.ui.theme.LocalKameriColors
import com.kameri.muzik.ui.theme.Motion
import kotlinx.coroutines.launch

private fun mediaPermissions(): Array<String> =
    if (Build.VERSION.SDK_INT >= 33) {
        arrayOf(
            Manifest.permission.READ_MEDIA_AUDIO,
            Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.POST_NOTIFICATIONS,
        )
    } else {
        arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

private fun Context.granted(permission: String): Boolean =
    ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

private fun Context.canReadMedia(): Boolean =
    if (Build.VERSION.SDK_INT >= 33) {
        granted(Manifest.permission.READ_MEDIA_AUDIO) || granted(Manifest.permission.READ_MEDIA_VIDEO)
    } else {
        granted(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

@Composable
fun AppRoot(vm: MainViewModel) {
    val colors = LocalKameriColors.current
    val context = LocalContext.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()

    val expansion = remember { Animatable(0f) }
    val expanded by remember { derivedStateOf { expansion.value > 0.5f } }
    var fullscreen by rememberSaveable { mutableStateOf(false) }
    val inPip = PipState.inPip

    var canRead by remember { mutableStateOf(context.canReadMedia()) }
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        canRead = context.canReadMedia()
    }
    LaunchedEffect(canRead) {
        if (canRead) vm.refresh()
    }

    val current = vm.current
    val videoActive = current?.isVideo == true && !vm.audioOnly
    val videoLayer = videoActive && (fullscreen || inPip)

    LaunchedEffect(videoActive) {
        if (!videoActive) fullscreen = false
    }
    LaunchedEffect(current == null) {
        if (current == null) expansion.snapTo(0f)
    }

    SideEffect {
        PipState.eligible = videoActive && vm.player.isPlaying
        PipState.aspect = vm.player.videoAspect

        // Tam ekran oynatıcı her zaman koyu olduğundan durum çubuğu ona uyar.
        context.findActivity()?.window?.let { window ->
            val lightBars = !colors.isDark && !expanded
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = lightBars
                isAppearanceLightNavigationBars = lightBars
            }
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(colors.bg)
    ) {
        if (canRead) {
            LibraryScreen(
                vm = vm,
                onPlay = { list, index ->
                    vm.play(list, index)
                    if (list[index].isVideo) {
                        scope.launch { expansion.animateTo(1f, Motion.spring()) }
                    }
                },
            )
        } else {
            PermissionScreen(onGrant = { launcher.launch(mediaPermissions()) })
        }

        PlayerSheet(
            vm = vm,
            expansion = expansion,
            showVideoHere = !videoLayer,
            onFullscreen = { fullscreen = true },
        )

        if (videoLayer) {
            FullscreenVideo(
                vm = vm,
                inPip = inPip,
                immersive = fullscreen && !inPip,
                onExit = { fullscreen = false },
            )
        }
    }

    BackHandler(enabled = expanded && !videoLayer) {
        scope.launch { expansion.animateTo(0f, Motion.spring()) }
    }
}

@Composable
private fun PermissionScreen(onGrant: () -> Unit) {
    val c = LocalKameriColors.current
    Column(
        Modifier
            .fillMaxSize()
            .padding(36.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Rosette(color = c.gold, modifier = Modifier.size(88.dp), stroke = 1.8.dp)
        Spacer(Modifier.height(28.dp))
        Text("Kamerî Müzik", style = KType.Display, color = c.text)
        Spacer(Modifier.height(10.dp))
        Text(
            "Cihazındaki müzik ve videoları gösterebilmek için kitaplığına erişim izni gerekiyor. " +
                "Dosyaların cihazından çıkmaz.",
            style = KType.Subtitle,
            color = c.textSecondary,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(28.dp))
        Text(
            "Kitaplığıma eriş",
            style = KType.Label,
            color = c.bg,
            modifier = Modifier
                .clip(CircleShape)
                .background(c.gold)
                .clickable(onClick = onGrant)
                .padding(horizontal = 26.dp, vertical = 14.dp),
        )
    }
}
