package com.kameri.muzik.ui.theme

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.spring as composeSpring
import androidx.compose.animation.core.tween
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.kameri.muzik.R

enum class ThemeMode(val label: String) {
    NIGHT("Gece"),
    AMOLED("Siyah"),
    CREAM("Krem"),
}

@Immutable
data class KameriColors(
    val bg: Color,
    val card: Color,
    val subtle: Color,
    val muted: Color,
    val border: Color,
    val text: Color,
    val textSecondary: Color,
    val accent: Color,
    val gold: Color,
    val isDark: Boolean,
)

// Renkler Kamerî Kitaplık'ın temalarından alınmıştır.
val NightColors = KameriColors(
    bg = Color(0xFF0F1312),
    card = Color(0xFF1A211F),
    subtle = Color(0xFF1F2825),
    muted = Color(0xFF26302C),
    border = Color(0xFF2E3A35),
    text = Color(0xFFE6E4DF),
    textSecondary = Color(0xFF9AA8A2),
    accent = Color(0xFF3DBA94),
    gold = Color(0xFFE8C547),
    isDark = true,
)

val AmoledColors = KameriColors(
    bg = Color(0xFF000000),
    card = Color(0xFF0B0B0B),
    subtle = Color(0xFF111111),
    muted = Color(0xFF191919),
    border = Color(0xFF242424),
    text = Color(0xFFD6D4CF),
    textSecondary = Color(0xFF8B8D8A),
    accent = Color(0xFF45B892),
    gold = Color(0xFFE8C547),
    isDark = true,
)

val CreamColors = KameriColors(
    bg = Color(0xFFF3EEE4),
    card = Color(0xFFFFFCF7),
    subtle = Color(0xFFFAF6EE),
    muted = Color(0xFFEBE3D4),
    border = Color(0xFFDDD2BF),
    text = Color(0xFF1F1C18),
    textSecondary = Color(0xFF5A5348),
    accent = Color(0xFF1B4D3E),
    gold = Color(0xFFB8922E),
    isDark = false,
)

val LocalKameriColors = staticCompositionLocalOf { NightColors }

@OptIn(ExperimentalTextApi::class)
private fun variable(resId: Int, weight: Int): Font = Font(
    resId = resId,
    weight = FontWeight(weight),
    variationSettings = FontVariation.Settings(FontVariation.weight(weight)),
)

val Literata = FontFamily(
    variable(R.font.literata, 400),
    variable(R.font.literata, 500),
    variable(R.font.literata, 600),
)

val Jakarta = FontFamily(
    variable(R.font.plus_jakarta_sans, 400),
    variable(R.font.plus_jakarta_sans, 500),
    variable(R.font.plus_jakarta_sans, 600),
    variable(R.font.plus_jakarta_sans, 700),
)

/** Başlıklar serif (Literata), kontroller sans (Plus Jakarta). */
object KType {
    val Display = TextStyle(
        fontFamily = Literata, fontWeight = FontWeight(600), fontSize = 34.sp, lineHeight = 40.sp,
    )
    val Title = TextStyle(
        fontFamily = Literata, fontWeight = FontWeight(600), fontSize = 24.sp, lineHeight = 30.sp,
    )
    val Subtitle = TextStyle(
        fontFamily = Jakarta, fontWeight = FontWeight(500), fontSize = 15.sp, lineHeight = 20.sp,
    )
    val RowTitle = TextStyle(
        fontFamily = Jakarta, fontWeight = FontWeight(600), fontSize = 15.sp, lineHeight = 20.sp,
    )
    val Body = TextStyle(
        fontFamily = Jakarta, fontWeight = FontWeight(400), fontSize = 13.sp, lineHeight = 18.sp,
    )
    val Label = TextStyle(
        fontFamily = Jakarta, fontWeight = FontWeight(600), fontSize = 13.sp, lineHeight = 18.sp,
    )
    val Caps = TextStyle(
        fontFamily = Jakarta, fontWeight = FontWeight(700), fontSize = 11.sp, letterSpacing = 2.6.sp,
    )
    val Time = TextStyle(
        fontFamily = Jakarta, fontWeight = FontWeight(500), fontSize = 12.sp,
        fontFeatureSettings = "tnum",
    )
}

/** Bütün uygulamada yalnızca üç hareket eğrisi kullanılır: giriş, çıkış, yay. */
object Motion {
    val Enter = CubicBezierEasing(0.16f, 1f, 0.3f, 1f)
    val Exit = CubicBezierEasing(0.4f, 0f, 1f, 1f)

    fun <T> spring(): FiniteAnimationSpec<T> =
        composeSpring(dampingRatio = 0.82f, stiffness = 380f)
    fun <T> enter(ms: Int = 320): FiniteAnimationSpec<T> = tween(ms, easing = Enter)
    fun <T> exit(ms: Int = 200): FiniteAnimationSpec<T> = tween(ms, easing = Exit)
}

@Composable
fun KameriTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val colors = when (mode) {
        ThemeMode.NIGHT -> NightColors
        ThemeMode.AMOLED -> AmoledColors
        ThemeMode.CREAM -> CreamColors
    }
    val scheme = if (colors.isDark) {
        darkColorScheme(
            primary = colors.gold,
            secondary = colors.accent,
            background = colors.bg,
            surface = colors.card,
            onBackground = colors.text,
            onSurface = colors.text,
        )
    } else {
        lightColorScheme(
            primary = colors.accent,
            secondary = colors.gold,
            background = colors.bg,
            surface = colors.card,
            onBackground = colors.text,
            onSurface = colors.text,
        )
    }
    CompositionLocalProvider(LocalKameriColors provides colors) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
