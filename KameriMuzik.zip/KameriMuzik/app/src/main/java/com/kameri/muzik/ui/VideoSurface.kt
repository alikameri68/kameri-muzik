package com.kameri.muzik.ui

import android.view.LayoutInflater
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Player
import androidx.media3.ui.PlayerView
import com.kameri.muzik.R

/**
 * Videonun çizildiği yüzey. TextureView kullanılır ki oynatıcı açılıp
 * kapanırken görüntü de köşeleri yuvarlanarak akıcı biçimde hareket etsin.
 */
@Composable
fun VideoSurface(player: Player?, modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { context ->
            LayoutInflater.from(context).inflate(R.layout.video_texture, null) as PlayerView
        },
        update = { view -> view.player = player },
        onRelease = { view -> view.player = null },
    )
}
