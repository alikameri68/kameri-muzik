package com.kameri.muzik.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableLongState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.lerp
import com.kameri.muzik.data.formatTime
import com.kameri.muzik.player.PlayerConnection
import com.kameri.muzik.ui.theme.KType
import com.kameri.muzik.ui.theme.Motion
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

/** Oynatma konumunu düzenli aralıkla okuyup tek bir durumda tutar. */
@Composable
fun rememberPosition(player: PlayerConnection): MutableLongState {
    val state = remember { mutableLongStateOf(0L) }
    LaunchedEffect(player.controller, player.isPlaying, player.currentKey) {
        while (isActive) {
            state.longValue = player.position
            delay(if (player.isPlaying) 250L else 800L)
        }
    }
    return state
}

/**
 * İlerleme çubuğu. Sürüklerken kalınlaşır ve her yüzde beşte hafif bir
 * titreşim verir; sarma parmak kalkınca uygulanır.
 */
@Composable
fun SeekBar(
    positionMs: Long,
    durationMs: Long,
    onSeek: (Long) -> Unit,
    active: Color,
    inactive: Color,
    modifier: Modifier = Modifier,
) {
    val haptic = LocalHapticFeedback.current
    val currentOnSeek by rememberUpdatedState(onSeek)
    var dragging by remember { mutableStateOf(false) }
    var dragFraction by remember { mutableFloatStateOf(0f) }
    var lastTick by remember { mutableIntStateOf(-1) }

    val real = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
    val shown = if (dragging) dragFraction else real
    val grow by animateFloatAsState(if (dragging) 1f else 0f, Motion.spring(), label = "seekGrow")

    Canvas(
        modifier
            .fillMaxWidth()
            .height(28.dp)
            .pointerInput(durationMs) {
                if (durationMs <= 0) return@pointerInput
                detectTapGestures { o ->
                    val fraction = (o.x / size.width).coerceIn(0f, 1f)
                    currentOnSeek((fraction * durationMs).toLong())
                }
            }
            .pointerInput(durationMs) {
                if (durationMs <= 0) return@pointerInput
                detectHorizontalDragGestures(
                    onDragStart = { o ->
                        dragFraction = (o.x / size.width).coerceIn(0f, 1f)
                        dragging = true
                    },
                    onDragEnd = {
                        dragging = false
                        currentOnSeek((dragFraction * durationMs).toLong())
                    },
                    onDragCancel = { dragging = false },
                ) { change, amount ->
                    change.consume()
                    dragFraction = (dragFraction + amount / size.width).coerceIn(0f, 1f)
                    val tick = (dragFraction * 20f).toInt()
                    if (tick != lastTick) {
                        lastTick = tick
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    }
                }
            }
    ) {
        val cy = size.height / 2f
        val h = lerp(3.dp.toPx(), 6.dp.toPx(), grow)
        val radius = CornerRadius(h / 2f, h / 2f)
        drawRoundRect(
            color = inactive,
            topLeft = Offset(0f, cy - h / 2f),
            size = Size(size.width, h),
            cornerRadius = radius,
        )
        drawRoundRect(
            color = active,
            topLeft = Offset(0f, cy - h / 2f),
            size = Size(size.width * shown, h),
            cornerRadius = radius,
        )
        drawCircle(
            color = active,
            radius = lerp(5.dp.toPx(), 9.dp.toPx(), grow),
            center = Offset(size.width * shown, cy),
        )
    }
}

/** İlerleme çubuğu ile altındaki geçen ve toplam süre. */
@Composable
fun PlayerSeek(
    player: PlayerConnection,
    position: MutableLongState,
    fallbackDurationMs: Long,
    active: Color,
    inactive: Color,
    textColor: Color,
    modifier: Modifier = Modifier,
) {
    val duration = if (player.durationMs > 0) player.durationMs else fallbackDurationMs
    Column(modifier) {
        SeekBar(
            positionMs = position.longValue,
            durationMs = duration,
            onSeek = { ms ->
                position.longValue = ms
                player.seekTo(ms)
            },
            active = active,
            inactive = inactive,
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(position.longValue), style = KType.Time, color = textColor)
            Text(formatTime(duration), style = KType.Time, color = textColor)
        }
    }
}
