package com.kameri.muzik.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PictureInPictureAlt
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableLongState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.lerp
import androidx.media3.common.Player
import com.kameri.muzik.MainActivity
import com.kameri.muzik.MainViewModel
import com.kameri.muzik.data.Track
import com.kameri.muzik.player.PlayerConnection
import com.kameri.muzik.ui.theme.KType
import com.kameri.muzik.ui.theme.LocalKameriColors
import com.kameri.muzik.ui.theme.Motion
import kotlinx.coroutines.launch
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Mini oynatıcı ile tam ekran oynatıcı tek bir katmandır. [expansion] 0 iken
 * altta ince bir çubuk, 1 iken tam ekrandır; aradaki her değer parmağı takip
 * eder, kapak da küçük halinden büyük haline kesintisiz taşınır.
 */
@Composable
fun PlayerSheet(
    vm: MainViewModel,
    expansion: Animatable<Float, AnimationVector1D>,
    showVideoHere: Boolean,
    onFullscreen: () -> Unit,
) {
    val track = vm.current ?: return
    val player = vm.player
    val theme = LocalKameriColors.current
    val night = PlayerColors
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    val context = LocalContext.current
    val ambient = rememberAmbientColor(track)
    val position = rememberPosition(player)

    val navBottomPx = WindowInsets.navigationBars.getBottom(density).toFloat()
    val statusTopPx = WindowInsets.statusBars.getTop(density).toFloat()
    val showVideo = track.isVideo && !vm.audioOnly
    val artScale by animateFloatAsState(
        if (player.isPlaying || showVideo) 1f else 0.92f, Motion.spring(), label = "artScale",
    )

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val fullH = constraints.maxHeight.toFloat()
        val fullW = constraints.maxWidth.toFloat()
        fun px(dp: Int): Float = with(density) { dp.dp.toPx() }

        val miniH = px(64)
        val margin = px(10)
        val collapsedY = (fullH - miniH - navBottomPx - margin).coerceAtLeast(1f)

        val f = expansion.value
        val side = lerp(margin, 0f, f)
        val width = fullW - 2f * side
        val shape = RoundedCornerShape(lerp(20f, 0f, f).dp)

        // Kapağın küçük ve büyük hâli arasındaki geometri
        val artArea = min(fullW - px(64), fullH * 0.38f)
        val artTop = statusTopPx + px(56) + px(28)
        val miniW = if (showVideo) px(78) else px(44)
        val miniArtH = px(44)
        val bigW: Float
        val bigH: Float
        if (showVideo) {
            val aspect = player.videoAspect.coerceIn(0.4f, 3f)
            var w = fullW - px(32)
            var h = w / aspect
            if (h > artArea) {
                h = artArea
                w = h * aspect
            }
            bigW = w
            bigH = h
        } else {
            bigW = artArea
            bigH = artArea
        }
        val artW = lerp(miniW, bigW, f)
        val artH = lerp(miniArtH, bigH, f)
        val artX = lerp(px(12), (width - bigW) / 2f, f)
        val artY = lerp(px(10), artTop + (artArea - bigH) / 2f, f)

        val dragState = rememberDraggableState { delta ->
            scope.launch {
                expansion.snapTo((expansion.value - delta / collapsedY).coerceIn(0f, 1f))
            }
        }

        Box(
            Modifier
                .offset { IntOffset(0, lerp(collapsedY, 0f, expansion.value).roundToInt()) }
                .padding(horizontal = with(density) { side.toDp() })
                .fillMaxWidth()
                .height(with(density) { fullH.toDp() })
                .clip(shape)
                .background(lerp(theme.card, night.bg, f))
                .border(1.dp, theme.border.copy(alpha = theme.border.alpha * (1f - f)), shape)
                .draggable(
                    state = dragState,
                    orientation = Orientation.Vertical,
                    onDragStopped = { velocity ->
                        val target = when {
                            velocity < -900f -> 1f
                            velocity > 900f -> 0f
                            expansion.value > 0.5f -> 1f
                            else -> 0f
                        }
                        expansion.animateTo(
                            target, Motion.spring(), initialVelocity = -velocity / collapsedY,
                        )
                    },
                )
        ) {
            // Kapaktan gelen ortam ışığı
            Box(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer { alpha = expansion.value }
                    .background(Brush.verticalGradient(listOf(ambient, night.bg)))
            )

            // Mini oynatıcı
            if (f < 0.6f) {
                val miniAlpha = (1f - f * 3f).coerceIn(0f, 1f)
                Row(
                    Modifier
                        .fillMaxWidth()
                        .height(64.dp)
                        .graphicsLayer { alpha = miniAlpha }
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                        ) { scope.launch { expansion.animateTo(1f, Motion.spring()) } }
                        .padding(
                            start = with(density) { (px(12) + miniW + px(12)).toDp() },
                            end = 4.dp,
                        ),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            track.title,
                            style = KType.RowTitle,
                            color = theme.text,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            track.artist,
                            style = KType.Body,
                            color = theme.textSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    IconButton(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            player.toggle()
                        }
                    ) {
                        Icon(
                            if (player.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = if (player.isPlaying) "Duraklat" else "Oynat",
                            tint = theme.text,
                        )
                    }
                    IconButton(onClick = { player.next() }) {
                        Icon(Icons.Rounded.SkipNext, contentDescription = "Sonraki", tint = theme.text)
                    }
                }
                MiniProgress(
                    position = position,
                    durationMs = if (player.durationMs > 0) player.durationMs else track.durationMs,
                    color = theme.gold,
                    modifier = Modifier
                        .padding(top = 62.dp)
                        .fillMaxWidth()
                        .height(2.dp)
                        .graphicsLayer { alpha = miniAlpha },
                )
            }

            // Tam ekran içerik
            if (f > 0.02f) {
                Column(
                    Modifier
                        .fillMaxSize()
                        .graphicsLayer { alpha = ((expansion.value - 0.3f) / 0.7f).coerceIn(0f, 1f) }
                        .padding(
                            top = with(density) { statusTopPx.toDp() },
                            bottom = with(density) { navBottomPx.toDp() } + 12.dp,
                        )
                ) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .padding(horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        IconButton(
                            onClick = { scope.launch { expansion.animateTo(0f, Motion.spring()) } }
                        ) {
                            Icon(
                                Icons.Rounded.KeyboardArrowDown,
                                contentDescription = "Küçült",
                                tint = night.text,
                                modifier = Modifier.size(30.dp),
                            )
                        }
                        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                            Text("ŞİMDİ ÇALIYOR", style = KType.Caps, color = night.gold)
                        }
                        if (track.isVideo) {
                            IconButton(onClick = { vm.changeAudioOnly(!vm.audioOnly) }) {
                                Icon(
                                    if (vm.audioOnly) Icons.Rounded.Videocam else Icons.Rounded.Headphones,
                                    contentDescription = if (vm.audioOnly) "Videoyu aç" else "Yalnız ses",
                                    tint = night.text,
                                )
                            }
                        } else {
                            Spacer(Modifier.width(48.dp))
                        }
                    }

                    Spacer(Modifier.height(with(density) { (px(28) + artArea + px(20)).toDp() }))

                    Column(
                        Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .padding(horizontal = 28.dp),
                        verticalArrangement = Arrangement.SpaceEvenly,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    track.title,
                                    style = KType.Title,
                                    color = night.text,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    track.artist,
                                    style = KType.Subtitle,
                                    color = night.textSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                            val favorite = track.key in vm.favorites
                            IconButton(
                                onClick = {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    vm.toggleFavorite(track)
                                }
                            ) {
                                Icon(
                                    if (favorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                                    contentDescription = if (favorite) "Beğeniyi kaldır" else "Beğen",
                                    tint = if (favorite) night.gold else night.textSecondary,
                                )
                            }
                        }

                        PlayerSeek(
                            player = player,
                            position = position,
                            fallbackDurationMs = track.durationMs,
                            active = night.gold,
                            inactive = night.text.copy(alpha = 0.16f),
                            textColor = night.textSecondary,
                        )

                        TransportRow(player)

                        if (showVideo) {
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(
                                    12.dp, Alignment.CenterHorizontally,
                                ),
                            ) {
                                PillButton(Icons.Rounded.PictureInPictureAlt, "Küçük pencere") {
                                    (context.findActivity() as? MainActivity)
                                        ?.enterPip(player.videoAspect)
                                }
                                PillButton(Icons.Rounded.Fullscreen, "Tam ekran", onFullscreen)
                            }
                        }
                    }
                }
            }

            // Kapak ya da video: mini ile tam ekran arasında taşınan öğe
            Box(
                Modifier
                    .offset { IntOffset(artX.roundToInt(), artY.roundToInt()) }
                    .size(with(density) { artW.toDp() }, with(density) { artH.toDp() })
                    .graphicsLayer {
                        val s = lerp(1f, artScale, expansion.value)
                        scaleX = s
                        scaleY = s
                    }
                    .clip(RoundedCornerShape(lerp(10f, 20f, f).dp))
                    .background(if (showVideo) Color.Black else night.muted),
                contentAlignment = Alignment.Center,
            ) {
                if (showVideo) {
                    if (showVideoHere) {
                        VideoSurface(player.controller, Modifier.fillMaxSize())
                    }
                    // Çift dokunuş: solda geri, sağda ileri on saniye
                    Box(
                        Modifier
                            .fillMaxSize()
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onTap = {
                                        if (expansion.value < 0.5f) {
                                            scope.launch { expansion.animateTo(1f, Motion.spring()) }
                                        }
                                    },
                                    onDoubleTap = { o ->
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        player.seekBy(if (o.x < size.width / 2f) -10_000L else 10_000L)
                                    },
                                )
                            }
                    )
                } else {
                    ArtworkFill(track)
                }
            }
        }
    }
}

@Composable
private fun ArtworkFill(track: Track) {
    Artwork(track, Modifier.fillMaxSize(), corner = 0.dp)
}

@Composable
private fun MiniProgress(
    position: MutableLongState,
    durationMs: Long,
    color: Color,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier.drawBehind {
            if (durationMs > 0) {
                val fraction = (position.longValue.toFloat() / durationMs).coerceIn(0f, 1f)
                drawRect(color, size = Size(size.width * fraction, size.height))
            }
        }
    )
}

@Composable
fun TransportRow(player: PlayerConnection, modifier: Modifier = Modifier) {
    val night = PlayerColors
    val haptic = LocalHapticFeedback.current
    Row(
        modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = { player.toggleShuffle() }) {
            Icon(
                Icons.Rounded.Shuffle,
                contentDescription = "Karıştır",
                tint = if (player.shuffle) night.gold else night.textSecondary,
            )
        }
        IconButton(onClick = { player.previous() }, modifier = Modifier.size(56.dp)) {
            Icon(
                Icons.Rounded.SkipPrevious,
                contentDescription = "Önceki",
                tint = night.text,
                modifier = Modifier.size(38.dp),
            )
        }

        val interaction = remember { MutableInteractionSource() }
        val pressed by interaction.collectIsPressedAsState()
        val scale by animateFloatAsState(if (pressed) 0.9f else 1f, Motion.spring(), label = "playScale")
        Box(
            Modifier
                .size(72.dp)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                }
                .clip(CircleShape)
                .background(night.gold)
                .clickable(interactionSource = interaction, indication = null) {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    player.toggle()
                },
            contentAlignment = Alignment.Center,
        ) {
            if (player.isBuffering) {
                Rosette(color = night.bg, modifier = Modifier.size(30.dp), stroke = 2.dp, spinning = true)
            } else {
                Icon(
                    if (player.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = if (player.isPlaying) "Duraklat" else "Oynat",
                    tint = night.bg,
                    modifier = Modifier.size(38.dp),
                )
            }
        }

        IconButton(onClick = { player.next() }, modifier = Modifier.size(56.dp)) {
            Icon(
                Icons.Rounded.SkipNext,
                contentDescription = "Sonraki",
                tint = night.text,
                modifier = Modifier.size(38.dp),
            )
        }
        IconButton(onClick = { player.cycleRepeat() }) {
            Icon(
                if (player.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                contentDescription = "Tekrar",
                tint = if (player.repeatMode != Player.REPEAT_MODE_OFF) night.gold else night.textSecondary,
            )
        }
    }
}

@Composable
private fun PillButton(icon: ImageVector, label: String, onClick: () -> Unit) {
    val night = PlayerColors
    Row(
        Modifier
            .clip(CircleShape)
            .background(night.text.copy(alpha = 0.08f))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = night.text, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(label, style = KType.Label, color = night.text)
    }
}
