package com.kameri.muzik.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.Collator
import java.util.Locale

object MediaRepository {

    private val albumArtBase: Uri = Uri.parse("content://media/external/audio/albumart")

    suspend fun load(context: Context): List<Track> = withContext(Dispatchers.IO) {
        val audio = runCatching { queryAudio(context) }.getOrDefault(emptyList())
        val video = runCatching { queryVideo(context) }.getOrDefault(emptyList())
        val collator = Collator.getInstance(Locale("tr"))
        (audio + video).sortedWith { a, b -> collator.compare(a.title, b.title) }
    }

    private fun clean(value: String?, fallback: String): String =
        if (value.isNullOrBlank() || value == MediaStore.UNKNOWN_STRING) fallback else value

    private fun queryAudio(context: Context): List<Track> {
        val out = ArrayList<Track>()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
        )
        context.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection,
            "${MediaStore.Audio.Media.IS_MUSIC} != 0",
            null,
            null,
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val iAlbumId = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val iDuration = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                out += Track(
                    id = id,
                    uri = ContentUris.withAppendedId(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id
                    ),
                    title = clean(c.getString(iTitle), "Adsız parça"),
                    artist = clean(c.getString(iArtist), "Bilinmeyen sanatçı"),
                    album = clean(c.getString(iAlbum), ""),
                    durationMs = c.getLong(iDuration),
                    isVideo = false,
                    artworkUri = ContentUris.withAppendedId(albumArtBase, c.getLong(iAlbumId)),
                )
            }
        }
        return out
    }

    private fun queryVideo(context: Context): List<Track> {
        val out = ArrayList<Track>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
        )
        context.contentResolver.query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            projection,
            null,
            null,
            null,
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val iTitle = c.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
            val iName = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val iDuration = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val uri = ContentUris.withAppendedId(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id
                )
                val name = c.getString(iName)?.substringBeforeLast('.')
                out += Track(
                    id = id,
                    uri = uri,
                    title = clean(c.getString(iTitle), clean(name, "Adsız video")),
                    artist = "Video",
                    album = "",
                    durationMs = c.getLong(iDuration),
                    isVideo = true,
                    artworkUri = uri,
                )
            }
        }
        return out
    }
}
