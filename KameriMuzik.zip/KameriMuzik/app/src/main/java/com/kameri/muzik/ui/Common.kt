package com.kameri.muzik.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.drawable.BitmapDrawable
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.graphics.ColorUtils
import androidx.palette.graphics.Palette
import coil.compose.AsyncImage
import coil.imageLoader
import coil.request.ImageRequest
import com.kameri.muzik.data.Track
import com.kameri.muzik.ui.theme.LocalKameriColors
import com.kameri.muzik.ui.theme.NightColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/**
 * Selçuklu sekiz köşeli yıldızı. Süs olarak değil işlev olarak kullanılır:
 * kapaksız parçanın yer tutucusu, çalan parçanın işareti, yükleme göstergesi.
 */
@Composable
fun Rosette(
    color: Color,
    modifier: Modifier = Modifier,
    stroke: Dp = 1.4.dp,
    spinning: Boolean = false,
) {
    val rotation: State<Float> = if (spinning) {
        rememberInfiniteTransition(label = "rosette").animateFloat(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing)),
            label = "rosetteRotation",
        )
    } else {
        remember { mutableFloatStateOf(0f) }
    }

    Canvas(modifier.graphicsLayer { rotationZ = rotation.value }) {
        val c = center
        val r = size.minDimension / 2f * 0.94f
        val sw = stroke.toPx()

        fun polygon(n: Int, radius: Float, startDeg: Double): Path {
            val path = Path()
            for (i in 0 until n) {
                val a = Math.toRadians(startDeg + i * 360.0 / n)
                val x = c.x + radius * cos(a).toFloat()
                val y = c.y + radius * sin(a).toFloat()
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            return path
        }

        val outline = Stroke(width = sw, join = StrokeJoin.Round)
        drawPath(polygon(4, r, -90.0), color, style = outline)
        drawPath(polygon(4, r, -45.0), color, style = outline)
        drawPath(polygon(8, r * 0.42f, -67.5), color, style = Stroke(sw * 0.8f, join = StrokeJoin.Round))
        drawCircle(color, radius = sw * 1.3f, center = Offset(c.x, c.y))
    }
}

/** Kapak ya da video karesi; yüklenemezse altındaki yıldız görünür kalır. */
@Composable
fun Artwork(track: Track, modifier: Modifier = Modifier, corner: Dp = 12.dp) {
    val c = LocalKameriColors.current
    Box(
        modifier
            .clip(RoundedCornerShape(corner))
            .background(c.muted),
        contentAlignment = Alignment.Center,
    ) {
        Rosette(color = c.gold.copy(alpha = 0.5f), modifier = Modifier.fillMaxSize(0.5f))
        AsyncImage(
            model = track.artworkUri,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
        )
    }
}

private val AmbientFallback = Color(0xFF163F32)

/**
 * Kapağın baskın rengini alır, doygunluğunu kısıp koyulaştırır ve uygulamanın
 * yeşiline doğru çeker; böylece her kapak aynı palete oturur.
 */
@Composable
fun rememberAmbientColor(track: Track?): Color {
    val context = LocalContext.current
    var target by remember { mutableStateOf(AmbientFallback) }

    LaunchedEffect(track?.key) {
        val uri = track?.artworkUri
        target = if (uri == null) {
            AmbientFallback
        } else {
            withContext(Dispatchers.IO) {
                runCatching {
                    val request = ImageRequest.Builder(context)
                        .data(uri)
                        .size(128)
                        .allowHardware(false)
                        .build()
                    val bitmap = (context.imageLoader.execute(request).drawable as? BitmapDrawable)
                        ?.bitmap ?: return@runCatching null
                    val palette = Palette.from(bitmap).generate()
                    val swatch = palette.vibrantSwatch ?: palette.mutedSwatch
                        ?: palette.dominantSwatch ?: return@runCatching null
                    tame(swatch.rgb)
                }.getOrNull()
            } ?: AmbientFallback
        }
    }

    val animated by animateColorAsState(target, tween(900), label = "ambient")
    return animated
}

private fun tame(rgb: Int): Color {
    val hsl = FloatArray(3)
    ColorUtils.colorToHSL(rgb, hsl)
    hsl[1] = min(hsl[1], 0.5f)
    hsl[2] = 0.2f
    return lerp(Color(ColorUtils.HSLToColor(hsl)), AmbientFallback, 0.22f)
}

/** Tam ekran oynatıcı her temada gece renkleriyle çizilir. */
val PlayerColors = NightColors
