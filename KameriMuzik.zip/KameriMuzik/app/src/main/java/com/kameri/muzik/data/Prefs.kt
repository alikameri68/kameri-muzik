package com.kameri.muzik.data

import android.content.Context
import com.kameri.muzik.ui.theme.ThemeMode

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("kameri", Context.MODE_PRIVATE)

    fun favorites(): Set<String> = sp.getStringSet("fav", emptySet())?.toSet() ?: emptySet()

    fun saveFavorites(value: Set<String>) {
        sp.edit().putStringSet("fav", value).apply()
    }

    fun theme(): ThemeMode =
        runCatching { ThemeMode.valueOf(sp.getString("theme", null) ?: ThemeMode.NIGHT.name) }
            .getOrDefault(ThemeMode.NIGHT)

    fun saveTheme(value: ThemeMode) {
        sp.edit().putString("theme", value.name).apply()
    }
}
