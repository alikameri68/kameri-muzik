package com.kameri.muzik.ui

import android.content.pm.ActivityInfo
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PictureInPictureAlt
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.kameri.muzik.MainActivity
import com.kameri.muzik.MainViewModel
import com.kameri.muzik.ui.theme.KType
import com.kameri.muzik.ui.theme.Motion
import kotlinx.coroutines.delay

/**
 * Tam ekran video. Tek dokunuş kontrolleri gösterir ya da gizler, çift dokunuş
 * on saniye sarar; kontroller oynarken üç saniye sonra kendiliğinden kaybolur.
 * Küçük pencere (PiP) modunda yalnızca görüntü çizilir.
 */
@Composable
fun FullscreenVideo(vm: MainViewModel, inPip: Boolean, immersive: Boolean, onExit: () -> Unit) {
    val player = vm.player
    val track = vm.current
    val night = PlayerColors
    val context = LocalContext.current
    val view = LocalView.current
    val haptic = LocalHapticFeedback.current
    val position = rememberPosition(player)
    var controls by remember { mutableStateOf(true) }
    var touches by remember { mutableIntStateOf(0) }

    // Yatay yön ve gizli sistem çubukları yalnızca gerçek tam ekranda
    DisposableEffect(immersive) {
        val activity = context.findActivity()
        val window = activity?.window
        if (immersive && activity != null && window != null) {
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            WindowCompat.getInsetsController(window, view).apply {
                systemBarsBehavior =
                    WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                hide(WindowInsetsCompat.Type.systemBars())
            }
        }
        onDispose {
            if (immersive && activity != null && window != null) {
                activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                WindowCompat.getInsetsController(window, view)
                    .show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    LaunchedEffect(controls, player.isPlaying, touches) {
        if (controls && player.isPlaying) {
            delay(3000L)
            controls = false
        }
    }

    BackHandler(enabled = !inPip, onBack = onExit)

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = {
                        controls = !controls
                        touches++
                    },
                    onDoubleTap = { o ->
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        player.seekBy(if (o.x < size.width / 2f) -10_000L else 10_000L)
                        touches++
                    },
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        VideoSurface(player.controller, Modifier.fillMaxSize())

        AnimatedVisibility(
            visible = controls && !inPip,
            enter = fadeIn(Motion.enter(220)),
            exit = fadeOut(Motion.exit(180)),
            modifier = Modifier.fillMaxSize(),
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.45f))
                    .safeDrawingPadding()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Row(
                    Modifier
                        .align(Alignment.TopCenter)
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = onExit) {
                        Icon(
                            Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Tam ekrandan çık",
                            tint = Color.White,
                        )
                    }
                    Text(
                        track?.title.orEmpty(),
                        style = KType.Title.copy(fontSize = KType.Subtitle.fontSize * 1.2f),
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    IconButton(
                        onClick = {
                            (context.findActivity() as? MainActivity)?.enterPip(player.videoAspect)
                        }
                    ) {
                        Icon(
                            Icons.Rounded.PictureInPictureAlt,
                            contentDescription = "Küçük pencere",
                            tint = Color.White,
                        )
                    }
                }

                Row(
                    Modifier.align(Alignment.Center),
                    horizontalArrangement = Arrangement.spacedBy(28.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(
                        onClick = {
                            player.seekBy(-10_000L)
                            touches++
                        },
                        modifier = Modifier.size(56.dp),
                    ) {
                        Icon(
                            Icons.Rounded.Replay10,
                            contentDescription = "On saniye geri",
                            tint = Color.White,
                            modifier = Modifier.size(34.dp),
                        )
                    }
                    IconButton(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            player.toggle()
                            touches++
                        },
                        modifier = Modifier.size(76.dp),
                    ) {
                        if (player.isBuffering) {
                            Rosette(
                                color = night.gold,
                                modifier = Modifier.size(40.dp),
                                stroke = 2.dp,
                                spinning = true,
                            )
                        } else {
                            Icon(
                                if (player.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                contentDescription = if (player.isPlaying) "Duraklat" else "Oynat",
                                tint = Color.White,
                                modifier = Modifier.size(56.dp),
                            )
                        }
                    }
                    IconButton(
                        onClick = {
                            player.seekBy(10_000L)
                            touches++
                        },
                        modifier = Modifier.size(56.dp),
                    ) {
                        Icon(
                            Icons.Rounded.Forward10,
                            contentDescription = "On saniye ileri",
                            tint = Color.White,
                            modifier = Modifier.size(34.dp),
                        )
                    }
                }

                Row(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp),
                ) {
                    Spacer(Modifier.width(4.dp))
                    PlayerSeek(
                        player = player,
                        position = position,
                        fallbackDurationMs = track?.durationMs ?: 0L,
                        active = night.gold,
                        inactive = Color.White.copy(alpha = 0.25f),
                        textColor = Color.White.copy(alpha = 0.8f),
                        modifier = Modifier.weight(1f),
                    )
                    Spacer(Modifier.width(4.dp))
                }
            }
        }
    }
}
