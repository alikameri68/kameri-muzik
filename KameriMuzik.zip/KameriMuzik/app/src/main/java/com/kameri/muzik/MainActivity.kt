package com.kameri.muzik

import android.app.PictureInPictureParams
import android.content.res.Configuration
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kameri.muzik.ui.AppRoot
import com.kameri.muzik.ui.theme.KameriTheme

/** Pencere içinde pencere durumu; arayüz ile Activity arasında paylaşılır. */
object PipState {
    var inPip by mutableStateOf(false)
    var eligible = false
    var aspect = 16f / 9f
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            val vm: MainViewModel = viewModel()
            KameriTheme(vm.themeMode) {
                AppRoot(vm)
            }
        }
    }

    fun enterPip(aspect: Float) {
        val safe = aspect.coerceIn(0.45f, 2.3f)
        val params = PictureInPictureParams.Builder()
            .setAspectRatio(Rational((safe * 1000).toInt(), 1000))
            .build()
        runCatching { enterPictureInPictureMode(params) }
    }

    // Video oynarken ana ekrana dönülürse kendiliğinden küçük pencereye geçer.
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (PipState.eligible) enterPip(PipState.aspect)
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration,
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        PipState.inPip = isInPictureInPictureMode
    }
}
