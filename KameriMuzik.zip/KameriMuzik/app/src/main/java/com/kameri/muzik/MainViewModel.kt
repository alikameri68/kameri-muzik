package com.kameri.muzik

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kameri.muzik.data.MediaRepository
import com.kameri.muzik.data.Prefs
import com.kameri.muzik.data.Track
import com.kameri.muzik.player.PlayerConnection
import com.kameri.muzik.ui.theme.ThemeMode
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = Prefs(app)
    val player = PlayerConnection(app)

    var tracks by mutableStateOf<List<Track>>(emptyList())
        private set
    private var byKey by mutableStateOf<Map<String, Track>>(emptyMap())
    var loading by mutableStateOf(false)
        private set
    var loadedOnce by mutableStateOf(false)
        private set
    var favorites by mutableStateOf(prefs.favorites())
        private set
    var themeMode by mutableStateOf(prefs.theme())
        private set
    var audioOnly by mutableStateOf(false)
        private set

    val current: Track? get() = player.currentKey?.let { byKey[it] }

    init {
        player.connect()
    }

    fun refresh() {
        if (loading) return
        viewModelScope.launch {
            loading = true
            val loaded = MediaRepository.load(getApplication())
            tracks = loaded
            byKey = loaded.associateBy { it.key }
            loading = false
            loadedOnce = true
        }
    }

    fun play(queue: List<Track>, index: Int) {
        if (audioOnly) changeAudioOnly(false)
        player.play(queue, index)
    }

    fun toggleFavorite(track: Track) {
        val next = if (track.key in favorites) favorites - track.key else favorites + track.key
        favorites = next
        prefs.saveFavorites(next)
    }

    fun cycleTheme() {
        val all = ThemeMode.entries
        val next = all[(themeMode.ordinal + 1) % all.size]
        themeMode = next
        prefs.saveTheme(next)
    }

    fun changeAudioOnly(value: Boolean) {
        audioOnly = value
        player.setVideoDisabled(value)
    }

    override fun onCleared() {
        player.release()
    }
}
