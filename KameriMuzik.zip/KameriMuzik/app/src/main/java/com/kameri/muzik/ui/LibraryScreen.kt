package com.kameri.muzik.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.kameri.muzik.MainViewModel
import com.kameri.muzik.data.Track
import com.kameri.muzik.data.formatTime
import com.kameri.muzik.ui.theme.KType
import com.kameri.muzik.ui.theme.LocalKameriColors
import java.util.Locale

private enum class LibraryTab(val label: String) {
    MUSIC("Müzik"),
    VIDEO("Video"),
    FAVORITES("Beğeniler"),
}

private val Turkish = Locale("tr")

@Composable
fun LibraryScreen(vm: MainViewModel, onPlay: (List<Track>, Int) -> Unit) {
    val c = LocalKameriColors.current
    var tab by rememberSaveable { mutableStateOf(LibraryTab.MUSIC) }
    var query by rememberSaveable { mutableStateOf("") }

    val tracks = vm.tracks
    val favorites = vm.favorites
    val list = remember(tracks, favorites, tab, query) {
        val base = when (tab) {
            LibraryTab.MUSIC -> tracks.filter { !it.isVideo }
            LibraryTab.VIDEO -> tracks.filter { it.isVideo }
            LibraryTab.FAVORITES -> tracks.filter { it.key in favorites }
        }
        val q = query.trim().lowercase(Turkish)
        if (q.isEmpty()) {
            base
        } else {
            base.filter {
                it.title.lowercase(Turkish).contains(q) || it.artist.lowercase(Turkish).contains(q)
            }
        }
    }

    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val bottomSpace = navBottom + (if (vm.current != null) 96.dp else 24.dp)

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        // Başlık
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 22.dp, end = 8.dp, top = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("KAMERÎ", style = KType.Caps, color = c.gold)
                Text("Müzik", style = KType.Display, color = c.text)
            }
            IconButton(onClick = { vm.cycleTheme() }) {
                Icon(Icons.Rounded.Palette, contentDescription = "Tema değiştir", tint = c.textSecondary)
            }
            IconButton(onClick = { vm.refresh() }) {
                Icon(Icons.Rounded.Refresh, contentDescription = "Kitaplığı yenile", tint = c.textSecondary)
            }
        }

        // Arama
        Row(
            Modifier
                .padding(horizontal = 20.dp, vertical = 12.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(c.subtle)
                .border(1.dp, c.border, RoundedCornerShape(16.dp))
                .padding(horizontal = 14.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                Icons.Rounded.Search,
                contentDescription = null,
                tint = c.textSecondary,
                modifier = Modifier.size(20.dp),
            )
            Spacer(Modifier.width(10.dp))
            BasicTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                textStyle = KType.Subtitle.copy(color = c.text),
                cursorBrush = SolidColor(c.gold),
                modifier = Modifier.weight(1f),
                decorationBox = { inner ->
                    Box {
                        if (query.isEmpty()) {
                            Text(
                                "Parça, sanatçı ya da video ara",
                                style = KType.Subtitle,
                                color = c.textSecondary,
                            )
                        }
                        inner()
                    }
                },
            )
        }

        // Sekmeler
        Row(
            Modifier.padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            LibraryTab.entries.forEach { item ->
                TabPill(label = item.label, selected = item == tab, onClick = { tab = item })
            }
            Spacer(Modifier.weight(1f))
            Text("${list.size}", style = KType.Time, color = c.textSecondary)
        }
        Spacer(Modifier.height(10.dp))

        when {
            list.isEmpty() -> EmptyState(
                text = when {
                    vm.loading || !vm.loadedOnce -> "Kitaplık taranıyor"
                    query.isNotBlank() -> "Aramayla eşleşen bir şey yok"
                    tab == LibraryTab.FAVORITES -> "Beğendiğin parçalar burada toplanır"
                    tab == LibraryTab.VIDEO -> "Cihazda video bulunamadı"
                    else -> "Cihazda müzik bulunamadı"
                },
                spinning = vm.loading || !vm.loadedOnce,
            )

            tab == LibraryTab.VIDEO -> LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = bottomSpace),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                itemsIndexed(list, key = { _, t -> t.key }) { index, track ->
                    VideoCard(
                        track = track,
                        isCurrent = vm.player.currentKey == track.key,
                        onClick = { onPlay(list, index) },
                        modifier = Modifier.animateItem(),
                    )
                }
            }

            else -> LazyColumn(
                contentPadding = PaddingValues(top = 4.dp, bottom = bottomSpace),
                modifier = Modifier.fillMaxSize(),
            ) {
                itemsIndexed(list, key = { _, t -> t.key }) { index, track ->
                    TrackRow(
                        track = track,
                        isCurrent = vm.player.currentKey == track.key,
                        isPlaying = vm.player.isPlaying,
                        isFavorite = track.key in favorites,
                        onClick = { onPlay(list, index) },
                        onFavorite = { vm.toggleFavorite(track) },
                        modifier = Modifier.animateItem(),
                    )
                }
            }
        }
    }
}

@Composable
private fun TabPill(label: String, selected: Boolean, onClick: () -> Unit) {
    val c = LocalKameriColors.current
    val bg by animateColorAsState(
        if (selected) c.gold.copy(alpha = 0.16f) else Color.Transparent, label = "tabBg",
    )
    val fg by animateColorAsState(if (selected) c.gold else c.textSecondary, label = "tabFg")
    val line by animateColorAsState(
        if (selected) c.gold.copy(alpha = 0.5f) else c.border, label = "tabLine",
    )
    Text(
        label,
        style = KType.Label,
        color = fg,
        modifier = Modifier
            .clip(CircleShape)
            .background(bg)
            .border(1.dp, line, CircleShape)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
    )
}

@Composable
private fun TrackRow(
    track: Track,
    isCurrent: Boolean,
    isPlaying: Boolean,
    isFavorite: Boolean,
    onClick: () -> Unit,
    onFavorite: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = LocalKameriColors.current
    val haptic = LocalHapticFeedback.current
    Row(
        modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 20.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Artwork(
            track,
            modifier = if (track.isVideo) {
                Modifier
                    .height(52.dp)
                    .aspectRatio(16f / 9f)
            } else {
                Modifier.size(52.dp)
            },
        )
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                track.title,
                style = KType.RowTitle,
                color = if (isCurrent) c.gold else c.text,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(2.dp))
            Text(
                "${track.artist} · ${formatTime(track.durationMs)}",
                style = KType.Body,
                color = c.textSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (isCurrent) {
            Rosette(color = c.gold, modifier = Modifier.size(20.dp), spinning = isPlaying)
        }
        IconButton(
            onClick = {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onFavorite()
            }
        ) {
            Icon(
                if (isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                contentDescription = if (isFavorite) "Beğeniyi kaldır" else "Beğen",
                tint = if (isFavorite) c.gold else c.textSecondary,
                modifier = Modifier.size(20.dp),
            )
        }
    }
}

@Composable
private fun VideoCard(
    track: Track,
    isCurrent: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = LocalKameriColors.current
    Column(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
    ) {
        Box {
            Artwork(
                track,
                corner = 14.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f),
            )
            Text(
                formatTime(track.durationMs),
                style = KType.Time,
                color = Color.White,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(6.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color.Black.copy(alpha = 0.6f))
                    .padding(horizontal = 6.dp, vertical = 2.dp),
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(
            track.title,
            style = KType.RowTitle,
            color = if (isCurrent) c.gold else c.text,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 2.dp),
        )
    }
}

@Composable
fun EmptyState(text: String, spinning: Boolean, modifier: Modifier = Modifier) {
    val c = LocalKameriColors.current
    Column(
        modifier
            .fillMaxSize()
            .padding(40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Rosette(color = c.gold, modifier = Modifier.size(64.dp), spinning = spinning)
        Spacer(Modifier.height(20.dp))
        Text(text, style = KType.Subtitle, color = c.textSecondary, textAlign = TextAlign.Center)
    }
}
