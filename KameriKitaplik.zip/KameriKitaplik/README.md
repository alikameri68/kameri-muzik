# Kamerî Kitaplık 4.0 (yerel Android)

WebView'sız, sıfırdan yazılmış Android sürümü: Kotlin + Jetpack Compose, ses için Media3.

## Bu sürümde
- **Kitaplık:** EPUB, PDF ve TXT ekleme; EPUB'un kendi kapağı, PDF'in ilk sayfası kapak olur.
- **Kitap sayfası:** büyük kapak, kapak renginden zemin, bilgi kutuları, içindekiler.
- **Okuma:** gerçek sayfalara bölünmüş metin, sayfa çevirme canlandırması, kenara dokunarak sayfa çevirme,
  dört sayfa rengi (Krem, Sepya, Gece, AMOLED), üç yazı tipi, yazı boyu ve satır aralığı sürgüleri,
  Arapça yazı tipi seçimi (Amiri / Noto Naskh), kalınan yer, içindekiler, sayfa kaydırıcısı.
- **PDF:** sayfa sayfa çevirme, çift dokunuşla yakınlaştırma, gece temasında koyu sayfa.
- **Sözlük:** kelimeye basılı tutunca çevrimdışı anlam (çekirdek lügat içinde gelir; Develioğlu ve Özön
  dosyaları Ayarlar → Sözlükler'den bir kez eklenir).
- **Dinle:** ses dosyası ekleme, arka planda ve ekran kilitliyken çalma, bildirim ve kilit ekranı denetimi,
  hız, 15 sn ileri/geri, uyku zamanlayıcısı, kaldığı yerden devam, sıradakine geçme.

## Henüz yok (sonraki sürümler)
Vurgu ve notlar, sesli okuma, hesapla eşitleme ve yedek, yapay zekâ ile konu bölme, podcast aboneliği,
eski uygulamadaki kitapları aktarma.

## Derleme
GitHub Actions `gradle assembleDebug` çalıştırır; APK "Actions" sekmesindeki çalıştırmanın altında
**KameriKitaplik** adıyla indirilir. İmza anahtarı (`kameri.keystore`) depodadır; her sürüm aynı anahtarla
imzalandığı için güncellemeler eski kurulumun üstüne kurulur ve kitaplar silinmez.
Uygulama kimliği `com.hazar.kitaplik`: eski WebView sürümüyle yan yana kurulur, onu silmez.

Yazı tipleri SIL Open Font License ile dağıtılır (`licenses/`).
