package com.hazar.kitaplik.data

import android.content.Context
import java.io.File
import kotlin.math.ceil

/**
 * Çevrimdışı sözlük. Çekirdek lügat uygulamanın içinde gelir; Develioğlu, Özön ya da başka
 * sözlükler kullanıcının seçtiği dosyadan bir kez alınır ve cihazda saklanır.
 * Biçim: her satırda "madde<TAB>anlam" ya da "madde|anlam|arap harfli yazılış".
 */
class Dictionary {

    class Dict(
        val name: String,
        val file: String?,
        val heads: Array<String>,
        val means: Array<String>,
        val arabic: Array<String>,
        val index: HashMap<String, MutableList<Int>>,
    )

    data class Hit(
        val head: String,
        val meaning: String,
        val arabic: String,
        val source: String,
        val exact: Boolean,
        val stem: String,
    )

    @Volatile
    var dicts: List<Dict> = emptyList()
        private set

    fun load(ctx: Context, dictDir: File) {
        val list = ArrayList<Dict>()
        dictDir.listFiles()?.filter { it.isFile && it.name.endsWith(".tsv") }?.sortedBy { it.name }?.forEach { f ->
            runCatching { parse(f.readText(), f.nameWithoutExtension, f.name) }.getOrNull()?.let { list += it }
        }
        runCatching {
            val core = ctx.assets.open("sozluk.txt").bufferedReader().use { it.readText() }
            parse(core, "Divan şiiri çekirdek lügati", null)
        }.getOrNull()?.let { list += it }
        dicts = list
    }

    /** Dosyadaki ilk "# ad:" satırını okur. */
    fun nameOf(text: String, fallback: String): String =
        text.lineSequence().take(5).firstOrNull { it.startsWith("# ad:") }?.substringAfter("# ad:")?.trim()?.ifEmpty { null } ?: fallback

    fun parse(text: String, fallbackName: String, file: String?): Dict? {
        val heads = ArrayList<String>()
        val means = ArrayList<String>()
        val ar = ArrayList<String>()
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) continue
            val tab = line.indexOf('\t')
            if (tab > 0) {
                val h = line.substring(0, tab).trim()
                val m = line.substring(tab + 1).trim()
                if (h.isNotEmpty() && m.isNotEmpty()) { heads += h; means += m; ar += "" }
                continue
            }
            val p = line.split('|')
            if (p.size >= 2 && p[0].isNotBlank() && p[1].isNotBlank() && p[0].length <= 80) {
                heads += p[0].trim(); means += p[1].trim(); ar += (p.getOrNull(2) ?: "").trim()
            }
        }
        if (heads.isEmpty()) return null
        val index = HashMap<String, MutableList<Int>>(heads.size * 2)
        fun add(k: String, i: Int) {
            if (k.isEmpty()) return
            val l = index.getOrPut(k) { ArrayList(1) }
            if (l.isEmpty() || l[l.size - 1] != i) l += i
        }
        for (i in heads.indices) {
            for (part in heads[i].split(',', ';')) {
                val k = norm(part)
                add(k, i)
                // "kitâb-ı" gibi izafetli maddeler dışında tireli maddeler tiresiz de bulunur
                if (k.contains('-') && !izafet.containsMatchIn(k)) add(k.replace("-", ""), i)
            }
            if (ar[i].isNotEmpty()) add(norm(ar[i]), i)
        }
        return Dict(nameOf(text, fallbackName), file, heads.toTypedArray(), means.toTypedArray(), ar.toTypedArray(), index)
    }

    fun lookup(word: String, max: Int = 6): List<Hit> {
        val key = norm(word)
        if (key.isEmpty()) return emptyList()
        // kelimenin yarısından fazlasını kesen kök alınmaz ("gönlümde" → "gön" gibi yanlışlar çıkmasın)
        val minL = maxOf(2, ceil(key.length * 0.4).toInt())
        val stems = stems(key).filterIndexed { i, s -> i == 0 || s.length >= minL }.toMutableList()
        if (key.indexOf('-') > 0 && !izafet.containsMatchIn(key)) stems.add(1, key.replace("-", ""))

        class Cand(val hit: Hit, val pen: Int, val dict: Int, val order: Int)
        val out = ArrayList<Cand>()
        val seen = HashSet<String>()
        dicts.forEachIndexed { di, d ->
            for ((si, st) in stems.withIndex()) {
                val ids = d.index[st] ?: continue
                for (i in ids) {
                    if (!seen.add("$di:$i")) continue
                    val pen = key.length - st.length + (if (key.startsWith(st)) 0 else 2)
                    val exact = si == 0 || st == key.replace("-", "")
                    out += Cand(Hit(d.heads[i], follow(d, d.means[i]), d.arabic[i], d.name, exact, st), pen, di, out.size)
                }
                if (out.size > 40) break
            }
        }
        out.sortWith(
            compareByDescending<Cand> { it.hit.exact }.thenBy { it.pen }.thenBy { it.dict }.thenBy { it.order }
        )
        return out.take(max).map { it.hit }
    }

    /** "(bkz. gönül)" gibi göndermelerde gösterilen maddenin anlamı da eklenir. */
    private fun follow(d: Dict, mean: String): String {
        val m = bkz.find(mean) ?: return mean
        if (mean.length > m.range.last + 12) return mean
        val target = norm(m.groupValues[1])
        val ids = d.index[target] ?: return mean
        val i = ids.first()
        return mean + "\n→ " + d.heads[i] + ": " + d.means[i]
    }

    fun search(q: String, max: Int = 40): List<Hit> {
        val key = norm(q)
        if (key.length < 2) return emptyList()
        val out = ArrayList<Hit>()
        for (d in dicts) {
            for (i in d.heads.indices) {
                if (norm(d.heads[i]).startsWith(key)) {
                    out += Hit(d.heads[i], d.means[i], d.arabic[i], d.name, true, key)
                    if (out.size >= max) return out
                }
            }
        }
        return out
    }

    companion object {
        private val izafet = Regex("-[a-zçğıöşü]{1,2}([- ]|$)")
        private val bkz = Regex("^\\(?\\s*bkz[.:]?\\s*:?\\s*([^),;]{2,40})", RegexOption.IGNORE_CASE)
        private val arabicRange = '؀'..'ۿ'

        private val SUF = listOf(
            "lerinden", "larından", "lerinde", "larında", "lerine", "larına", "lerini", "larını", "lerin", "ların", "leri", "ları", "ler", "lar",
            "sinden", "sından", "sunda", "sinde", "sında", "sine", "sına", "sini", "sını", "ünden", "inden", "ından", "undan", "ünde", "inde", "ında", "unda", "üne", "ine", "ına", "una", "ünü", "ini", "ını", "unu",
            "nın", "nin", "nun", "nün", "ımız", "imiz", "umuz", "ümüz", "ınız", "iniz", "unuz", "ünüz", "dır", "dir", "dur", "dür", "tır", "tir", "tur", "tür", "dan", "den", "tan", "ten", "yla", "yle",
            "lık", "lik", "luk", "lük", "sız", "siz", "suz", "süz", "ım", "im", "um", "üm", "ın", "in", "un", "ün", "sı", "si", "su", "sü", "yı", "yi", "yu", "yü", "ya", "ye", "da", "de", "ta", "te", "la", "le", "lı", "li", "lu", "lü", "ca", "ce", "ça", "çe", "ki", "ı", "i", "u", "ü", "a", "e", "m", "n",
        )
        private val HARD = mapOf('b' to 'p', 'c' to 'ç', 'd' to 't', 'ğ' to 'k', 'g' to 'k')
        private const val VOWELS = "aeıioöuü"
        private val AR_PRE = listOf("وال", "بال", "فال", "کال", "لل", "ال", "نمی", "می", "و", "ب", "ل", "ک", "ف", "ن")
        private val AR_SUF = listOf("هایی", "های", "ها", "ترین", "تر", "ان", "ات", "ین", "ون", "ی", "ه", "م", "ت", "ش")

        fun norm(w: String): String {
            val t = w.trim()
            if (t.any { it in arabicRange }) {
                val sb = StringBuilder()
                for (ch in t) {
                    val c = when (ch) {
                        'ي', 'ى', 'ئ' -> 'ی'
                        'ك' -> 'ک'
                        'أ', 'إ', 'آ', 'ٱ' -> 'ا'
                        'ة' -> 'ه'
                        'ؤ' -> 'و'
                        else -> ch
                    }
                    if (c in arabicRange && !(c in 'ً'..'ٟ') && c != 'ٰ' && c != 'ـ') sb.append(c)
                }
                return sb.toString()
            }
            val sb = StringBuilder()
            for (ch in t.lowercase(TR)) {
                val c = when (ch) {
                    'â', 'ā' -> 'a'
                    'î', 'ī' -> 'i'
                    'û', 'ū' -> 'u'
                    'ô' -> 'o'
                    'ê' -> 'e'
                    else -> ch
                }
                if (c in 'a'..'z' || c in "çğıöşü" || c in '0'..'9' || c == ' ' || c == '-') sb.append(c)
            }
            return sb.toString().replace(Regex("\\s*-\\s*"), "-").replace(Regex("\\s+"), " ").trim()
        }

        fun stems(key: String): List<String> {
            val out = ArrayList<String>()
            val seen = HashSet<String>()
            val minL = if (key.length > 4) 3 else 2
            fun add(s: String) {
                if (s.length >= minL && seen.add(s)) out += s
            }
            out += key
            seen += key
            if (key.any { it in arabicRange }) {
                var cur = listOf(key)
                repeat(2) {
                    val nx = ArrayList<String>()
                    for (k in cur) {
                        for (p in AR_PRE) if (k.startsWith(p) && k.length - p.length >= 2) nx += k.substring(p.length)
                        for (s in AR_SUF) if (k.endsWith(s) && k.length - s.length >= 2) nx += k.substring(0, k.length - s.length)
                    }
                    nx.forEach { add(it) }
                    cur = nx
                }
                return out
            }
            var cur = listOf(key)
            for (d in 0 until 3) {
                val nx = ArrayList<String>()
                for (k in cur) {
                    for (s in SUF) {
                        if (k.length - s.length < 2 || !k.endsWith(s)) continue
                        val st = k.substring(0, k.length - s.length)
                        nx += st
                        val l = st.last()
                        HARD[l]?.let { nx += st.dropLast(1) + it }
                        // düşen ünlü: gönl-ü → gönül, ömr-ü → ömür
                        if (st.length >= 3 && st.takeLast(2).none { it in VOWELS }) {
                            for (v in "ıiuü") nx += st.dropLast(1) + v + st.last()
                        }
                    }
                }
                nx.forEach { add(it) }
                cur = nx
                if (out.size > 400) break
            }
            return out
        }

        /** Metindeki bir konumun üstündeki kelimeyi verir; kesme işaretinden sonrası (Fuzûlî'nin) atılır. */
        fun wordAt(text: String, offset: Int): String? {
            if (text.isEmpty()) return null
            fun part(c: Char) = c.isLetter() || c == '\'' || c == '’' || c == 'ʿ' || c == 'ʾ' || c == '-' || c == 'ٰ' || c in 'ً'..'ٟ'
            var i = offset.coerceIn(0, text.length - 1)
            if (!part(text[i]) && i > 0 && part(text[i - 1])) i--
            if (!part(text[i])) return null
            var s = i
            var e = i
            while (s > 0 && part(text[s - 1])) s--
            while (e < text.length - 1 && part(text[e + 1])) e++
            var w = text.substring(s, e + 1).trim('-', '\'', '’')
            val ap = w.indexOfFirst { it == '\'' || it == '’' }
            if (ap > 1 && w.none { it in arabicRange }) w = w.substring(0, ap)
            return w.takeIf { it.isNotBlank() }
        }
    }
}
