package com.hazar.kitaplik.data

import android.content.Context
import com.hazar.kitaplik.ui.theme.KTheme

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("kameri", Context.MODE_PRIVATE)

    fun appTheme(): KTheme = runCatching { KTheme.valueOf(sp.getString("theme", null) ?: KTheme.CREAM.name) }
        .getOrDefault(KTheme.CREAM)

    fun saveAppTheme(t: KTheme) = sp.edit().putString("theme", t.name).apply()

    fun reader(): ReaderSettings = ReaderSettings(
        theme = sp.getString("r_theme", "CREAM") ?: "CREAM",
        font = sp.getString("r_font", "literata") ?: "literata",
        size = sp.getFloat("r_size", 18f),
        lineHeight = sp.getFloat("r_lh", 1.65f),
        arabicFont = sp.getString("r_ar", "amiri") ?: "amiri",
        justify = sp.getBoolean("r_just", true),
    )

    fun saveReader(r: ReaderSettings) = sp.edit()
        .putString("r_theme", r.theme).putString("r_font", r.font).putFloat("r_size", r.size)
        .putFloat("r_lh", r.lineHeight).putString("r_ar", r.arabicFont).putBoolean("r_just", r.justify)
        .apply()

    fun speed(): Float = sp.getFloat("speed", 1f)
    fun saveSpeed(v: Float) = sp.edit().putFloat("speed", v).apply()

    fun autoNext(): Boolean = sp.getBoolean("auto_next", true)
    fun saveAutoNext(v: Boolean) = sp.edit().putBoolean("auto_next", v).apply()

    fun lastPod(): String? = sp.getString("last_pod", null)
    fun saveLastPod(id: String?) = sp.edit().putString("last_pod", id).apply()
}
