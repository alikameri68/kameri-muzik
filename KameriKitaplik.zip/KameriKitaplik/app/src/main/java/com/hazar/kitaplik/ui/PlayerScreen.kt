@file:OptIn(ExperimentalMaterial3Api::class)

package com.hazar.kitaplik.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.material.icons.rounded.FastRewind
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import com.hazar.kitaplik.MainViewModel
import com.hazar.kitaplik.data.Pod
import com.hazar.kitaplik.data.formatTime
import com.hazar.kitaplik.ui.theme.KType
import com.hazar.kitaplik.ui.theme.LocalKColors
import com.hazar.kitaplik.ui.theme.Motion
import com.hazar.kitaplik.ui.theme.NightColors
import kotlinx.coroutines.delay

private val Speeds = listOf(0.8f, 1f, 1.2f, 1.5f, 1.75f, 2f)
private val Sleeps = listOf(0 to "Kapalı", 10 to "10 dk", 20 to "20 dk", 30 to "30 dk", 45 to "45 dk", 60 to "1 saat", -1 to "Bölüm sonu")

private fun speedLabel(v: Float): String = (if (v == v.toInt().toFloat()) v.toInt().toString() else v.toString().replace('.', ',')) + "×"

/** Tam ekran oynatıcı: kapak renginden zemin, büyük kapak, ilerleme, denetimler. */
@Composable
fun PlayerScreen(vm: MainViewModel, onClose: () -> Unit) {
    val p = vm.shownPod
    val c = NightColors
    if (p == null) {
        LaunchedEffect(Unit) { onClose() }
        Box(Modifier.fillMaxSize().background(c.bg))
        return
    }
    val (top, bottom) = tintOf(p.id)
    val active = vm.player.currentKey == p.id
    val playing = active && vm.player.isPlaying
    val pos = rememberPodPosition(vm, p)
    val dur = if (active && vm.player.durationMs > 0) vm.player.durationMs else p.durationMs
    var sheet by remember { mutableIntStateOf(0) } // 1 uyku, 2 seçenekler
    val artScale by animateFloatAsState(if (playing) 1f else 0.88f, Motion.spring(), label = "art")

    Box(
        Modifier
            .fillMaxSize()
            .background(c.bg)
            .background(Brush.verticalGradient(0f to top.copy(alpha = 0.95f), 0.55f to bottom.copy(alpha = 0.6f), 1f to c.bg)),
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                RoundIcon(Icons.Rounded.KeyboardArrowDown, "Küçült", background = Color.White.copy(alpha = 0.12f), tint = Color.White) { onClose() }
                Text(
                    if (playing) "ŞİMDİ ÇALIYOR" else "DURAKLATILDI",
                    style = KType.Caps,
                    color = Color.White.copy(alpha = 0.75f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f),
                )
                RoundIcon(Icons.Rounded.Edit, "Seçenekler", background = Color.White.copy(alpha = 0.12f), tint = Color.White) { sheet = 2 }
            }
            Spacer(Modifier.height(26.dp))
            BoxWithConstraints(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                val side = minOf(maxWidth * 0.82f, 330.dp)
                PodArt(
                    p,
                    vm.coverOfPod(p),
                    Modifier
                        .width(side)
                        .aspectRatio(1f)
                        .scale(artScale)
                        .shadow(30.dp, RoundedCornerShape(28.dp), ambientColor = Color.Black, spotColor = Color.Black),
                    corner = 28.dp,
                )
            }
            Spacer(Modifier.height(28.dp))
            Text(p.title, style = KType.Title, color = Color.White, textAlign = TextAlign.Center, maxLines = 3, overflow = TextOverflow.Ellipsis)
            if (p.artist.isNotEmpty()) {
                Spacer(Modifier.height(4.dp))
                Text(p.artist, style = KType.Subtitle, color = Color.White.copy(alpha = 0.75f), textAlign = TextAlign.Center, maxLines = 1)
            }
            Spacer(Modifier.height(22.dp))
            SeekBar(
                positionMs = pos,
                durationMs = dur,
                onSeek = { vm.seekPod(it) },
                active = Color.White,
                inactive = Color.White.copy(alpha = 0.22f),
            )
            Row(Modifier.fillMaxWidth()) {
                Text(formatTime(pos), style = KType.Time, color = Color.White.copy(alpha = 0.75f))
                Spacer(Modifier.weight(1f))
                Text(if (dur > 0) "-" + formatTime(dur - pos) else "", style = KType.Time, color = Color.White.copy(alpha = 0.75f))
            }
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                SkipButton(Icons.Rounded.FastRewind, "15 saniye geri") { vm.skip(-15_000) }
                Box(
                    Modifier
                        .size(78.dp)
                        .shadow(20.dp, CircleShape)
                        .clip(CircleShape)
                        .background(Color.White)
                        .pressable({ vm.togglePod() }, 0.9f),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (playing) "Duraklat" else "Oynat", tint = top, modifier = Modifier.size(38.dp))
                }
                SkipButton(Icons.Rounded.FastForward, "15 saniye ileri") { vm.skip(15_000) }
            }
            Spacer(Modifier.height(26.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val sleepOn = vm.sleepEndsAt > 0L || vm.sleepAtEnd
                OptionTile(Icons.Rounded.Speed, speedLabel(vm.speed), vm.speed != 1f, Modifier.weight(1f)) {
                    val i = Speeds.indexOf(vm.speed)
                    vm.changeSpeed(Speeds[(if (i < 0) 1 else i + 1) % Speeds.size])
                }
                OptionTile(Icons.Rounded.Bedtime, sleepLabel(vm), sleepOn, Modifier.weight(1f)) { sheet = 1 }
                OptionTile(Icons.Rounded.SkipNext, "Sıradaki", vm.autoNext, Modifier.weight(1f)) {
                    vm.changeAutoNext(!vm.autoNext)
                    vm.say(if (vm.autoNext) "Bölüm bitince sıradakine geçer" else "Bölüm bitince durur")
                }
            }
            Spacer(Modifier.height(30.dp))
        }
    }

    if (sheet == 1) {
        ModalBottomSheet(
            onDismissRequest = { sheet = 0 },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = LocalKColors.current.card,
        ) { SleepSheet(vm) { sheet = 0 } }
    }
    if (sheet == 2) {
        ModalBottomSheet(
            onDismissRequest = { sheet = 0 },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = LocalKColors.current.card,
        ) { PodOptions(vm, p) { sheet = 0 } }
    }
}

@Composable
private fun sleepLabel(vm: MainViewModel): String {
    if (vm.sleepAtEnd) return "Bölüm sonu"
    if (vm.sleepEndsAt <= 0L) return "Uyku"
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(vm.sleepEndsAt) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }
    val s = ((vm.sleepEndsAt - now) / 1000).coerceAtLeast(0)
    return if (s >= 60) "${(s + 59) / 60} dk" else "$s sn"
}

@Composable
private fun SkipButton(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.pressable(onClick, 0.86f)) {
        Icon(icon, desc, tint = Color.White, modifier = Modifier.size(34.dp))
        Text("15", style = KType.Time.copy(fontSize = 10.sp), color = Color.White.copy(alpha = 0.75f))
    }
}

@Composable
private fun OptionTile(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    on: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (on) Color.White.copy(alpha = 0.22f) else Color.White.copy(alpha = 0.08f))
            .border(1.dp, Color.White.copy(alpha = if (on) 0.45f else 0.12f), RoundedCornerShape(16.dp))
            .pressable(onClick, 0.94f)
            .padding(vertical = 11.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(19.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, style = KType.Small, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SleepSheet(vm: MainViewModel, onDone: () -> Unit) {
    val c = LocalKColors.current
    Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp).padding(bottom = 26.dp).navigationBarsPadding()) {
        Text("Uyku zamanlayıcısı", style = KType.Title, color = c.text)
        Spacer(Modifier.height(14.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Sleeps.forEach { (m, l) ->
                val on = when {
                    m == -1 -> vm.sleepAtEnd
                    m == 0 -> !vm.sleepAtEnd && vm.sleepEndsAt == 0L
                    else -> false
                }
                KChip(l, selected = on) {
                    vm.setSleep(m)
                    vm.say(
                        when {
                            m == -1 -> "Bu bölüm bitince duracak"
                            m > 0 -> "$m dakika sonra duracak"
                            else -> "Uyku zamanlayıcısı kapalı"
                        }
                    )
                    onDone()
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Süre dolunca ses yavaşça kısılır ve durur; kaldığın yer saklanır.", style = KType.Body, color = c.textSecondary)
    }
}

@Composable
private fun PodOptions(vm: MainViewModel, p: Pod, onDone: () -> Unit) {
    val c = LocalKColors.current
    var title by remember { mutableStateOf(p.title) }
    var artist by remember { mutableStateOf(p.artist) }
    var armed by remember { mutableStateOf(false) }
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 22.dp)
            .padding(bottom = 26.dp)
            .navigationBarsPadding(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("Kayıt", style = KType.Title, color = c.text)
        OutlinedTextField(title, { title = it }, label = { Text("Başlık") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next))
        OutlinedTextField(artist, { artist = it }, label = { Text("Kişi / program") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done))
        MainButton("Kaydet", Icons.Rounded.Check, Modifier.fillMaxWidth()) {
            vm.renamePod(p.id, title, artist)
            onDone()
        }
        GhostButton(if (p.done) "Dinlenmedi yap" else "Dinlendi yap", Icons.Rounded.Check, modifier = Modifier.fillMaxWidth()) {
            vm.setPodDone(p.id, !p.done)
            onDone()
        }
        GhostButton("Baştan başlat", Icons.Rounded.Replay, modifier = Modifier.fillMaxWidth()) {
            vm.restartPod(p.id)
            onDone()
        }
        GhostButton(
            if (armed) "Silmek için bir daha dokun" else "Sil",
            Icons.Rounded.Delete,
            color = c.rust,
            modifier = Modifier.fillMaxWidth(),
        ) {
            if (armed) {
                vm.deletePod(p.id)
                onDone()
            } else {
                armed = true
            }
        }
    }
}

/** İlerleme çubuğu: sürüklerken kalınlaşır, her yüzde beşte hafif titreşim verir. */
@Composable
fun SeekBar(
    positionMs: Long,
    durationMs: Long,
    onSeek: (Long) -> Unit,
    active: Color,
    inactive: Color,
    modifier: Modifier = Modifier,
) {
    val haptic = LocalHapticFeedback.current
    val currentOnSeek by rememberUpdatedState(onSeek)
    var dragging by remember { mutableStateOf(false) }
    var dragFraction by remember { mutableFloatStateOf(0f) }
    var lastTick by remember { mutableIntStateOf(-1) }
    val real = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
    val shown = if (dragging) dragFraction else real
    val grow by animateFloatAsState(if (dragging) 1f else 0f, Motion.spring(), label = "seekGrow")

    Canvas(
        modifier
            .fillMaxWidth()
            .height(30.dp)
            .pointerInput(durationMs) {
                if (durationMs <= 0) return@pointerInput
                detectTapGestures { o ->
                    currentOnSeek(((o.x / size.width).coerceIn(0f, 1f) * durationMs).toLong())
                }
            }
            .pointerInput(durationMs) {
                if (durationMs <= 0) return@pointerInput
                detectHorizontalDragGestures(
                    onDragStart = { o ->
                        dragFraction = (o.x / size.width).coerceIn(0f, 1f)
                        dragging = true
                    },
                    onDragEnd = {
                        dragging = false
                        currentOnSeek((dragFraction * durationMs).toLong())
                    },
                    onDragCancel = { dragging = false },
                ) { change, amount ->
                    change.consume()
                    dragFraction = (dragFraction + amount / size.width).coerceIn(0f, 1f)
                    val tick = (dragFraction * 20f).toInt()
                    if (tick != lastTick) {
                        lastTick = tick
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    }
                }
            },
    ) {
        val cy = size.height / 2f
        val h = lerp(4.dp.toPx(), 7.dp.toPx(), grow)
        val r = CornerRadius(h / 2f, h / 2f)
        drawRoundRect(inactive, topLeft = Offset(0f, cy - h / 2f), size = Size(size.width, h), cornerRadius = r)
        drawRoundRect(active, topLeft = Offset(0f, cy - h / 2f), size = Size(size.width * shown, h), cornerRadius = r)
        drawCircle(active, radius = lerp(6.dp.toPx(), 10.dp.toPx(), grow), center = Offset(size.width * shown, cy))
    }
}
