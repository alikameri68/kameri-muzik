package com.hazar.kitaplik.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.hazar.kitaplik.ui.theme.KType
import com.hazar.kitaplik.ui.theme.LocalKColors
import com.hazar.kitaplik.ui.theme.Literata
import com.hazar.kitaplik.ui.theme.Motion
import kotlinx.coroutines.delay
import java.io.File
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/** Selçuklu sekiz köşeli yıldızı: kapaksız kitabın süsü, yükleme göstergesi. */
@Composable
fun Rosette(color: Color, modifier: Modifier = Modifier, stroke: Dp = 1.4.dp, spinning: Boolean = false) {
    val rotation: State<Float> = if (spinning) {
        rememberInfiniteTransition(label = "rosette").animateFloat(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing)),
            label = "rosetteRotation",
        )
    } else {
        remember { mutableFloatStateOf(0f) }
    }
    Canvas(modifier.graphicsLayer { rotationZ = rotation.value }) {
        val c = center
        val r = size.minDimension / 2f * 0.94f
        val sw = stroke.toPx()
        fun polygon(n: Int, radius: Float, startDeg: Double): Path {
            val path = Path()
            for (i in 0 until n) {
                val a = Math.toRadians(startDeg + i * 360.0 / n)
                val x = c.x + radius * cos(a).toFloat()
                val y = c.y + radius * sin(a).toFloat()
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            return path
        }
        val outline = Stroke(width = sw, join = StrokeJoin.Round)
        drawPath(polygon(4, r, -90.0), color, style = outline)
        drawPath(polygon(4, r, -45.0), color, style = outline)
        drawPath(polygon(8, r * 0.42f, -67.5), color, style = Stroke(sw * 0.8f, join = StrokeJoin.Round))
        drawCircle(color, radius = sw * 1.3f, center = Offset(c.x, c.y))
    }
}

/** Kapak renkleri (kitabın kimliğinden seçilir): koyu yeşil, bordo, lacivert, kahve, mor, petrol. */
private val CoverTints = listOf(
    Color(0xFF1F5C49) to Color(0xFF0E2F25),
    Color(0xFF7A2E2E) to Color(0xFF3F1414),
    Color(0xFF2A3A6E) to Color(0xFF131C3A),
    Color(0xFF8C6220) to Color(0xFF47300C),
    Color(0xFF5E3C60) to Color(0xFF2C1A2D),
    Color(0xFF205478) to Color(0xFF0E2A3E),
)

fun tintOf(id: String): Pair<Color, Color> = CoverTints[abs(id.hashCode()) % CoverTints.size]

/**
 * Kitap kapağı. Dosyanın kendi kapağı varsa o, yoksa çizim kapak (renkli cilt, yıldız ve başlık).
 * Sol kenardaki ışık ve gölge cilt sırtı hissi verir.
 */
@Composable
fun BookCover(
    id: String,
    title: String,
    cover: File?,
    modifier: Modifier = Modifier,
    titleSize: TextUnit = 13.sp,
    elevation: Dp = 10.dp,
) {
    val (top, bottom) = tintOf(id)
    val shape = RoundedCornerShape(topStart = 3.dp, bottomStart = 3.dp, topEnd = 9.dp, bottomEnd = 9.dp)
    Box(
        modifier
            .aspectRatio(2f / 3f)
            .shadow(elevation, shape, ambientColor = Color.Black.copy(alpha = 0.35f), spotColor = Color.Black.copy(alpha = 0.45f))
            .clip(shape)
            .background(Brush.linearGradient(listOf(top, bottom))),
    ) {
        if (cover != null) {
            AsyncImage(
                model = cover,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            val gold = Color(0xFFE2C46A)
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(7.dp)
                    .border(0.8.dp, gold.copy(alpha = 0.55f), RoundedCornerShape(4.dp)),
            )
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp, vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Rosette(gold.copy(alpha = 0.85f), Modifier.fillMaxWidth(0.42f).aspectRatio(1f), stroke = 1.1.dp)
                Spacer(Modifier.height(10.dp))
                Text(
                    title,
                    color = Color(0xFFF6EFDF),
                    fontFamily = Literata,
                    fontWeight = FontWeight(600),
                    fontSize = titleSize,
                    lineHeight = titleSize * 1.18f,
                    textAlign = TextAlign.Center,
                    maxLines = 4,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        // cilt sırtı
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        0f to Color.Black.copy(alpha = 0.30f),
                        0.035f to Color.White.copy(alpha = 0.16f),
                        0.07f to Color.Black.copy(alpha = 0.10f),
                        0.14f to Color.Transparent,
                        1f to Color.Transparent,
                    )
                ),
        )
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.10f), Color.Transparent, Color.Transparent))),
        )
    }
}

/** Parmağın altında hafifçe gömülen tıklanabilir alan. */
@Composable
fun Modifier.pressable(onClick: () -> Unit, scaleTo: Float = 0.96f): Modifier {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) scaleTo else 1f, Motion.spring(), label = "press")
    return this
        .scale(s)
        .clickable(interactionSource = source, indication = null, onClick = onClick)
}

@Composable
fun KChip(
    label: String,
    selected: Boolean = false,
    icon: ImageVector? = null,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val c = LocalKColors.current
    val bg by animateColorAsState(if (selected) c.accent else c.subtle, Motion.enter(240), label = "chipBg")
    val fg by animateColorAsState(if (selected) (if (c.isDark) c.bg else Color.White) else c.text, Motion.enter(240), label = "chipFg")
    Row(
        modifier
            .clip(CircleShape)
            .background(bg)
            .border(1.dp, if (selected) Color.Transparent else c.border, CircleShape)
            .pressable(onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, null, tint = fg, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
        }
        Text(label, style = KType.Label, color = fg, maxLines = 1)
    }
}

@Composable
fun MainButton(label: String, icon: ImageVector? = null, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val c = LocalKColors.current
    Row(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(c.accent)
            .pressable(onClick, 0.97f)
            .padding(horizontal = 20.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        val fg = if (c.isDark) c.bg else Color.White
        if (icon != null) {
            Icon(icon, null, tint = fg, modifier = Modifier.size(19.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(label, style = KType.Label.copy(fontSize = 14.5.sp), color = fg, maxLines = 1)
    }
}

@Composable
fun GhostButton(
    label: String,
    icon: ImageVector? = null,
    color: Color? = null,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val c = LocalKColors.current
    val fg = color ?: c.text
    Row(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(c.subtle)
            .border(1.dp, c.border, RoundedCornerShape(16.dp))
            .pressable(onClick, 0.97f)
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        if (icon != null) {
            Icon(icon, null, tint = fg, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(label, style = KType.Label, color = fg, maxLines = 1)
    }
}

@Composable
fun RoundIcon(
    icon: ImageVector,
    description: String,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    background: Color? = null,
    tint: Color? = null,
    onClick: () -> Unit,
) {
    val c = LocalKColors.current
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(background ?: c.subtle)
            .pressable(onClick, 0.9f),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, description, tint = tint ?: c.text, modifier = Modifier.size(size * 0.48f))
    }
}

@Composable
fun SectionHeader(title: String, note: String = "", modifier: Modifier = Modifier) {
    val c = LocalKColors.current
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(c.gold).align(Alignment.CenterVertically))
        Spacer(Modifier.width(10.dp))
        Text(title, style = KType.Section, color = c.text, modifier = Modifier.weight(1f))
        if (note.isNotEmpty()) Text(note, style = KType.Small, color = c.textSecondary)
    }
}

@Composable
fun ProgressLine(progress: Float, modifier: Modifier = Modifier, color: Color? = null, track: Color? = null, height: Dp = 3.dp) {
    val c = LocalKColors.current
    val p by animateFloatAsState(progress.coerceIn(0f, 1f), Motion.enter(500), label = "prog")
    Box(
        modifier
            .fillMaxWidth()
            .height(height)
            .clip(CircleShape)
            .background(track ?: c.muted),
    ) {
        Box(
            Modifier
                .fillMaxWidth(p)
                .height(height)
                .clip(CircleShape)
                .background(color ?: c.accent),
        )
    }
}

/** Ekranın altında kısa süre görünen bildirim. */
@Composable
fun BoxScope.ToastHost(message: String?, seq: Int, bottomPadding: Dp, onDone: () -> Unit) {
    val c = LocalKColors.current
    var shown by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }
    LaunchedEffect(seq) {
        if (message != null) {
            text = message
            shown = true
            delay(2600)
            shown = false
            delay(300)
            onDone()
        }
    }
    AnimatedVisibility(
        visible = shown,
        enter = fadeIn(Motion.enter(260)) + slideInVertically(Motion.enter(360)) { it / 2 },
        exit = fadeOut(Motion.exit(200)) + slideOutVertically(Motion.exit(200)) { it / 3 },
        modifier = Modifier
            .align(Alignment.BottomCenter)
            .navigationBarsPadding()
            .padding(bottom = bottomPadding, start = 24.dp, end = 24.dp),
    ) {
        Text(
            text,
            style = KType.Label,
            color = if (c.isDark) c.bg else Color.White,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .shadow(14.dp, RoundedCornerShape(16.dp))
                .clip(RoundedCornerShape(16.dp))
                .background(if (c.isDark) c.text else Color(0xFF1C2622))
                .padding(horizontal = 18.dp, vertical = 13.dp),
        )
    }
}

/** Uzun işlerde (kitap ekleme gibi) ekranı kaplayan bekleme kartı. */
@Composable
fun BusyOverlay(text: String?) {
    val c = LocalKColors.current
    AnimatedVisibility(visible = text != null, enter = fadeIn(Motion.enter(200)), exit = fadeOut(Motion.exit(200))) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.42f))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
            contentAlignment = Alignment.Center,
        ) {
            Column(
                Modifier
                    .padding(32.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(c.card)
                    .padding(PaddingValues(horizontal = 26.dp, vertical = 24.dp)),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Rosette(c.gold, Modifier.size(54.dp), stroke = 1.6.dp, spinning = true)
                Spacer(Modifier.height(16.dp))
                Text(text ?: "", style = KType.Subtitle, color = c.text, textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
fun Loader(modifier: Modifier = Modifier, color: Color? = null) {
    val c = LocalKColors.current
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = color ?: c.accent, strokeWidth = 2.5.dp, modifier = Modifier.size(34.dp))
    }
}
