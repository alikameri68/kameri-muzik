package com.hazar.kitaplik.player

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.hazar.kitaplik.playback.PlaybackService

/** Arayüzün oynatma servisine bağlandığı ve durumunu izlediği katman. */
@Stable
class PlayerConnection(
    private val context: Context,
    private val onEnded: (String) -> Unit,
    private val onPaused: () -> Unit,
) {
    var controller by mutableStateOf<MediaController?>(null)
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var isBuffering by mutableStateOf(false)
        private set
    var currentKey by mutableStateOf<String?>(null)
        private set
    var durationMs by mutableLongStateOf(0L)
        private set

    private var future: ListenableFuture<MediaController>? = null
    private var pending: (() -> Unit)? = null

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = sync(player)

        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_ENDED) {
                controller?.currentMediaItem?.mediaId?.let(onEnded)
            }
        }
    }

    val position: Long get() = controller?.currentPosition ?: 0L

    fun connect() {
        if (future != null) return
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val f = MediaController.Builder(context, token).buildAsync()
        future = f
        f.addListener(
            {
                val c = runCatching { f.get() }.getOrNull()
                if (c != null) {
                    controller = c
                    c.addListener(listener)
                    sync(c)
                    pending?.invoke()
                    pending = null
                }
            },
            ContextCompat.getMainExecutor(context),
        )
    }

    fun release() {
        controller?.removeListener(listener)
        future?.let { MediaController.releaseFuture(it) }
        future = null
        controller = null
    }

    private fun sync(player: Player) {
        val was = isPlaying
        isPlaying = player.isPlaying
        isBuffering = player.playbackState == Player.STATE_BUFFERING
        currentKey = player.currentMediaItem?.mediaId
        val d = player.duration
        durationMs = if (d == C.TIME_UNSET || d < 0) 0L else d
        if (was && !isPlaying) onPaused()
    }

    fun play(id: String, uri: Uri, title: String, artist: String, art: Uri?, startMs: Long, speed: Float) {
        val run = {
            val c = controller
            if (c != null) {
                val item = MediaItem.Builder()
                    .setMediaId(id)
                    .setUri(uri)
                    .setRequestMetadata(MediaItem.RequestMetadata.Builder().setMediaUri(uri).build())
                    .setMediaMetadata(
                        MediaMetadata.Builder()
                            .setTitle(title)
                            .setArtist(artist.ifEmpty { "Kamerî Kitaplık" })
                            .setArtworkUri(art)
                            .build()
                    )
                    .build()
                c.setMediaItem(item, startMs)
                c.setPlaybackSpeed(speed)
                c.volume = 1f
                c.prepare()
                c.play()
            }
        }
        if (controller == null) {
            pending = run
            connect()
        } else {
            run()
        }
    }

    fun toggle() {
        val c = controller ?: return
        if (c.isPlaying) {
            c.pause()
        } else {
            if (c.playbackState == Player.STATE_ENDED) c.seekTo(0L)
            if (c.playbackState == Player.STATE_IDLE) c.prepare()
            c.play()
        }
    }

    fun pause() {
        controller?.pause()
    }

    fun seekTo(ms: Long) {
        controller?.seekTo(ms.coerceAtLeast(0L))
    }

    fun seekBy(deltaMs: Long) {
        val c = controller ?: return
        val max = if (durationMs > 0) durationMs - 500 else Long.MAX_VALUE
        c.seekTo((c.currentPosition + deltaMs).coerceIn(0L, max.coerceAtLeast(0L)))
    }

    fun setSpeed(v: Float) {
        controller?.setPlaybackSpeed(v)
    }

    fun setVolume(v: Float) {
        controller?.volume = v
    }

    fun stop() {
        val c = controller ?: return
        c.stop()
        c.clearMediaItems()
    }
}
