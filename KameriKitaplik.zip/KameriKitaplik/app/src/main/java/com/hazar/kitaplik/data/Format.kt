package com.hazar.kitaplik.data

import java.util.Locale

val TR: Locale = Locale.forLanguageTag("tr")

/** Ortalama okuma hızı (karakter/dakika); kalan süre tahmini için. */
const val CHARS_PER_MIN = 1100

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val x = s % 60
    return if (h > 0) String.format(Locale.ROOT, "%d:%02d:%02d", h, m, x) else String.format(Locale.ROOT, "%d:%02d", m, x)
}

fun formatMinutes(min: Double): String {
    val m = Math.round(min).toInt()
    return when {
        m < 1 -> "1 dk'dan az"
        m < 60 -> "$m dk"
        m % 60 == 0 -> "${m / 60} sa"
        else -> "${m / 60} sa ${m % 60} dk"
    }
}

fun formatLeft(ms: Long): String = formatMinutes(ms / 60000.0) + " kaldı"

fun newId(prefix: String): String =
    prefix + java.lang.Long.toString(System.currentTimeMillis(), 36) + (1000..9999).random()

/** "Yazar - Başlık" biçimli dosya adlarını ayırır. */
fun splitName(fileName: String): Pair<String, String> {
    val base = fileName.substringBeforeLast('.').replace('_', ' ').trim()
    val parts = base.split(" - ", " – ", " — ")
    return if (parts.size == 2 && parts[0].isNotBlank() && parts[1].isNotBlank()) {
        parts[1].trim() to parts[0].trim()
    } else {
        base to ""
    }
}
