@file:OptIn(ExperimentalFoundationApi::class)

package com.hazar.kitaplik.ui

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hazar.kitaplik.MainViewModel
import com.hazar.kitaplik.data.Book
import com.hazar.kitaplik.ui.theme.KColors
import com.hazar.kitaplik.ui.theme.KType
import com.hazar.kitaplik.ui.theme.Motion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** PdfRenderer aynı anda tek sayfa açabildiği için bütün çizimler tek kilitten geçer. */
class PdfDoc private constructor(private val pfd: ParcelFileDescriptor, private val renderer: PdfRenderer) {
    private val lock = Any()
    private var closed = false
    val count: Int = renderer.pageCount

    fun render(index: Int, widthPx: Int): Bitmap? {
        synchronized(lock) {
            if (closed || index < 0 || index >= count) return null
            val page = renderer.openPage(index)
            try {
                val w = widthPx.coerceIn(200, 2200)
                val h = (w * page.height.toFloat() / page.width.coerceAtLeast(1)).toInt().coerceIn(200, 3200)
                val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(android.graphics.Color.WHITE)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                return bmp
            } finally {
                page.close()
            }
        }
    }

    fun close() {
        synchronized(lock) {
            if (!closed) {
                closed = true
                runCatching { renderer.close() }
                runCatching { pfd.close() }
            }
        }
    }

    companion object {
        fun open(f: File): PdfDoc? = runCatching {
            val pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
            try {
                PdfDoc(pfd, PdfRenderer(pfd))
            } catch (e: Exception) {
                pfd.close()
                throw e
            }
        }.getOrNull()
    }
}

/** Gece temalarında sayfa ters çevrilir (beyaz kâğıt koyulaşır), sepyada kâğıt sararır. */
private fun pageFilter(c: KColors): ColorFilter? = when {
    c.isDark -> ColorFilter.colorMatrix(
        ColorMatrix(
            floatArrayOf(
                -0.86f, 0f, 0f, 0f, 236f,
                0f, -0.86f, 0f, 0f, 234f,
                0f, 0f, -0.86f, 0f, 228f,
                0f, 0f, 0f, 1f, 0f,
            )
        )
    )
    c.bg.red > 0.93f && c.bg.blue < 0.82f -> ColorFilter.tint(Color(0xFFF1E4C8), BlendMode.Multiply)
    else -> null
}

@Composable
fun PdfReader(
    vm: MainViewModel,
    book: Book,
    rc: KColors,
    chrome: Boolean,
    onToggleChrome: () -> Unit,
    onClose: () -> Unit,
) {
    val doc = remember(book.id) { PdfDoc.open(vm.store.pdfFile(book.id)) }
    DisposableEffect(doc) { onDispose { doc?.close() } }
    if (doc == null || doc.count == 0) {
        Column(Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center) {
            Text("Bu PDF açılamadı", style = KType.Title, color = rc.text)
            Text("Dosya silinmiş ya da bozulmuş olabilir.", style = KType.Subtitle, color = rc.textSecondary)
        }
        return
    }
    val pager = rememberPagerState(initialPage = book.posCh.coerceIn(0, doc.count - 1)) { doc.count }
    val scope = rememberCoroutineScope()
    var zoomed by remember { mutableStateOf(false) }
    val filter = remember(rc) { pageFilter(rc) }

    LaunchedEffect(pager) {
        snapshotFlow { pager.settledPage }.collect { i ->
            zoomed = false
            vm.saveReadPos(book.id, i, 0, if (doc.count <= 1) 1f else i.toFloat() / (doc.count - 1))
        }
    }

    HorizontalPager(
        state = pager,
        beyondViewportPageCount = 1,
        userScrollEnabled = !zoomed,
        modifier = Modifier.fillMaxSize(),
    ) { i ->
        PdfPage(
            doc = doc,
            index = i,
            rc = rc,
            filter = filter,
            zoomed = zoomed && pager.currentPage == i,
            onZoom = { zoomed = it },
            onTap = { frac ->
                when {
                    chrome -> onToggleChrome()
                    zoomed -> {}
                    frac < 0.25f -> scope.launch { pager.animateScrollToPage((i - 1).coerceAtLeast(0)) }
                    frac > 0.75f -> scope.launch { pager.animateScrollToPage((i + 1).coerceAtMost(doc.count - 1)) }
                    else -> onToggleChrome()
                }
            },
            modifier = Modifier.pageTurn(pager, i),
        )
    }

    AnimatedVisibility(visible = chrome, enter = fadeIn(Motion.enter(200)), exit = fadeOut(Motion.exit(180)), modifier = Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize()) {
            var drag by remember { mutableFloatStateOf(-1f) }
            val shown = if (drag >= 0f) drag.toInt() else pager.currentPage
            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(rc.card.copy(alpha = 0.96f))
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
            ) {
                Text("Sayfa ${shown + 1} / ${doc.count}", style = KType.Time, color = rc.textSecondary)
                if (doc.count > 1) {
                    Slider(
                        value = shown.toFloat(),
                        onValueChange = { drag = it },
                        onValueChangeFinished = {
                            val t = drag.toInt().coerceIn(0, doc.count - 1)
                            drag = -1f
                            scope.launch { pager.scrollToPage(t) }
                        },
                        valueRange = 0f..(doc.count - 1).toFloat(),
                        colors = SliderDefaults.colors(thumbColor = rc.accent, activeTrackColor = rc.accent, inactiveTrackColor = rc.muted),
                    )
                }
            }
        }
    }
}

@Composable
private fun PdfPage(
    doc: PdfDoc,
    index: Int,
    rc: KColors,
    filter: ColorFilter?,
    zoomed: Boolean,
    onZoom: (Boolean) -> Unit,
    onTap: (Float) -> Unit,
    modifier: Modifier = Modifier,
) {
    var box by remember { mutableStateOf(IntSize.Zero) }
    val bmp by produceState<Bitmap?>(null, index, box.width) {
        if (box.width > 0) {
            value = withContext(Dispatchers.IO) { doc.render(index, (box.width * 1.6f).toInt()) }
        }
    }
    var pan by remember { mutableStateOf(Offset.Zero) }
    val scale by animateFloatAsState(if (zoomed) 2.3f else 1f, Motion.spring(), label = "zoom")
    LaunchedEffect(zoomed) { if (!zoomed) pan = Offset.Zero }

    Box(
        modifier
            .fillMaxSize()
            .background(rc.bg)
            .onSizeChanged { box = it }
            .pointerInput(zoomed) {
                detectTapGestures(
                    onDoubleTap = { o ->
                        if (!zoomed) {
                            // dokunulan yer ortaya gelsin
                            pan = Offset((size.width / 2f - o.x) * 1.3f, (size.height / 2f - o.y) * 1.3f)
                        }
                        onZoom(!zoomed)
                    },
                    onTap = { o -> onTap(o.x / size.width) },
                )
            }
            .then(
                if (zoomed) {
                    Modifier.pointerInput(Unit) {
                        detectDragGestures { change, drag ->
                            change.consume()
                            val maxX = size.width * 0.66f
                            val maxY = size.height * 0.66f
                            pan = Offset((pan.x + drag.x).coerceIn(-maxX, maxX), (pan.y + drag.y).coerceIn(-maxY, maxY))
                        }
                    }
                } else {
                    Modifier
                }
            ),
        contentAlignment = Alignment.Center,
    ) {
        val b = bmp
        if (b == null) {
            Loader(color = rc.accent)
        } else {
            val img = remember(b) { b.asImageBitmap() }
            Image(
                bitmap = img,
                contentDescription = "Sayfa ${index + 1}",
                contentScale = ContentScale.Fit,
                colorFilter = filter,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 6.dp, vertical = 10.dp)
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        translationX = pan.x * (scale - 1f) / 1.3f
                        translationY = pan.y * (scale - 1f) / 1.3f
                    },
            )
        }
        if (!zoomed) {
            Text(
                "${index + 1}",
                style = KType.Time.copy(fontSize = 10.sp),
                color = rc.textSecondary.copy(alpha = 0.6f),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 2.dp),
            )
        }
    }
}
