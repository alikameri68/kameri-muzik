package com.hazar.kitaplik

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.hazar.kitaplik.data.Book
import com.hazar.kitaplik.data.BookText
import com.hazar.kitaplik.data.Dictionary
import com.hazar.kitaplik.data.ImportError
import com.hazar.kitaplik.data.Importer
import com.hazar.kitaplik.data.Pod
import com.hazar.kitaplik.data.Prefs
import com.hazar.kitaplik.data.ReaderSettings
import com.hazar.kitaplik.data.Store
import com.hazar.kitaplik.data.TR
import com.hazar.kitaplik.player.PlayerConnection
import com.hazar.kitaplik.ui.theme.KTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainViewModel(app: Application) : AndroidViewModel(app) {

    val store = Store(app)
    private val prefs = Prefs(app)
    val dict = Dictionary()

    var books by mutableStateOf(store.loadBooks())
        private set
    var pods by mutableStateOf(store.loadPods())
        private set

    /** Uzun süren işin açıklaması (ekleme vb.); null ise iş yok. */
    var busy by mutableStateOf<String?>(null)
        private set
    var toast by mutableStateOf<String?>(null)
    var toastSeq by mutableIntStateOf(0)
        private set

    var dictReady by mutableStateOf(false)
        private set
    var dictVersion by mutableIntStateOf(0)
        private set

    var appTheme by mutableStateOf(prefs.appTheme())
        private set
    var reader by mutableStateOf(prefs.reader())
        private set

    var speed by mutableFloatStateOf(prefs.speed())
        private set
    var autoNext by mutableStateOf(prefs.autoNext())
        private set
    var sleepEndsAt by mutableLongStateOf(0L)
        private set
    var sleepAtEnd by mutableStateOf(false)
        private set
    private var sleepJob: Job? = null

    /** Son çalınan kayıt; uygulama yeniden açılınca küçük oynatıcıda gösterilir. */
    var lastPodId by mutableStateOf(prefs.lastPod())
        private set

    val player = PlayerConnection(app, onEnded = ::onEnded, onPaused = { savePosition() })

    init {
        player.connect()
        viewModelScope.launch(Dispatchers.IO) {
            dict.load(app, store.dictDir)
            withContext(Dispatchers.Main) {
                dictReady = true
                dictVersion++
            }
        }
        // çalarken kalınan yer birkaç saniyede bir kaydedilir
        viewModelScope.launch {
            while (isActive) {
                delay(4000)
                if (player.isPlaying) savePosition()
            }
        }
    }

    fun say(msg: String) {
        toast = msg
        toastSeq++
    }

    // ---------------- kitaplar ----------------

    fun importBooks(uris: List<Uri>) {
        if (busy != null || uris.isEmpty()) return
        viewModelScope.launch {
            var ok = 0
            var last: Book? = null
            val errors = ArrayList<String>()
            for ((i, u) in uris.withIndex()) {
                busy = (if (uris.size > 1) "${i + 1}/${uris.size} · " else "") + Importer.displayName(getApplication(), u) + " ekleniyor…"
                try {
                    val b = Importer.importBook(getApplication(), store, u)
                    books = listOf(b) + books
                    store.saveBooks(books)
                    ok++
                    last = b
                } catch (e: ImportError) {
                    errors += e.message ?: "eklenemedi"
                } catch (e: Exception) {
                    errors += (Importer.displayName(getApplication(), u) + " eklenemedi")
                }
            }
            busy = null
            say(
                when {
                    ok == 1 && errors.isEmpty() -> "“${last?.title}” eklendi"
                    ok > 0 && errors.isEmpty() -> "$ok kitap eklendi"
                    ok > 0 -> "$ok kitap eklendi · ${errors.size} dosya eklenemedi"
                    else -> errors.firstOrNull() ?: "Eklenemedi"
                }
            )
        }
    }

    suspend fun loadText(id: String): BookText? = withContext(Dispatchers.IO) { store.loadText(id) }

    fun book(id: String?): Book? = books.firstOrNull { it.id == id }

    private fun updateBook(id: String, persist: Boolean = true, f: (Book) -> Book) {
        books = books.map { if (it.id == id) f(it) else it }
        if (persist) viewModelScope.launch(Dispatchers.IO) { store.saveBooks(books) }
    }

    fun markOpened(id: String) = updateBook(id) { it.copy(opened = System.currentTimeMillis()) }

    fun saveReadPos(id: String, ch: Int, off: Int, progress: Float) = updateBook(id) {
        it.copy(posCh = ch, posOff = off, progress = progress.coerceIn(0f, 1f), done = it.done || progress >= 0.999f)
    }

    fun setDone(id: String, done: Boolean) = updateBook(id) { it.copy(done = done) }

    fun renameBook(id: String, title: String, author: String) = updateBook(id) {
        it.copy(title = title.trim().ifEmpty { it.title }, author = author.trim())
    }

    fun deleteBook(id: String) {
        val b = book(id) ?: return
        books = books.filterNot { it.id == id }
        viewModelScope.launch(Dispatchers.IO) {
            store.saveBooks(books)
            store.deleteBook(id)
        }
        say("“${b.title}” silindi")
    }

    fun coverOf(b: Book): File? = if (b.hasCover) store.coverFile(b.id).takeIf { it.exists() } else null

    // ---------------- ayarlar ----------------

    fun setTheme(t: KTheme) {
        appTheme = t
        prefs.saveAppTheme(t)
    }

    fun updateReader(r: ReaderSettings) {
        reader = r
        prefs.saveReader(r)
    }

    // ---------------- sözlük ----------------

    fun importDictionary(uri: Uri) {
        if (busy != null) return
        viewModelScope.launch {
            busy = "Sözlük hazırlanıyor…"
            try {
                val (name, count) = withContext(Dispatchers.IO) {
                    val txt = getApplication<Application>().contentResolver.openInputStream(uri)?.use { s ->
                        s.readBytes().toString(Charsets.UTF_8)
                    } ?: throw ImportError("Dosya açılamadı")
                    val fallback = Importer.displayName(getApplication(), uri).substringBeforeLast('.')
                    val d = dict.parse(txt, fallback, null) ?: throw ImportError("Dosyada sözlük maddesi bulunamadı (her satır “madde<TAB>anlam” olmalı)")
                    val safe = d.name.replace(Regex("[^\\p{L}\\p{N} .·-]"), "").take(60).ifEmpty { "sozluk" }
                    File(store.dictDir, "$safe.tsv").writeText(txt)
                    dict.load(getApplication(), store.dictDir)
                    d.name to d.heads.size
                }
                dictVersion++
                say("“$name” eklendi · ${String.format(TR, "%,d", count)} madde")
            } catch (e: ImportError) {
                say(e.message ?: "Sözlük eklenemedi")
            } catch (e: Exception) {
                say("Sözlük eklenemedi")
            }
            busy = null
        }
    }

    fun deleteDictionary(file: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                File(store.dictDir, file).delete()
                dict.load(getApplication(), store.dictDir)
            }
            dictVersion++
            say("Sözlük kaldırıldı")
        }
    }

    // ---------------- dinle ----------------

    fun importAudio(uris: List<Uri>) {
        if (busy != null || uris.isEmpty()) return
        viewModelScope.launch {
            var ok = 0
            var last: Pod? = null
            val errors = ArrayList<String>()
            for ((i, u) in uris.withIndex()) {
                busy = (if (uris.size > 1) "${i + 1}/${uris.size} · " else "") + Importer.displayName(getApplication(), u) + " ekleniyor…"
                try {
                    val p = Importer.importAudio(getApplication(), store, u)
                    pods = listOf(p) + pods
                    store.savePods(pods)
                    ok++
                    last = p
                } catch (e: ImportError) {
                    errors += e.message ?: "eklenemedi"
                } catch (e: Exception) {
                    errors += (Importer.displayName(getApplication(), u) + " eklenemedi")
                }
            }
            busy = null
            say(
                when {
                    ok == 1 && errors.isEmpty() -> "“${last?.title}” eklendi"
                    ok > 0 && errors.isEmpty() -> "$ok ses eklendi"
                    ok > 0 -> "$ok ses eklendi · ${errors.size} dosya eklenemedi"
                    else -> errors.firstOrNull() ?: "Eklenemedi"
                }
            )
        }
    }

    fun pod(id: String?): Pod? = pods.firstOrNull { it.id == id }

    /** Küçük oynatıcıda gösterilecek kayıt: çalan ya da en son çalınan. */
    val shownPod: Pod? get() = pod(player.currentKey) ?: pod(lastPodId)

    private fun updatePod(id: String, persist: Boolean = true, f: (Pod) -> Pod) {
        pods = pods.map { if (it.id == id) f(it) else it }
        if (persist) viewModelScope.launch(Dispatchers.IO) { store.savePods(pods) }
    }

    fun savePosition() {
        val id = player.currentKey ?: return
        val pos = player.position
        val dur = player.durationMs
        updatePod(id) { p ->
            p.copy(
                posMs = pos,
                played = System.currentTimeMillis(),
                durationMs = if (dur > 0) dur else p.durationMs,
            )
        }
    }

    fun audioFile(p: Pod) = File(store.audioDir, p.file)

    fun coverOfPod(p: Pod): File? = if (p.hasCover) store.coverFile(p.id).takeIf { it.exists() } else null

    fun playPod(p: Pod) {
        if (player.currentKey == p.id) {
            player.toggle()
            return
        }
        savePosition()
        val f = audioFile(p)
        if (!f.exists()) {
            say("Ses dosyası bu cihazda bulunamadı")
            return
        }
        val fresh = p.done || (p.durationMs > 0 && p.posMs >= p.durationMs - 3000)
        // uzun aradan sonra birkaç saniye geriden başlar; cümlenin başı kaçmasın
        val back = if (p.posMs > 10_000 && p.played > 0 && System.currentTimeMillis() - p.played > 10 * 60_000) 4000L else 0L
        val start = if (fresh) 0L else (p.posMs - back).coerceAtLeast(0L)
        if (fresh) updatePod(p.id) { it.copy(done = false, posMs = 0L) }
        val art = if (p.hasCover) store.coverFile(p.id).takeIf { it.exists() }?.let { Uri.fromFile(it) } else null
        player.play(p.id, Uri.fromFile(f), p.title, p.artist, art, start, speed)
        lastPodId = p.id
        prefs.saveLastPod(p.id)
    }

    fun togglePod() {
        val id = player.currentKey
        if (id != null) {
            player.toggle()
        } else {
            shownPod?.let { playPod(it) }
        }
    }

    fun seekPod(ms: Long) {
        if (player.currentKey == null) {
            val p = shownPod ?: return
            updatePod(p.id) { it.copy(posMs = ms) }
            return
        }
        player.seekTo(ms)
    }

    fun skip(deltaMs: Long) {
        if (player.currentKey == null) {
            val p = shownPod ?: return
            updatePod(p.id) { it.copy(posMs = (it.posMs + deltaMs).coerceIn(0L, maxOf(0L, it.durationMs - 500))) }
            return
        }
        player.seekBy(deltaMs)
    }

    fun changeSpeed(v: Float) {
        speed = v
        prefs.saveSpeed(v)
        player.setSpeed(v)
    }

    fun changeAutoNext(v: Boolean) {
        autoNext = v
        prefs.saveAutoNext(v)
    }

    fun closePlayer() {
        savePosition()
        player.stop()
        setSleep(0)
        lastPodId = null
        prefs.saveLastPod(null)
    }

    fun setPodDone(id: String, done: Boolean) = updatePod(id) { it.copy(done = done, posMs = if (done) it.posMs else 0L) }

    fun restartPod(id: String) {
        updatePod(id) { it.copy(done = false, posMs = 0L) }
        if (player.currentKey == id) {
            player.seekTo(0L)
            if (!player.isPlaying) player.toggle()
        } else {
            pod(id)?.let { playPod(it) }
        }
    }

    fun renamePod(id: String, title: String, artist: String) = updatePod(id) {
        it.copy(title = title.trim().ifEmpty { it.title }, artist = artist.trim())
    }

    fun deletePod(id: String) {
        val p = pod(id) ?: return
        if (player.currentKey == id) {
            player.stop()
            setSleep(0)
        }
        if (lastPodId == id) {
            lastPodId = null
            prefs.saveLastPod(null)
        }
        pods = pods.filterNot { it.id == id }
        viewModelScope.launch(Dispatchers.IO) {
            store.savePods(pods)
            audioFile(p).delete()
            store.coverFile(id).delete()
        }
        say("“${p.title}” silindi")
    }

    private fun onEnded(id: String) {
        updatePod(id) { it.copy(done = true, posMs = 0L, played = System.currentTimeMillis()) }
        if (sleepAtEnd) {
            setSleep(0)
            say("Bölüm bitti; uyku zamanlayıcısı durdurdu")
            return
        }
        if (!autoNext) return
        val i = pods.indexOfFirst { it.id == id }
        val next = pods.drop(i + 1).firstOrNull { !it.done }
        if (next != null) {
            say("Sıradaki: ${next.title}")
            playPod(next)
        }
    }

    /** dakika > 0: süreli; -1: bölüm sonunda; 0: kapalı */
    fun setSleep(minutes: Int) {
        sleepJob?.cancel()
        sleepJob = null
        sleepEndsAt = 0L
        sleepAtEnd = false
        player.setVolume(1f)
        when {
            minutes == -1 -> sleepAtEnd = true
            minutes > 0 -> {
                sleepEndsAt = System.currentTimeMillis() + minutes * 60_000L
                sleepJob = viewModelScope.launch {
                    while (isActive) {
                        val left = sleepEndsAt - System.currentTimeMillis()
                        if (left <= 0) break
                        if (left < 8000) player.setVolume((left / 8000f).coerceAtLeast(0.05f))
                        delay(minOf(left, 400L))
                    }
                    player.pause()
                    player.setVolume(1f)
                    sleepEndsAt = 0L
                    say("Uyku zamanlayıcısı sesi durdurdu")
                }
            }
        }
    }

    override fun onCleared() {
        savePosition()
        player.release()
    }
}
