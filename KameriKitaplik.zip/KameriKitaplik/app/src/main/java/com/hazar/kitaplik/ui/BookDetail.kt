package com.hazar.kitaplik.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AutoStories
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hazar.kitaplik.MainViewModel
import com.hazar.kitaplik.data.Book
import com.hazar.kitaplik.data.BookText
import com.hazar.kitaplik.data.CHARS_PER_MIN
import com.hazar.kitaplik.data.formatMinutes
import com.hazar.kitaplik.ui.theme.KType
import com.hazar.kitaplik.ui.theme.LocalKColors
import kotlinx.coroutines.delay

/** Kitap sayfası: büyük kapak, kapak renginden zemin, dört bilgi kutusu, içindekiler. */
@Composable
fun BookDetail(vm: MainViewModel, book: Book, onClose: () -> Unit, onRead: (Int?) -> Unit) {
    val c = LocalKColors.current
    val (tint, _) = tintOf(book.id)
    val text by produceState<BookText?>(null, book.id) {
        if (!book.isPdf) value = vm.loadText(book.id)
    }
    var editing by remember { mutableStateOf(false) }
    var armed by remember { mutableStateOf(false) }
    LaunchedEffect(armed) {
        if (armed) {
            delay(3000)
            armed = false
        }
    }
    BackHandler(enabled = editing) { editing = false }

    Box(
        Modifier
            .fillMaxSize()
            .background(c.bg)
            .background(Brush.verticalGradient(0f to tint.copy(alpha = if (c.isDark) 0.45f else 0.30f), 0.45f to c.bg)),
    ) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 40.dp),
        ) {
            item {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                        RoundIcon(Icons.AutoMirrored.Rounded.ArrowBack, "Geri", background = c.card.copy(alpha = 0.8f)) { onClose() }
                        Spacer(Modifier.weight(1f))
                        RoundIcon(Icons.Rounded.Edit, "Adı düzenle", background = c.card.copy(alpha = 0.8f)) { editing = !editing }
                    }
                    Spacer(Modifier.height(8.dp))
                    BookCover(book.id, book.title, vm.coverOf(book), Modifier.width(176.dp), titleSize = 17.sp, elevation = 26.dp)
                    Spacer(Modifier.height(22.dp))
                    if (editing) {
                        EditFields(book.title, book.author) { t, a ->
                            vm.renameBook(book.id, t, a)
                            editing = false
                        }
                    } else {
                        Text(book.title, style = KType.Display.copy(fontSize = 25.sp, lineHeight = 31.sp), color = c.text, textAlign = TextAlign.Center)
                        if (book.author.isNotEmpty()) {
                            Spacer(Modifier.height(4.dp))
                            Text(book.author, style = KType.Subtitle.copy(fontWeight = FontWeight(600)), color = c.textSecondary, textAlign = TextAlign.Center)
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                    Stats(book)
                    Spacer(Modifier.height(18.dp))
                    MainButton(
                        when {
                            book.done -> "Yeniden oku"
                            book.progress > 0.005f -> "Okumaya devam et · %${(book.progress * 100).toInt()}"
                            else -> "Okumaya başla"
                        },
                        Icons.Rounded.AutoStories,
                        Modifier.fillMaxWidth(),
                    ) {
                        if (book.done) {
                            vm.setDone(book.id, false)
                            onRead(0)
                        } else {
                            onRead(null)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        GhostButton(
                            if (book.done) "Okunmadı yap" else "Bitti yap",
                            Icons.Rounded.Check,
                            modifier = Modifier.weight(1f),
                        ) { vm.setDone(book.id, !book.done) }
                        GhostButton(
                            if (armed) "Bir daha dokun" else "Sil",
                            Icons.Rounded.Delete,
                            color = if (armed) Color.White else c.rust,
                            modifier = Modifier
                                .weight(1f)
                                .then(if (armed) Modifier.clip(RoundedCornerShape(16.dp)).background(c.rust) else Modifier),
                        ) {
                            if (armed) {
                                onClose()
                                vm.deleteBook(book.id)
                            } else {
                                armed = true
                            }
                        }
                    }
                    Spacer(Modifier.height(26.dp))
                }
            }
            val t = text
            if (t != null) {
                item {
                    SectionHeader("İçindekiler", "${t.chapters.size} bölüm", Modifier.padding(horizontal = 20.dp))
                    Spacer(Modifier.height(10.dp))
                }
                itemsIndexed(t.chapters) { i, ch ->
                    val cur = i == book.posCh && book.progress > 0f
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (cur) c.accentSoft else Color.Transparent)
                            .pressable({ onRead(i) }, 0.98f)
                            .padding(horizontal = 12.dp, vertical = 13.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            "${i + 1}".padStart(2, '0'),
                            style = KType.Time,
                            color = if (cur) c.accent else c.textSecondary,
                            modifier = Modifier.width(34.dp),
                        )
                        Text(
                            ch.title,
                            style = KType.RowTitle.copy(fontWeight = FontWeight(if (cur) 800 else 600)),
                            color = if (cur) c.accent else c.text,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f),
                        )
                        val mins = ch.paras.sumOf { it.text.length } / CHARS_PER_MIN.toDouble()
                        Text(formatMinutes(mins), style = KType.Small, color = c.textSecondary)
                    }
                }
            }
            item { Spacer(Modifier.navigationBarsPadding()) }
        }
    }
}

@Composable
private fun Stats(b: Book) {
    val c = LocalKColors.current
    val cells = listOf(
        (if (b.done) "✓" else "%${(b.progress * 100).toInt()}") to (if (b.done) "Bitti" else "Okundu"),
        (if (b.isPdf) "${b.pages}" else "${b.chapters}") to (if (b.isPdf) "Sayfa" else "Bölüm"),
        (if (b.isPdf || b.chars == 0L) "—" else formatMinutes((1 - b.progress) * b.chars / CHARS_PER_MIN.toDouble())) to "Kalan",
        (if (b.isPdf) "PDF" else b.kind.uppercase()) to "Biçim",
    )
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        cells.forEach { (v, l) ->
            Column(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(c.card.copy(alpha = 0.85f))
                    .border(1.dp, c.border, RoundedCornerShape(16.dp))
                    .padding(vertical = 11.dp, horizontal = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(v, style = KType.Section.copy(fontSize = 16.sp), color = c.text, maxLines = 1)
                Spacer(Modifier.height(2.dp))
                Text(l.uppercase(com.hazar.kitaplik.data.TR), style = KType.Caps.copy(fontSize = 9.sp), color = c.textSecondary)
            }
        }
    }
}

@Composable
private fun EditFields(title: String, author: String, onSave: (String, String) -> Unit) {
    var t by remember { mutableStateOf(title) }
    var a by remember { mutableStateOf(author) }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(t, { t = it }, label = { Text("Başlık") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next))
        OutlinedTextField(a, { a = it }, label = { Text("Yazar") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done))
        MainButton("Kaydet", Icons.Rounded.Check, Modifier.fillMaxWidth()) { onSave(t, a) }
    }
}
