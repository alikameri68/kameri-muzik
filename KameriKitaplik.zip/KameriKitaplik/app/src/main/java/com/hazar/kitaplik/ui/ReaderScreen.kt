@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.hazar.kitaplik.ui

import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.List
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFontFamilyResolver
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.Hyphens
import androidx.compose.ui.text.style.LineBreak
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.hazar.kitaplik.MainViewModel
import com.hazar.kitaplik.data.Book
import com.hazar.kitaplik.data.BookText
import com.hazar.kitaplik.data.ReaderSettings
import com.hazar.kitaplik.data.TR
import com.hazar.kitaplik.ui.theme.Amiri
import com.hazar.kitaplik.ui.theme.Jakarta
import com.hazar.kitaplik.ui.theme.KColors
import com.hazar.kitaplik.ui.theme.KTheme
import com.hazar.kitaplik.ui.theme.KType
import com.hazar.kitaplik.ui.theme.Literata
import com.hazar.kitaplik.ui.theme.LocalKColors
import com.hazar.kitaplik.ui.theme.Lora
import com.hazar.kitaplik.ui.theme.Motion
import com.hazar.kitaplik.ui.theme.NotoNaskh
import com.hazar.kitaplik.ui.theme.colorsOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

fun readerTheme(r: ReaderSettings): KTheme = runCatching { KTheme.valueOf(r.theme) }.getOrDefault(KTheme.CREAM)

@Composable
fun ReaderScreen(vm: MainViewModel, book: Book, onClose: () -> Unit) {
    val rs = vm.reader
    val rc = colorsOf(readerTheme(rs))
    var chrome by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showToc by remember { mutableStateOf(false) }
    var word by remember { mutableStateOf<String?>(null) }

    Immersive()
    BackHandler {
        if (chrome) chrome = false else onClose()
    }

    CompositionLocalProvider(LocalKColors provides rc) {
        Box(
            Modifier
                .fillMaxSize()
                .background(rc.bg),
        ) {
            if (book.isPdf) {
                PdfReader(vm, book, rc, chrome, onToggleChrome = { chrome = !chrome }, onClose = onClose)
            } else {
                TextReader(
                    vm = vm,
                    book = book,
                    rs = rs,
                    rc = rc,
                    chrome = chrome,
                    showToc = showToc,
                    onToggleChrome = { chrome = !chrome },
                    onWord = { word = it },
                    onCloseToc = { showToc = false },
                )
            }

            ReaderChrome(
                visible = chrome,
                title = book.title,
                isPdf = book.isPdf,
                onBack = onClose,
                onToc = { showToc = true },
                onSettings = { showSettings = true },
            )
        }

        if (showSettings) {
            ModalBottomSheet(
                onDismissRequest = { showSettings = false },
                sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
                containerColor = rc.card,
            ) {
                ReaderSettingsSheet(rs, book.isPdf) { vm.updateReader(it) }
            }
        }
        word?.let { w ->
            ModalBottomSheet(
                onDismissRequest = { word = null },
                sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
                containerColor = rc.card,
            ) {
                WordCard(vm, w)
            }
        }
    }
}

/** Okurken durum ve gezinme çubukları gizlenir, ekran kararmaz. */
@Composable
private fun Immersive() {
    val view = LocalView.current
    val context = LocalContext.current
    DisposableEffect(Unit) {
        val window = context.findActivity()?.window
        val ctl = window?.let { WindowCompat.getInsetsController(it, view) }
        ctl?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        ctl?.hide(WindowInsetsCompat.Type.systemBars())
        window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose {
            ctl?.show(WindowInsetsCompat.Type.systemBars())
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }
}

@Composable
private fun ReaderChrome(
    visible: Boolean,
    title: String,
    isPdf: Boolean,
    onBack: () -> Unit,
    onToc: () -> Unit,
    onSettings: () -> Unit,
) {
    val c = LocalKColors.current
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(Motion.enter(200)) + slideInVertically(Motion.enter(320)) { -it },
        exit = fadeOut(Motion.exit(180)) + slideOutVertically(Motion.exit(220)) { -it },
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(c.card, c.card.copy(alpha = 0.92f))))
                .statusBarsPadding()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            RoundIcon(Icons.AutoMirrored.Rounded.ArrowBack, "Kitaplığa dön") { onBack() }
            Spacer(Modifier.width(10.dp))
            Text(title, style = KType.RowTitle, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            if (!isPdf) {
                RoundIcon(Icons.AutoMirrored.Rounded.List, "İçindekiler") { onToc() }
                Spacer(Modifier.width(8.dp))
            }
            RoundIcon(Icons.Rounded.TextFields, "Okuma ayarları") { onSettings() }
        }
    }
}

/** Sayfa çevirme: yeni sayfa eskisinin üstüne kayar, kenarında gölge; alttaki sayfa yerinde kalıp kararır. */
fun Modifier.pageTurn(pager: PagerState, index: Int): Modifier = this
    .graphicsLayer {
        val off = (pager.currentPage - index) + pager.currentPageOffsetFraction
        when {
            off >= 1f || off <= -1f -> alpha = if (off <= -1f) 1f else 0f
            off > 0f -> translationX = off * size.width
            off < 0f -> {
                transformOrigin = TransformOrigin(0f, 0.5f)
                rotationY = (-off) * 7f
                cameraDistance = 16f * density
            }
        }
    }
    .drawWithContent {
        drawContent()
        val off = (pager.currentPage - index) + pager.currentPageOffsetFraction
        if (off > 0f && off < 1f) {
            drawRect(Color.Black.copy(alpha = 0.32f * off))
        } else if (off < 0f && off > -1f) {
            val w = 26.dp.toPx()
            drawRect(
                Brush.horizontalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.22f)), startX = -w, endX = 0f),
                topLeft = Offset(-w, 0f),
                size = Size(w, size.height),
            )
        }
    }

private fun readerStyles(rs: ReaderSettings, c: KColors): ReaderStyles {
    val family = when (rs.font) {
        "lora" -> Lora
        "jakarta" -> Jakarta
        else -> Literata
    }
    val size = rs.size.sp
    val lh = (rs.size * rs.lineHeight).sp
    val lhStyle = LineHeightStyle(LineHeightStyle.Alignment.Center, LineHeightStyle.Trim.None)
    val body = TextStyle(
        fontFamily = family,
        fontWeight = FontWeight(400),
        fontSize = size,
        lineHeight = lh,
        color = c.text,
        textAlign = if (rs.justify) TextAlign.Justify else TextAlign.Start,
        lineHeightStyle = lhStyle,
        lineBreak = LineBreak.Simple,
        hyphens = Hyphens.None,
        textDirection = TextDirection.Content,
    )
    val heading = body.copy(
        fontFamily = Literata,
        fontWeight = FontWeight(600),
        fontSize = (rs.size * 1.28f).sp,
        lineHeight = (rs.size * 1.28f * 1.3f).sp,
        textAlign = TextAlign.Center,
        color = c.text,
    )
    val arabic = body.copy(
        fontFamily = if (rs.arabicFont == "naskh") NotoNaskh else Amiri,
        fontSize = (rs.size * 1.22f).sp,
        lineHeight = (rs.size * 1.22f * maxOf(rs.lineHeight, 1.9f)).sp,
        textAlign = TextAlign.Start,
        textDirection = TextDirection.Rtl,
    )
    return ReaderStyles(body, heading, arabic, paraGap = (rs.size * 0.62f).dp, headGap = (rs.size * 1.5f).dp)
}

@Composable
private fun TextReader(
    vm: MainViewModel,
    book: Book,
    rs: ReaderSettings,
    rc: KColors,
    chrome: Boolean,
    showToc: Boolean,
    onToggleChrome: () -> Unit,
    onWord: (String) -> Unit,
    onCloseToc: () -> Unit,
) {
    val text by produceState<BookText?>(null, book.id) { value = vm.loadText(book.id) }
    val t = text
    if (t == null) {
        Loader(color = rc.accent)
        return
    }
    val density = LocalDensity.current
    val resolver = LocalFontFamilyResolver.current
    val dir = LocalLayoutDirection.current
    val styles = remember(rs, rc) { readerStyles(rs, rc) }
    val cutTop = WindowInsets.displayCutout.asPaddingValues().calculateTopPadding()
    val padH = if (rs.size > 22f) 20.dp else 26.dp
    val padTop = maxOf(cutTop, 0.dp) + 44.dp
    val padBottom = 40.dp

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val pw = with(density) { (maxWidth - padH * 2).roundToPx() }
        val ph = with(density) { (maxHeight - padTop - padBottom).roundToPx() }
        val pages by produceState<List<Page>?>(null, t, pw, ph, styles) {
            value = null
            value = try {
                withContext(Dispatchers.Default) {
                    paginate(t, TextMeasurer(resolver, density, dir, 0), styles, pw, ph, density)
                }
            } catch (e: Exception) {
                paginate(t, TextMeasurer(resolver, density, dir, 0), styles, pw, ph, density)
            }
        }
        val list = pages
        if (list == null || list.isEmpty()) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Rosette(rc.gold, Modifier.size(56.dp), stroke = 1.5.dp, spinning = true)
                Spacer(Modifier.height(14.dp))
                Text("Sayfalar diziliyor…", style = KType.Subtitle, color = rc.textSecondary)
            }
        } else {
            key(list) {
                PagedBook(
                    vm = vm,
                    book = book,
                    text = t,
                    pages = list,
                    styles = styles,
                    rc = rc,
                    padH = padH,
                    padTop = padTop,
                    padBottom = padBottom,
                    chrome = chrome,
                    showToc = showToc,
                    onToggleChrome = onToggleChrome,
                    onWord = onWord,
                    onCloseToc = onCloseToc,
                )
            }
        }
    }
}

@Composable
private fun PagedBook(
    vm: MainViewModel,
    book: Book,
    text: BookText,
    pages: List<Page>,
    styles: ReaderStyles,
    rc: KColors,
    padH: androidx.compose.ui.unit.Dp,
    padTop: androidx.compose.ui.unit.Dp,
    padBottom: androidx.compose.ui.unit.Dp,
    chrome: Boolean,
    showToc: Boolean,
    onToggleChrome: () -> Unit,
    onWord: (String) -> Unit,
    onCloseToc: () -> Unit,
) {
    val start = remember { findPage(pages, book.posCh, book.posOff) }
    val pager = rememberPagerState(initialPage = start) { pages.size }
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current

    LaunchedEffect(pager) {
        snapshotFlow { pager.settledPage }.collect { i ->
            val p = pages[i]
            val prog = if (pages.size <= 1) 1f else i.toFloat() / (pages.size - 1)
            vm.saveReadPos(book.id, p.ch, p.off, prog)
        }
    }

    val go: (Int) -> Unit = { delta ->
        val target = (pager.currentPage + delta).coerceIn(0, pages.size - 1)
        if (target != pager.currentPage) scope.launch { pager.animateScrollToPage(target) }
    }
    val onTap: (Float) -> Unit = { frac ->
        when {
            chrome -> onToggleChrome()
            frac < 0.28f -> go(-1)
            frac > 0.72f -> go(1)
            else -> onToggleChrome()
        }
    }

    HorizontalPager(
        state = pager,
        beyondViewportPageCount = 1,
        modifier = Modifier.fillMaxSize(),
    ) { i ->
        val page = pages[i]
        Box(
            Modifier
                .fillMaxSize()
                .pageTurn(pager, i)
                .background(rc.bg)
                .pointerInput(i) {
                    detectTapGestures(onTap = { o -> onTap(o.x / size.width) })
                },
        ) {
            // üst bilgi: bölüm adı; alt bilgi: sayfa numarası
            Text(
                text.chapters[page.ch].title.uppercase(TR),
                style = KType.Caps.copy(fontSize = 9.5.sp, letterSpacing = 1.4.sp),
                color = rc.textSecondary.copy(alpha = 0.75f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = padTop - 30.dp, start = 48.dp, end = 48.dp),
            )
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(start = padH, end = padH, top = padTop, bottom = padBottom),
            ) {
                var prev: Slice? = null
                for (s in page.slices) {
                    val gap = gapBefore(prev, s, styles)
                    if (gap.value > 0f) Spacer(Modifier.height(gap))
                    prev = s
                    key(s.para, s.start) {
                        SliceText(text, s, styles, onTap = onTap, onLongPress = { w ->
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            onWord(w)
                        })
                    }
                }
            }
            Text(
                "${i + 1} / ${pages.size}",
                style = KType.Time.copy(fontSize = 11.sp),
                color = rc.textSecondary.copy(alpha = 0.7f),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 14.dp),
            )
        }
    }

    // sayfa kaydırıcı
    AnimatedVisibility(
        visible = chrome,
        enter = fadeIn(Motion.enter(200)) + slideInVertically(Motion.enter(320)) { it },
        exit = fadeOut(Motion.exit(180)) + slideOutVertically(Motion.exit(220)) { it },
        modifier = Modifier.fillMaxSize(),
    ) {
        Box(Modifier.fillMaxSize()) {
            var drag by remember { mutableFloatStateOf(-1f) }
            val shown = if (drag >= 0f) drag.toInt() else pager.currentPage
            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(rc.card.copy(alpha = 0.96f))
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text.chapters[pages[shown.coerceIn(0, pages.size - 1)].ch].title,
                        style = KType.Label,
                        color = rc.text,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    Text("s. ${shown + 1} / ${pages.size}", style = KType.Time, color = rc.textSecondary)
                }
                if (pages.size > 1) {
                    Slider(
                        value = shown.toFloat(),
                        onValueChange = { drag = it },
                        onValueChangeFinished = {
                            val target = drag.toInt().coerceIn(0, pages.size - 1)
                            drag = -1f
                            scope.launch { pager.scrollToPage(target) }
                        },
                        valueRange = 0f..(pages.size - 1).toFloat(),
                        colors = SliderDefaults.colors(
                            thumbColor = rc.accent,
                            activeTrackColor = rc.accent,
                            inactiveTrackColor = rc.muted,
                        ),
                    )
                }
            }
        }
    }

    if (showToc) {
        ModalBottomSheet(
            onDismissRequest = onCloseToc,
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = false),
            containerColor = rc.card,
        ) {
            val curCh = pages[pager.currentPage].ch
            val listState = rememberLazyListState(initialFirstVisibleItemIndex = (curCh - 2).coerceAtLeast(0))
            Text("İçindekiler", style = KType.Title, color = rc.text, modifier = Modifier.padding(start = 24.dp, bottom = 10.dp))
            LazyColumn(state = listState, modifier = Modifier.fillMaxWidth()) {
                itemsIndexed(text.chapters) { ci, ch ->
                    val on = ci == curCh
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (on) rc.accentSoft else Color.Transparent)
                            .pressable({
                                val target = pages.indexOfFirst { it.ch == ci }.coerceAtLeast(0)
                                scope.launch { pager.scrollToPage(target) }
                                onCloseToc()
                            }, 0.98f)
                            .padding(horizontal = 14.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("${ci + 1}".padStart(2, '0'), style = KType.Time, color = if (on) rc.accent else rc.textSecondary, modifier = Modifier.width(34.dp))
                        Text(
                            ch.title,
                            style = KType.RowTitle.copy(fontWeight = FontWeight(if (on) 800 else 600)),
                            color = if (on) rc.accent else rc.text,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f),
                        )
                        val firstPage = pages.indexOfFirst { it.ch == ci }
                        if (firstPage >= 0) Text("s. ${firstPage + 1}", style = KType.Small, color = rc.textSecondary)
                    }
                }
                item { Spacer(Modifier.navigationBarsPadding().height(16.dp)) }
            }
        }
    }
}

@Composable
private fun SliceText(text: BookText, s: Slice, styles: ReaderStyles, onTap: (Float) -> Unit, onLongPress: (String) -> Unit) {
    val para = text.chapters[s.ch].paras[s.para]
    val str = remember(s) { para.text.substring(s.start, s.end).trimEnd() }
    val style = remember(s, styles) { styleFor(para, styles) }
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
    Text(
        str,
        style = style,
        onTextLayout = { layout = it },
        modifier = Modifier
            .fillMaxWidth()
            .pointerInput(str) {
                detectTapGestures(
                    onTap = { o -> onTap(o.x / size.width) },
                    onLongPress = { o ->
                        val l = layout
                        if (l != null) {
                            val off = l.getOffsetForPosition(o)
                            com.hazar.kitaplik.data.Dictionary.wordAt(str, off)?.let(onLongPress)
                        }
                    },
                )
            },
    )
}

@Composable
private fun ReaderSettingsSheet(rs: ReaderSettings, isPdf: Boolean, onChange: (ReaderSettings) -> Unit) {
    val c = LocalKColors.current
    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp)
            .padding(bottom = 28.dp)
            .navigationBarsPadding(),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Okuma ayarları", style = KType.Title, color = c.text)
        SettingLabel("Sayfa rengi")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            KTheme.entries.forEach { t ->
                val tc = colorsOf(t)
                val on = rs.theme == t.name
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.pressable({ onChange(rs.copy(theme = t.name)) }, 0.94f)) {
                    Box(
                        Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(tc.bg)
                            .then(
                                if (on) Modifier.background(Color.Transparent) else Modifier
                            ),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("Aa", style = KType.Label.copy(fontFamily = Literata, fontSize = 16.sp), color = tc.text)
                        if (on) {
                            Box(
                                Modifier
                                    .fillMaxSize()
                                    .padding(2.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.Transparent)
                                    .then(Modifier.drawWithContent {
                                        drawContent()
                                        drawRoundRect(
                                            color = c.accent,
                                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(12.dp.toPx()),
                                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.5.dp.toPx()),
                                        )
                                    }),
                            )
                        }
                    }
                    Spacer(Modifier.height(5.dp))
                    Text(t.label, style = KType.Small, color = if (on) c.accent else c.textSecondary)
                }
            }
        }
        if (!isPdf) {
            SettingLabel("Yazı tipi")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("literata" to "Kitap", "lora" to "Klasik", "jakarta" to "Sade").forEach { (k, l) ->
                    KChip(l, selected = rs.font == k) { onChange(rs.copy(font = k)) }
                }
            }
            SettingLabel("Yazı boyu · ${rs.size.toInt()}")
            Slider(
                value = rs.size,
                onValueChange = { onChange(rs.copy(size = Math.round(it).toFloat())) },
                valueRange = 14f..32f,
                steps = 17,
                colors = SliderDefaults.colors(thumbColor = c.accent, activeTrackColor = c.accent, inactiveTrackColor = c.muted),
            )
            SettingLabel("Satır aralığı · ${String.format(TR, "%.2f", rs.lineHeight)}")
            Slider(
                value = rs.lineHeight,
                onValueChange = { onChange(rs.copy(lineHeight = Math.round(it * 20f) / 20f)) },
                valueRange = 1.3f..2.2f,
                colors = SliderDefaults.colors(thumbColor = c.accent, activeTrackColor = c.accent, inactiveTrackColor = c.muted),
            )
            SettingLabel("Arapça yazı tipi")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                KChip("Amiri · ابجد", selected = rs.arabicFont != "naskh") { onChange(rs.copy(arabicFont = "amiri")) }
                KChip("Naskh · ابجد", selected = rs.arabicFont == "naskh") { onChange(rs.copy(arabicFont = "naskh")) }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("İki yana yasla", style = KType.RowTitle, color = c.text)
                    Text("Satırlar sayfanın iki kenarına hizalanır", style = KType.Small, color = c.textSecondary)
                }
                Switch(
                    checked = rs.justify,
                    onCheckedChange = { onChange(rs.copy(justify = it)) },
                    colors = SwitchDefaults.colors(checkedTrackColor = c.accent),
                )
            }
        }
    }
}

@Composable
fun SettingLabel(text: String) {
    val c = LocalKColors.current
    Text(text.uppercase(TR), style = KType.Caps, color = c.textSecondary)
}
