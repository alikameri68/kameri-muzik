package com.hazar.kitaplik.ui

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import com.hazar.kitaplik.data.BookText
import com.hazar.kitaplik.data.Para

/** Bir sayfadaki paragraf parçası: [start, end) aralığı. */
data class Slice(val ch: Int, val para: Int, val start: Int, val end: Int, val heading: Boolean)

/** Bir sayfa; [off] bölüm içindeki ilk karakterin konumu (kalınan yer bununla saklanır). */
class Page(val ch: Int, val off: Int, val slices: List<Slice>)

class ReaderStyles(
    val body: TextStyle,
    val heading: TextStyle,
    val arabic: TextStyle,
    val paraGap: Dp,
    val headGap: Dp,
)

fun isArabicText(t: String): Boolean {
    var ar = 0
    var lat = 0
    for (ch in t) {
        if (ch in '؀'..'ۿ' || ch in 'ﭐ'..'﷿' || ch in 'ﹰ'..'﻿') ar++ else if (ch.isLetter()) lat++
        if (ar + lat > 400) break
    }
    return ar > lat
}

fun styleFor(p: Para, st: ReaderStyles): TextStyle = when {
    p.heading -> st.heading
    isArabicText(p.text) -> st.arabic
    else -> st.body
}

fun gapBefore(prev: Slice?, cur: Slice, st: ReaderStyles): Dp = when {
    prev == null -> Dp(0f)
    cur.heading -> st.headGap
    prev.heading -> st.paraGap * 1.4f
    else -> st.paraGap
}

/**
 * Metni sayfalara böler. Her paragraf ölçülür; sayfaya sığmayan paragraf satır sınırından bölünür.
 * Başlık sayfanın dibinde yalnız kalmaz, bir sonraki sayfaya geçer.
 */
fun paginate(
    text: BookText,
    measurer: TextMeasurer,
    st: ReaderStyles,
    widthPx: Int,
    heightPx: Int,
    density: Density,
): List<Page> {
    val pages = ArrayList<Page>()
    val constraints = Constraints(maxWidth = widthPx.coerceAtLeast(1))
    val pageH = heightPx.toFloat()
    val bodyLine = with(density) { (st.body.lineHeight.toPx()) }.let { if (it.isNaN() || it <= 0f) 40f else it }

    for ((ci, ch) in text.chapters.withIndex()) {
        val starts = IntArray(ch.paras.size)
        var acc = 0
        for (i in ch.paras.indices) {
            starts[i] = acc
            acc += ch.paras[i].text.length + 1
        }
        var cur = ArrayList<Slice>()
        var used = 0f
        var prev: Slice? = null

        fun flush() {
            if (cur.isEmpty()) return
            val f = cur[0]
            pages += Page(ci, starts[f.para] + f.start, cur)
            cur = ArrayList()
            used = 0f
            prev = null
        }

        for ((pi, p) in ch.paras.withIndex()) {
            val style = styleFor(p, st)
            val lay = measurer.measure(AnnotatedString(p.text), style = style, constraints = constraints)
            val n = lay.lineCount
            var line = 0
            while (line < n) {
                val probe = Slice(ci, pi, 0, 0, p.heading)
                val gap = with(density) { gapBefore(prev, probe, st).toPx() }
                val avail = pageH - used - gap
                val top = lay.getLineTop(line)
                var last = line - 1
                var k = line
                while (k < n && lay.getLineBottom(k) - top <= avail + 0.5f) {
                    last = k
                    k++
                }
                if (last < line) {
                    if (cur.isEmpty()) {
                        last = line // tek satır bile sığmıyorsa yine de koy (çok büyük yazı)
                    } else {
                        flush()
                        continue
                    }
                }
                // başlık bölünmez
                if (p.heading && last < n - 1 && cur.isNotEmpty()) {
                    flush()
                    continue
                }
                val s = lay.getLineStart(line)
                val e = lay.getLineEnd(last)
                val sl = Slice(ci, pi, s, e, p.heading)
                cur.add(sl)
                used += gap + (lay.getLineBottom(last) - top)
                prev = sl
                line = last + 1
                if (line < n) {
                    flush()
                } else if (p.heading && cur.size > 1 && pageH - used < bodyLine * 2.6f) {
                    // başlığın altına iki satır sığmıyor: başlığı yeni sayfaya taşı
                    cur.removeAt(cur.size - 1)
                    prev = cur.lastOrNull()
                    flush()
                    cur.add(sl)
                    used = lay.getLineBottom(last) - top
                    prev = sl
                }
            }
        }
        flush()
    }
    return pages
}

/** Kaydedilen konumu (bölüm, karakter) içeren sayfanın sırası. */
fun findPage(pages: List<Page>, ch: Int, off: Int): Int {
    var best = 0
    for ((i, p) in pages.withIndex()) {
        if (p.ch < ch || (p.ch == ch && p.off <= off)) best = i else break
    }
    return best
}
