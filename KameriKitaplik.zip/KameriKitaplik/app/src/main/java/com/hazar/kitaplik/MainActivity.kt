package com.hazar.kitaplik

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.hazar.kitaplik.ui.AppRoot
import com.hazar.kitaplik.ui.theme.KameriTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            val vm: MainViewModel = viewModel()
            KameriTheme(vm.appTheme) {
                AppRoot(vm)
            }
        }
    }
}
