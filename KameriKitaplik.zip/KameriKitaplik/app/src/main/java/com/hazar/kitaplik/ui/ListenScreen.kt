package com.hazar.kitaplik.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableLongState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.hazar.kitaplik.MainViewModel
import com.hazar.kitaplik.data.Pod
import com.hazar.kitaplik.data.formatLeft
import com.hazar.kitaplik.data.formatMinutes
import com.hazar.kitaplik.ui.theme.KType
import com.hazar.kitaplik.ui.theme.LocalKColors
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import java.io.File

val AudioTypes = arrayOf("audio/*")

/** Çalan kaydın konumu sık, öbürlerininki kayıtlı değerden okunur. */
@Composable
fun rememberPodPosition(vm: MainViewModel, p: Pod): Long {
    val state: MutableLongState = remember(p.id) { mutableLongStateOf(p.posMs) }
    val active = vm.player.currentKey == p.id
    LaunchedEffect(p.id, active, vm.player.isPlaying) {
        if (!active) {
            state.longValue = p.posMs
            return@LaunchedEffect
        }
        while (isActive) {
            state.longValue = vm.player.position
            delay(if (vm.player.isPlaying) 250L else 800L)
        }
    }
    return if (active) state.longValue else p.posMs
}

@Composable
fun PodArt(p: Pod, cover: File?, modifier: Modifier = Modifier, corner: Dp = 14.dp) {
    val (top, bottom) = tintOf(p.id)
    Box(
        modifier
            .clip(RoundedCornerShape(corner))
            .background(Brush.linearGradient(listOf(top, bottom))),
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.Rounded.Headphones, null, tint = Color.White.copy(alpha = 0.9f), modifier = Modifier.fillMaxSize(0.42f))
        if (cover != null) {
            AsyncImage(model = cover, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        }
    }
}

fun podSub(p: Pod, posMs: Long, playing: Boolean): String = when {
    playing -> "çalıyor"
    p.done -> "Dinlendi" + if (p.durationMs > 0) " · " + formatMinutes(p.durationMs / 60000.0) else ""
    p.durationMs > 0 && posMs > 5000 -> formatLeft(p.durationMs - posMs)
    p.durationMs > 0 -> formatMinutes(p.durationMs / 60000.0)
    else -> "Süre bilinmiyor"
}

@Composable
fun ListenScreen(vm: MainViewModel, onOpenPlayer: () -> Unit) {
    val c = LocalKColors.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) vm.importAudio(uris)
    }
    val add = { launcher.launch(AudioTypes) }
    var filter by remember { mutableStateOf(0) }
    val pods = vm.pods
    val shown = when (filter) {
        1 -> pods.filter { it.progress > 0.005f && !it.done }
        2 -> pods.filter { it.progress <= 0.005f && !it.done }
        3 -> pods.filter { it.done }
        else -> pods
    }
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val hero = vm.shownPod ?: pods.filter { !it.done }.maxByOrNull { it.played }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = top + 14.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("PODCAST · SESLİ KİTAP · DERS", style = KType.Caps, color = c.textSecondary)
                    Spacer(Modifier.height(4.dp))
                    Text("Dinle", style = KType.Display, color = c.text)
                }
                RoundIcon(Icons.Rounded.Add, "Ses dosyası ekle", size = 48.dp, background = c.accent, tint = if (c.isDark) c.bg else Color.White) { add() }
            }
        }
        if (pods.isEmpty()) {
            item { EmptyListen(add) }
        } else {
            if (hero != null) item { HeroPod(vm, hero, onOpenPlayer) }
            item {
                Column {
                    Spacer(Modifier.height(6.dp))
                    val total = pods.sumOf { it.durationMs }
                    SectionHeader("Dinlediklerim", "${pods.size} ses" + if (total > 0) " · " + formatMinutes(total / 60000.0) else "")
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Tümü", "Yarım", "Yeni", "Dinlendi").forEachIndexed { i, l ->
                            KChip(l, selected = filter == i) { filter = i }
                        }
                    }
                }
            }
            items(shown, key = { it.id }) { p -> PodRow(vm, p, onOpenPlayer) }
        }
    }
}

@Composable
private fun HeroPod(vm: MainViewModel, p: Pod, onOpenPlayer: () -> Unit) {
    val (top, bottom) = tintOf(p.id)
    val playing = vm.player.isPlaying && vm.player.currentKey == p.id
    val pos = rememberPodPosition(vm, p)
    Row(
        Modifier
            .fillMaxWidth()
            .shadow(18.dp, RoundedCornerShape(24.dp), ambientColor = top, spotColor = top)
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(top, bottom)))
            .pressable({
                if (vm.player.currentKey != p.id) vm.playPod(p)
                onOpenPlayer()
            }, 0.98f)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        PodArt(p, vm.coverOfPod(p), Modifier.size(84.dp), corner = 18.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                if (playing) "ŞİMDİ ÇALIYOR" else if (pos > 5000) "KALDIĞIN YERDEN" else "SIRADAKİ",
                style = KType.Caps,
                color = Color.White.copy(alpha = 0.78f),
            )
            Spacer(Modifier.height(3.dp))
            Text(p.title, style = KType.Title.copy(fontSize = 18.sp, lineHeight = 23.sp), color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (p.artist.isNotEmpty()) Text(p.artist, style = KType.Body, color = Color.White.copy(alpha = 0.82f), maxLines = 1)
            Spacer(Modifier.height(8.dp))
            ProgressLine(if (p.durationMs > 0) pos.toFloat() / p.durationMs else 0f, color = Color.White, track = Color.White.copy(alpha = 0.22f), height = 4.dp)
        }
        Spacer(Modifier.width(10.dp))
        Box(
            Modifier
                .size(54.dp)
                .clip(CircleShape)
                .background(Color.White)
                .pressable({ vm.playPod(p) }, 0.88f),
            contentAlignment = Alignment.Center,
        ) {
            Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (playing) "Duraklat" else "Oynat", tint = top, modifier = Modifier.size(28.dp))
        }
    }
}

@Composable
private fun PodRow(vm: MainViewModel, p: Pod, onOpenPlayer: () -> Unit) {
    val c = LocalKColors.current
    val cur = vm.player.currentKey == p.id
    val playing = cur && vm.player.isPlaying
    val pos = rememberPodPosition(vm, p)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(if (cur) c.accentSoft else c.card)
            .border(1.dp, if (cur) c.accent.copy(alpha = 0.35f) else c.border, RoundedCornerShape(18.dp))
            .pressable({
                if (!cur) vm.playPod(p)
                onOpenPlayer()
            }, 0.98f)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        PodArt(p, vm.coverOfPod(p), Modifier.size(54.dp).graphicsLayer { alpha = if (p.done) 0.7f else 1f })
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(p.title, style = KType.RowTitle, color = if (p.done) c.textSecondary else c.text, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(
                (if (p.artist.isNotEmpty()) p.artist + " · " else "") + podSub(p, pos, playing),
                style = KType.Small,
                color = c.textSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (pos > 0 && p.durationMs > 0 && !p.done) {
                Spacer(Modifier.height(6.dp))
                ProgressLine(pos.toFloat() / p.durationMs)
            }
        }
        Spacer(Modifier.width(8.dp))
        if (playing) Equalizer(c.accent, Modifier.size(width = 18.dp, height = 16.dp).padding(end = 2.dp))
        RoundIcon(
            if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
            if (playing) "Duraklat" else "Oynat",
            size = 42.dp,
            background = c.accent,
            tint = if (c.isDark) c.bg else Color.White,
        ) { vm.playPod(p) }
    }
}

/** Çalan satırdaki küçük ses çubukları. */
@Composable
fun Equalizer(color: Color, modifier: Modifier = Modifier) {
    val tr = rememberInfiniteTransition(label = "eq")
    val a = tr.animateFloat(0.3f, 1f, infiniteRepeatable(tween(520, easing = LinearEasing), RepeatMode.Reverse), label = "a")
    val b = tr.animateFloat(1f, 0.25f, infiniteRepeatable(tween(430, easing = LinearEasing), RepeatMode.Reverse), label = "b")
    val d = tr.animateFloat(0.5f, 0.9f, infiniteRepeatable(tween(610, easing = LinearEasing), RepeatMode.Reverse), label = "d")
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.Bottom) {
        listOf(a, b, d).forEach { v ->
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxHeight(v.value)
                    .clip(RoundedCornerShape(2.dp))
                    .background(color),
            )
        }
    }
}

@Composable
private fun EmptyListen(onAdd: () -> Unit) {
    val c = LocalKColors.current
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(c.card)
            .border(1.dp, c.border, RoundedCornerShape(24.dp))
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Equalizer(c.gold, Modifier.size(width = 64.dp, height = 46.dp))
        Spacer(Modifier.height(16.dp))
        Text("Dinleyecek bir şey ekle", style = KType.Title, color = c.text)
        Spacer(Modifier.height(6.dp))
        Text(
            "Podcast bölümü, sesli kitap ya da ders kaydı: telefonundaki ses dosyasını seç. Ekran kilitliyken de çalar, kaldığın yerden sürer.",
            style = KType.Subtitle,
            color = c.textSecondary,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(18.dp))
        MainButton("Ses dosyası ekle", Icons.Rounded.Add) { onAdd() }
        Spacer(Modifier.height(8.dp))
        Text("MP3 · M4A · OGG · WAV · FLAC", style = KType.Caps.copy(fontSize = 9.5.sp), color = c.textSecondary)
    }
}
