package com.hazar.kitaplik.data

import org.json.JSONArray
import org.json.JSONObject

/** Kitaplıktaki bir kitap. Metin ayrı dosyada durur; burada yalnızca künye ve kalınan yer var. */
data class Book(
    val id: String,
    val title: String,
    val author: String,
    val kind: String,          // "txt", "epub", "pdf"
    val added: Long,
    val opened: Long = 0L,
    val chapters: Int = 0,
    val chars: Long = 0L,
    val pages: Int = 0,        // yalnızca PDF
    val hasCover: Boolean = false,
    val posCh: Int = 0,        // metinde bölüm, PDF'te sayfa
    val posOff: Int = 0,       // bölüm içindeki karakter
    val progress: Float = 0f,
    val done: Boolean = false,
) {
    val isPdf: Boolean get() = kind == "pdf"

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("title", title).put("author", author).put("kind", kind)
        .put("added", added).put("opened", opened).put("chapters", chapters).put("chars", chars)
        .put("pages", pages).put("hasCover", hasCover).put("posCh", posCh).put("posOff", posOff)
        .put("progress", progress.toDouble()).put("done", done)

    companion object {
        fun fromJson(o: JSONObject) = Book(
            id = o.getString("id"),
            title = o.optString("title"),
            author = o.optString("author"),
            kind = o.optString("kind", "txt"),
            added = o.optLong("added"),
            opened = o.optLong("opened"),
            chapters = o.optInt("chapters"),
            chars = o.optLong("chars"),
            pages = o.optInt("pages"),
            hasCover = o.optBoolean("hasCover"),
            posCh = o.optInt("posCh"),
            posOff = o.optInt("posOff"),
            progress = o.optDouble("progress", 0.0).toFloat(),
            done = o.optBoolean("done"),
        )
    }
}

data class Para(val text: String, val heading: Boolean)

data class Chapter(val title: String, val paras: List<Para>)

class BookText(val chapters: List<Chapter>) {
    val chars: Long get() = chapters.sumOf { c -> c.paras.sumOf { it.text.length.toLong() } }

    fun toJson(): String {
        val arr = JSONArray()
        for (c in chapters) {
            val ps = JSONArray()
            for (p in c.paras) ps.put(if (p.heading) "#" + p.text else p.text)
            arr.put(JSONObject().put("t", c.title).put("p", ps))
        }
        return JSONObject().put("v", 1).put("c", arr).toString()
    }

    companion object {
        fun fromJson(s: String): BookText {
            val arr = JSONObject(s).getJSONArray("c")
            val out = ArrayList<Chapter>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val ps = o.getJSONArray("p")
                val paras = ArrayList<Para>(ps.length())
                for (k in 0 until ps.length()) {
                    val t = ps.getString(k)
                    paras += if (t.startsWith("#")) Para(t.substring(1), true) else Para(t, false)
                }
                out += Chapter(o.optString("t"), paras)
            }
            return BookText(out)
        }
    }
}

/** Dinle sekmesindeki bir ses kaydı. */
data class Pod(
    val id: String,
    val title: String,
    val artist: String,
    val durationMs: Long,
    val file: String,
    val added: Long,
    val posMs: Long = 0L,
    val done: Boolean = false,
    val played: Long = 0L,
    val hasCover: Boolean = false,
) {
    val progress: Float
        get() = when {
            done -> 1f
            durationMs > 0 -> (posMs.toFloat() / durationMs).coerceIn(0f, 1f)
            else -> 0f
        }

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("title", title).put("artist", artist).put("dur", durationMs)
        .put("file", file).put("added", added).put("pos", posMs).put("done", done)
        .put("played", played).put("hasCover", hasCover)

    companion object {
        fun fromJson(o: JSONObject) = Pod(
            id = o.getString("id"),
            title = o.optString("title"),
            artist = o.optString("artist"),
            durationMs = o.optLong("dur"),
            file = o.optString("file"),
            added = o.optLong("added"),
            posMs = o.optLong("pos"),
            done = o.optBoolean("done"),
            played = o.optLong("played"),
            hasCover = o.optBoolean("hasCover"),
        )
    }
}

/** Okuma sayfasının ayarları. */
data class ReaderSettings(
    val theme: String = "CREAM",
    val font: String = "literata",   // literata, lora, jakarta
    val size: Float = 18f,           // sp
    val lineHeight: Float = 1.65f,
    val arabicFont: String = "amiri", // amiri, naskh
    val justify: Boolean = true,
)
