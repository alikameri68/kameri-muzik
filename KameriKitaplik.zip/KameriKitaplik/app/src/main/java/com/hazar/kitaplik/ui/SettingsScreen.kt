package com.hazar.kitaplik.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hazar.kitaplik.MainViewModel
import com.hazar.kitaplik.data.Dictionary
import com.hazar.kitaplik.data.TR
import com.hazar.kitaplik.ui.theme.KTheme
import com.hazar.kitaplik.ui.theme.KType
import com.hazar.kitaplik.ui.theme.LocalKColors
import com.hazar.kitaplik.ui.theme.colorsOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(vm: MainViewModel) {
    val c = LocalKColors.current
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val dictLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importDictionary(uri)
    }
    var q by remember { mutableStateOf("") }
    var openWord by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = top + 14.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Text("AYARLAR", style = KType.Caps, color = c.textSecondary)
            Spacer(Modifier.height(4.dp))
            Text("Görünüm ve sözlük", style = KType.Display, color = c.text)
        }
        item {
            Card {
                SettingLabel("Uygulama teması")
                Spacer(Modifier.height(12.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    KTheme.entries.forEach { t ->
                        val tc = colorsOf(t)
                        Row(
                            Modifier
                                .clip(CircleShape)
                                .background(if (vm.appTheme == t) c.accent else c.subtle)
                                .border(1.dp, if (vm.appTheme == t) c.accent else c.border, CircleShape)
                                .pressable({ vm.setTheme(t) })
                                .padding(start = 6.dp, end = 14.dp, top = 6.dp, bottom = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(Modifier.size(22.dp).clip(CircleShape).background(tc.bg).border(1.dp, tc.border, CircleShape))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                t.label,
                                style = KType.Label,
                                color = if (vm.appTheme == t) (if (c.isDark) c.bg else androidx.compose.ui.graphics.Color.White) else c.text,
                            )
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("Okuma sayfasının rengi, yazı tipi ve boyutu okurken üstteki “Aa” düğmesinden ayarlanır.", style = KType.Body, color = c.textSecondary)
            }
        }
        item {
            Card {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Translate, null, tint = c.accent, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Sözlükler", style = KType.Section, color = c.text, modifier = Modifier.weight(1f))
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "Okurken bir kelimeye basılı tut: anlamı bu sözlüklerden çevrimdışı bulunur. Develioğlu ve Özön dosyalarını bir kez eklemen yeter.",
                    style = KType.Body,
                    color = c.textSecondary,
                )
                Spacer(Modifier.height(12.dp))
                val dicts = remember(vm.dictVersion, vm.dictReady) { vm.dict.dicts }
                if (!vm.dictReady) {
                    Text("Sözlükler yükleniyor…", style = KType.Small, color = c.textSecondary)
                }
                dicts.forEach { d ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(c.subtle)
                            .border(1.dp, c.border, RoundedCornerShape(14.dp))
                            .padding(horizontal = 14.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(d.name, style = KType.RowTitle, color = c.text)
                            Text(
                                String.format(TR, "%,d madde", d.heads.size) + if (d.file == null) " · uygulamayla gelir" else " · bu cihazda",
                                style = KType.Small,
                                color = c.textSecondary,
                            )
                        }
                        val f = d.file
                        if (f != null) {
                            RoundIcon(Icons.Rounded.Close, "Kaldır", size = 34.dp) { vm.deleteDictionary(f) }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                GhostButton("Sözlük dosyası ekle (.tsv, .txt)", Icons.Rounded.Add, modifier = Modifier.fillMaxWidth()) {
                    dictLauncher.launch(arrayOf("text/*", "application/octet-stream", "text/tab-separated-values"))
                }
            }
        }
        item {
            Card {
                SettingLabel("Sözlükte ara")
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = q,
                    onValueChange = { q = it },
                    singleLine = true,
                    placeholder = { Text("ör. gönül, aşk, kitâb") },
                    leadingIcon = { Icon(Icons.Rounded.Search, null) },
                    modifier = Modifier.fillMaxWidth(),
                )
                val results by produceState(emptyList<Dictionary.Hit>(), q, vm.dictVersion) {
                    delay(220)
                    value = withContext(Dispatchers.Default) {
                        if (q.trim().length < 2) emptyList() else {
                            val exact = vm.dict.lookup(q, 6)
                            val more = vm.dict.search(q, 20).filter { h -> exact.none { it.head == h.head && it.source == h.source } }
                            (exact + more).take(20)
                        }
                    }
                }
                results.forEach { h ->
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(c.subtle)
                            .pressable({ openWord = h.head }, 0.98f)
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                    ) {
                        Text(h.head, style = KType.Section.copy(fontSize = 15.sp), color = c.text)
                        Text(h.meaning, style = KType.Body, color = c.text, maxLines = 3)
                        Text(h.source.substringBefore(" · ").uppercase(TR), style = KType.Caps.copy(fontSize = 9.sp), color = c.textSecondary)
                    }
                }
            }
        }
        item {
            Card {
                SettingLabel("Hakkında")
                Spacer(Modifier.height(8.dp))
                Text("Kamerî Kitaplık 4.0", style = KType.RowTitle, color = c.text)
                Text(
                    "Yerel Android sürümü (Kotlin, Jetpack Compose). Kitaplar, sesler ve sözlükler yalnızca bu cihazda saklanır. " +
                        "Yazı tipleri: Literata, Lora, Plus Jakarta Sans, Amiri, Noto Naskh Arabic (SIL Open Font License).",
                    style = KType.Body,
                    color = c.textSecondary,
                )
            }
        }
    }

    openWord?.let { w ->
        WordSheet(vm, w) { openWord = null }
    }
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun WordSheet(vm: MainViewModel, word: String, onDismiss: () -> Unit) {
    androidx.compose.material3.ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = androidx.compose.material3.rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = LocalKColors.current.card,
    ) { WordCard(vm, word) }
}

@Composable
private fun Card(content: @Composable () -> Unit) {
    val c = LocalKColors.current
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(c.card)
            .border(1.dp, c.border, RoundedCornerShape(22.dp))
            .padding(18.dp),
    ) { content() }
}
