package com.hazar.kitaplik.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoStories
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hazar.kitaplik.MainViewModel
import com.hazar.kitaplik.data.Book
import com.hazar.kitaplik.data.CHARS_PER_MIN
import com.hazar.kitaplik.data.formatMinutes
import com.hazar.kitaplik.ui.theme.KType
import com.hazar.kitaplik.ui.theme.LocalKColors
import java.util.Calendar

val BookTypes = arrayOf("application/epub+zip", "application/pdf", "text/plain", "application/octet-stream")

private fun greeting(): String = when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
    in 5..10 -> "Günaydın"
    in 11..17 -> "İyi günler"
    in 18..22 -> "İyi akşamlar"
    else -> "İyi geceler"
}

fun bookSubtitle(b: Book): String = when {
    b.isPdf -> "${b.pages} sayfa · PDF"
    else -> "${b.chapters} bölüm" + if (b.chars > 0) " · " + formatMinutes(b.chars / CHARS_PER_MIN.toDouble()) else ""
}

@Composable
fun LibraryScreen(vm: MainViewModel, onOpen: (String) -> Unit, onRead: (String) -> Unit) {
    val c = LocalKColors.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) vm.importBooks(uris)
    }
    val add = { launcher.launch(BookTypes) }
    var filter by remember { mutableStateOf(0) }
    val books = vm.books
    val shown = when (filter) {
        1 -> books.filter { it.progress > 0.005f && !it.done }
        2 -> books.filter { it.progress <= 0.005f && !it.done }
        3 -> books.filter { it.done }
        else -> books
    }
    val last = books.filter { it.opened > 0 && !it.done }.maxByOrNull { it.opened }
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    LazyVerticalGrid(
        columns = GridCells.Adaptive(104.dp),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = top + 14.dp, bottom = 28.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(greeting().uppercase(com.hazar.kitaplik.data.TR), style = KType.Caps, color = c.textSecondary)
                    Spacer(Modifier.height(4.dp))
                    Text("Kitaplığım", style = KType.Display, color = c.text)
                }
                RoundIcon(Icons.Rounded.Add, "Kitap ekle", size = 48.dp, background = c.accent, tint = if (c.isDark) c.bg else Color.White) { add() }
            }
        }
        if (last != null) {
            item(span = { GridItemSpan(maxLineSpan) }) { ContinueCard(vm, last, onRead) }
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column {
                SectionHeader("Raflarım", "${books.size} kitap")
                if (books.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Tümü", "Okunuyor", "Okunacak", "Bitti").forEachIndexed { i, l ->
                            KChip(l, selected = filter == i) { filter = i }
                        }
                    }
                }
            }
        }
        if (books.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) { EmptyLibrary(add) }
        } else {
            items(shown, key = { it.id }) { b -> BookTile(vm, b) { onOpen(b.id) } }
            if (filter == 0) item(key = "add") { AddTile(add) }
        }
    }
}

@Composable
private fun ContinueCard(vm: MainViewModel, b: Book, onRead: (String) -> Unit) {
    val c = LocalKColors.current
    val (top, bottom) = tintOf(b.id)
    Row(
        Modifier
            .fillMaxWidth()
            .shadow(18.dp, RoundedCornerShape(24.dp), ambientColor = top, spotColor = top)
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(top, bottom)))
            .pressable({ onRead(b.id) }, 0.98f)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        BookCover(b.id, b.title, vm.coverOf(b), Modifier.width(70.dp), titleSize = 8.sp, elevation = 8.dp)
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text("KALDIĞIN YERDEN", style = KType.Caps, color = Color.White.copy(alpha = 0.75f))
            Spacer(Modifier.height(4.dp))
            Text(b.title, style = KType.Title.copy(fontSize = 19.sp, lineHeight = 24.sp), color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (b.author.isNotEmpty()) Text(b.author, style = KType.Body, color = Color.White.copy(alpha = 0.8f), maxLines = 1)
            Spacer(Modifier.height(10.dp))
            ProgressLine(b.progress, color = Color.White, track = Color.White.copy(alpha = 0.22f), height = 4.dp)
            Spacer(Modifier.height(6.dp))
            val left = if (!b.isPdf && b.chars > 0) " · " + formatMinutes((1 - b.progress) * b.chars / CHARS_PER_MIN.toDouble()) + " kaldı" else ""
            Text("%${(b.progress * 100).toInt()}$left", style = KType.Small, color = Color.White.copy(alpha = 0.85f))
        }
        Spacer(Modifier.width(10.dp))
        Box(
            Modifier
                .size(50.dp)
                .clip(CircleShape)
                .background(Color.White),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.AutoStories, "Devam et", tint = top, modifier = Modifier.size(22.dp))
        }
    }
}

@Composable
private fun BookTile(vm: MainViewModel, b: Book, onClick: () -> Unit) {
    val c = LocalKColors.current
    Column(Modifier.pressable(onClick, 0.95f)) {
        Box {
            BookCover(b.id, b.title, vm.coverOf(b), Modifier.fillMaxWidth())
            if (b.done) {
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                        .size(22.dp)
                        .clip(CircleShape)
                        .background(c.accent),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.Check, "Bitti", tint = Color.White, modifier = Modifier.size(14.dp)) }
            } else if (b.opened == 0L) {
                Text(
                    "YENİ",
                    style = KType.Caps.copy(fontSize = 9.sp, letterSpacing = 1.sp),
                    color = Color.White,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                        .clip(CircleShape)
                        .background(c.rust)
                        .padding(horizontal = 7.dp, vertical = 3.dp),
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(b.title, style = KType.RowTitle.copy(fontSize = 13.sp, lineHeight = 17.sp), color = c.text, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Text(if (b.author.isNotEmpty()) b.author else bookSubtitle(b), style = KType.Small, color = c.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (b.progress > 0.005f && !b.done) {
            Spacer(Modifier.height(6.dp))
            ProgressLine(b.progress)
        }
    }
}

@Composable
private fun AddTile(onClick: () -> Unit) {
    val c = LocalKColors.current
    Column(Modifier.pressable(onClick, 0.95f)) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 3f)
                .clip(RoundedCornerShape(10.dp))
                .border(1.5.dp, c.border, RoundedCornerShape(10.dp))
                .background(c.subtle),
            contentAlignment = Alignment.Center,
        ) {
            Box(Modifier.size(46.dp).clip(CircleShape).background(c.accentSoft), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Add, null, tint = c.accent)
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("Kitap ekle", style = KType.RowTitle.copy(fontSize = 13.sp), color = c.accent)
    }
}

@Composable
private fun EmptyLibrary(onAdd: () -> Unit) {
    val c = LocalKColors.current
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(c.card)
            .border(1.dp, c.border, RoundedCornerShape(24.dp))
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Rosette(c.gold, Modifier.size(64.dp), stroke = 1.6.dp)
        Spacer(Modifier.height(16.dp))
        Text("Kitaplığın boş", style = KType.Title, color = c.text)
        Spacer(Modifier.height(6.dp))
        Text(
            "EPUB, PDF ya da TXT dosyası ekle. Kitaplar yalnızca bu cihazda saklanır.",
            style = KType.Subtitle,
            color = c.textSecondary,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(18.dp))
        MainButton("Kitap ekle", Icons.Rounded.Add) { onAdd() }
    }
}
