package com.hazar.kitaplik.data

import android.content.Context
import org.json.JSONArray
import java.io.File

/** Bütün veriler uygulamanın kendi klasöründe JSON dosyaları olarak saklanır. */
class Store(context: Context) {
    private val root: File = context.filesDir
    val booksDir = File(root, "books").apply { mkdirs() }
    val coversDir = File(root, "covers").apply { mkdirs() }
    val audioDir = File(root, "audio").apply { mkdirs() }
    val dictDir = File(root, "dicts").apply { mkdirs() }
    private val libFile = File(root, "library.json")
    private val podFile = File(root, "pods.json")

    fun textFile(id: String) = File(booksDir, "$id.json")
    fun pdfFile(id: String) = File(booksDir, "$id.pdf")
    fun coverFile(id: String) = File(coversDir, "$id.jpg")

    fun loadBooks(): List<Book> = readArray(libFile) { Book.fromJson(it) }
    fun saveBooks(list: List<Book>) = writeAtomic(libFile, JSONArray().also { a -> list.forEach { a.put(it.toJson()) } }.toString())

    fun loadPods(): List<Pod> = readArray(podFile) { Pod.fromJson(it) }
    fun savePods(list: List<Pod>) = writeAtomic(podFile, JSONArray().also { a -> list.forEach { a.put(it.toJson()) } }.toString())

    fun loadText(id: String): BookText? = runCatching { BookText.fromJson(textFile(id).readText()) }.getOrNull()
    fun saveText(id: String, t: BookText) = writeAtomic(textFile(id), t.toJson())

    fun deleteBook(id: String) {
        textFile(id).delete()
        pdfFile(id).delete()
        coverFile(id).delete()
    }

    private fun <T> readArray(f: File, map: (org.json.JSONObject) -> T): List<T> = runCatching {
        if (!f.exists()) return emptyList()
        val a = JSONArray(f.readText())
        (0 until a.length()).mapNotNull { i -> runCatching { map(a.getJSONObject(i)) }.getOrNull() }
    }.getOrDefault(emptyList())

    private fun writeAtomic(f: File, s: String) {
        val tmp = File(f.parentFile, f.name + ".tmp")
        tmp.writeText(s)
        if (!tmp.renameTo(f)) {
            f.writeText(s)
            tmp.delete()
        }
    }
}
