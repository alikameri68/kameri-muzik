package com.hazar.kitaplik.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hazar.kitaplik.MainViewModel
import com.hazar.kitaplik.data.Dictionary
import com.hazar.kitaplik.data.TR
import com.hazar.kitaplik.ui.theme.Amiri
import com.hazar.kitaplik.ui.theme.KType
import com.hazar.kitaplik.ui.theme.Literata
import com.hazar.kitaplik.ui.theme.LocalKColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val ORIGIN = mapOf(
    "a" to "Arapça", "f" to "Farsça", "t" to "Türkçe", "fr" to "Fransızca", "it" to "İtalyanca", "yun" to "Yunanca",
    "yu" to "Yunanca", "rum" to "Rumca", "lat" to "Latince", "erm" to "Ermenice", "ibr" to "İbranice", "moğ" to "Moğolca",
    "mo" to "Moğolca", "ing" to "İngilizce", "al" to "Almanca", "rus" to "Rusça", "süry" to "Süryanice",
)
private val TYPE = mapOf(
    "i" to "isim", "s" to "sıfat", "zf" to "zarf", "e" to "edat", "c" to "çoğul", "m" to "mastar", "zm" to "zamir",
    "f" to "fiil", "h" to "özel ad", "n" to "nida",
)

/** Anlamın başındaki köken ve tür kısaltmalarını ayırır: "(a. i.) sevgi" → Arapça · isim. */
fun splitMeta(mean: String): Triple<String, List<String>, String> {
    var s = mean.trim()
    var origin = ""
    val types = ArrayList<String>()
    val paren = Regex("^\\(\\s*([^)]{1,26})\\)\\s*").find(s)
    val bare = Regex("^((?:A|F|T|Fr|İt|It|Yu|Rum|Erm|İbr|Mo|Moğ|Lat|Süry|İng|Al|Rus)\\.)\\s*((?:(?:i|s|zf|e|c|m|zm)\\.\\s*){0,2})").find(s)
    val toks: List<String>
    val cut: Int
    if (paren != null) {
        toks = paren.groupValues[1].split(Regex("[\\s.]+")).filter { it.isNotEmpty() }
        cut = paren.value.length
    } else if (bare != null) {
        toks = (bare.groupValues[1] + " " + bare.groupValues[2]).split(Regex("[\\s.]+")).filter { it.isNotEmpty() }
        cut = bare.value.length
    } else {
        return Triple("", emptyList(), s)
    }
    if (toks.isEmpty() || toks.size > 4 || toks.any { it.length > 4 }) return Triple("", emptyList(), s)
    for ((i, t) in toks.withIndex()) {
        val k = t.lowercase(TR)
        when {
            i == 0 && ORIGIN.containsKey(k) -> origin = ORIGIN.getValue(k)
            TYPE.containsKey(k) -> TYPE.getValue(k).let { if (it !in types) types += it }
            else -> return Triple("", emptyList(), s)
        }
    }
    s = s.substring(cut).trim()
    return Triple(origin, types.take(2), s.ifEmpty { mean.trim() })
}

/** Kelimeye basılı tutunca açılan kart: madde başı, Arap harfli yazılış, köken ve tür rozetleri, anlam. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WordCard(vm: MainViewModel, word: String) {
    val c = LocalKColors.current
    val context = LocalContext.current
    val hits by produceState<List<Dictionary.Hit>?>(null, word, vm.dictVersion) {
        value = withContext(Dispatchers.Default) { vm.dict.lookup(word, 6) }
    }
    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp)
            .padding(bottom = 26.dp)
            .navigationBarsPadding(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        val list = hits
        when {
            list == null || !vm.dictReady -> Loader(Modifier.height(120.dp))
            list.isEmpty() -> {
                Text(word, style = KType.Display, color = c.text)
                Text("Bu kelime cihazdaki sözlüklerde bulunamadı.", style = KType.Subtitle, color = c.textSecondary)
                if (vm.dict.dicts.size <= 1) {
                    Text(
                        "Ayarlar → Sözlükler bölümünden Develioğlu ya da Özön dosyasını eklersen çok daha fazla kelime bulunur.",
                        style = KType.Body,
                        color = c.textSecondary,
                    )
                }
            }
            else -> {
                val h0 = list[0]
                val (origin, types, text) = splitMeta(h0.meaning)
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(h0.head, style = KType.Display, color = c.text, modifier = Modifier.weight(1f, fill = false))
                    if (h0.arabic.isNotEmpty()) {
                        Spacer(Modifier.width(14.dp))
                        Text(h0.arabic, style = TextStyle(fontFamily = Amiri, fontSize = 28.sp, textDirection = TextDirection.Rtl), color = c.accent)
                    }
                }
                if (Dictionary.norm(h0.head) != Dictionary.norm(word)) {
                    Text("Metinde: $word", style = KType.Small, color = c.textSecondary)
                }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (origin.isNotEmpty()) Badge(origin, c.accent, c.accentSoft)
                    types.forEach { Badge(it, c.text, c.subtle) }
                    if (!h0.exact) Badge("Kök: ${h0.head}", c.text, c.gold.copy(alpha = 0.16f))
                }
                SelectionContainer {
                    Text(text, style = TextStyle(fontFamily = Literata, fontSize = 17.5.sp, lineHeight = 27.sp), color = c.text)
                }
                Text(h0.source.substringBefore(" · ").uppercase(TR), style = KType.Caps, color = c.textSecondary)
                if (list.size > 1) {
                    Spacer(Modifier.height(4.dp))
                    Text("ÖBÜR KAYITLAR", style = KType.Caps, color = c.gold)
                    list.drop(1).take(4).forEach { h ->
                        val (o, ts, tx) = splitMeta(h.meaning)
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(c.subtle)
                                .border(1.dp, c.border, RoundedCornerShape(14.dp))
                                .padding(horizontal = 14.dp, vertical = 11.dp),
                        ) {
                            Text(h.head, style = KType.Section.copy(fontSize = 15.5.sp), color = c.text)
                            val meta = (listOf(o) + ts).filter { it.isNotEmpty() }.joinToString(" · ")
                            if (meta.isNotEmpty()) Text(meta, style = KType.Small, color = c.accent)
                            Text(tx, style = KType.Body.copy(fontSize = 13.5.sp, lineHeight = 20.sp), color = c.text)
                            Text(h.source.substringBefore(" · ").uppercase(TR), style = KType.Caps.copy(fontSize = 9.sp), color = c.textSecondary)
                        }
                    }
                }
                GhostButton("Kopyala", Icons.Rounded.ContentCopy) {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("sözlük", h0.head + ": " + text))
                    vm.say("Kopyalandı")
                }
            }
        }
    }
}

@Composable
private fun Badge(text: String, fg: androidx.compose.ui.graphics.Color, bg: androidx.compose.ui.graphics.Color) {
    Text(
        text,
        style = KType.Small.copy(fontSize = 11.5.sp),
        color = fg,
        modifier = Modifier
            .clip(CircleShape)
            .background(bg)
            .padding(horizontal = 11.dp, vertical = 5.dp),
    )
}
