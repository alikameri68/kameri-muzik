package com.hazar.kitaplik.ui.theme

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.tween
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.hazar.kitaplik.R
import androidx.compose.animation.core.spring as composeSpring

/** Uygulamanın ve okuma sayfasının temaları. Renkler 3.x sürümünden birebir alındı. */
enum class KTheme(val label: String) {
    CREAM("Krem"),
    SEPIA("Sepya"),
    NIGHT("Gece"),
    AMOLED("AMOLED siyah"),
}

@Immutable
data class KColors(
    val bg: Color,
    val card: Color,
    val subtle: Color,
    val muted: Color,
    val border: Color,
    val text: Color,
    val textSecondary: Color,
    val accent: Color,
    val accentSoft: Color,
    val gold: Color,
    val rust: Color,
    val isDark: Boolean,
)

val CreamColors = KColors(
    bg = Color(0xFFF3EEE4),
    card = Color(0xFFFFFCF7),
    subtle = Color(0xFFFAF6EE),
    muted = Color(0xFFEBE3D4),
    border = Color(0xFFDDD2BF),
    text = Color(0xFF1F1C18),
    textSecondary = Color(0xFF5A5348),
    accent = Color(0xFF1B4D3E),
    accentSoft = Color(0x1F1B4D3E),
    gold = Color(0xFFB8922E),
    rust = Color(0xFFA34A33),
    isDark = false,
)

val SepiaColors = KColors(
    bg = Color(0xFFF1E4C8),
    card = Color(0xFFF7EDD6),
    subtle = Color(0xFFF4E8CE),
    muted = Color(0xFFE6D5B1),
    border = Color(0xFFD5C094),
    text = Color(0xFF3B2A17),
    textSecondary = Color(0xFF6E5638),
    accent = Color(0xFF6B4A1E),
    accentSoft = Color(0x226B4A1E),
    gold = Color(0xFFA67C1E),
    rust = Color(0xFF9A4325),
    isDark = false,
)

val NightColors = KColors(
    bg = Color(0xFF0F1312),
    card = Color(0xFF1A211F),
    subtle = Color(0xFF1F2825),
    muted = Color(0xFF26302C),
    border = Color(0xFF2E3A35),
    text = Color(0xFFE6E4DF),
    textSecondary = Color(0xFF9AA8A2),
    accent = Color(0xFF3DBA94),
    accentSoft = Color(0x243DBA94),
    gold = Color(0xFFE8C547),
    rust = Color(0xFFE6A28C),
    isDark = true,
)

val AmoledColors = KColors(
    bg = Color(0xFF000000),
    card = Color(0xFF0B0B0B),
    subtle = Color(0xFF111111),
    muted = Color(0xFF191919),
    border = Color(0xFF242424),
    text = Color(0xFFD6D4CF),
    textSecondary = Color(0xFF8B8D8A),
    accent = Color(0xFF45B892),
    accentSoft = Color(0x2445B892),
    gold = Color(0xFFD8B84C),
    rust = Color(0xFFE6A28C),
    isDark = true,
)

fun colorsOf(theme: KTheme): KColors = when (theme) {
    KTheme.CREAM -> CreamColors
    KTheme.SEPIA -> SepiaColors
    KTheme.NIGHT -> NightColors
    KTheme.AMOLED -> AmoledColors
}

val LocalKColors = staticCompositionLocalOf { CreamColors }

@OptIn(ExperimentalTextApi::class)
private fun variable(resId: Int, weight: Int): Font = Font(
    resId = resId,
    weight = FontWeight(weight),
    variationSettings = FontVariation.Settings(FontVariation.weight(weight)),
)

val Literata = FontFamily(
    variable(R.font.literata, 400),
    variable(R.font.literata, 500),
    variable(R.font.literata, 600),
    variable(R.font.literata, 700),
)

val Lora = FontFamily(
    variable(R.font.lora, 400),
    variable(R.font.lora, 500),
    variable(R.font.lora, 600),
    variable(R.font.lora, 700),
)

val Jakarta = FontFamily(
    variable(R.font.plus_jakarta_sans, 400),
    variable(R.font.plus_jakarta_sans, 500),
    variable(R.font.plus_jakarta_sans, 600),
    variable(R.font.plus_jakarta_sans, 700),
    variable(R.font.plus_jakarta_sans, 800),
)

val Amiri = FontFamily(Font(R.font.amiri, FontWeight.Normal))

val NotoNaskh = FontFamily(
    variable(R.font.noto_naskh, 400),
    variable(R.font.noto_naskh, 700),
)

/** Başlıklar serif (Literata), denetimler sans (Plus Jakarta). */
object KType {
    val Display = TextStyle(fontFamily = Literata, fontWeight = FontWeight(600), fontSize = 30.sp, lineHeight = 36.sp, letterSpacing = (-0.4).sp)
    val Title = TextStyle(fontFamily = Literata, fontWeight = FontWeight(600), fontSize = 22.sp, lineHeight = 28.sp, letterSpacing = (-0.3).sp)
    val Section = TextStyle(fontFamily = Literata, fontWeight = FontWeight(600), fontSize = 19.sp, lineHeight = 24.sp)
    val Subtitle = TextStyle(fontFamily = Jakarta, fontWeight = FontWeight(500), fontSize = 14.sp, lineHeight = 20.sp)
    val RowTitle = TextStyle(fontFamily = Jakarta, fontWeight = FontWeight(700), fontSize = 14.sp, lineHeight = 19.sp)
    val Body = TextStyle(fontFamily = Jakarta, fontWeight = FontWeight(400), fontSize = 13.sp, lineHeight = 19.sp)
    val Label = TextStyle(fontFamily = Jakarta, fontWeight = FontWeight(700), fontSize = 13.sp, lineHeight = 18.sp)
    val Small = TextStyle(fontFamily = Jakarta, fontWeight = FontWeight(600), fontSize = 11.5.sp, lineHeight = 15.sp)
    val Caps = TextStyle(fontFamily = Jakarta, fontWeight = FontWeight(800), fontSize = 10.5.sp, letterSpacing = 1.6.sp)
    val Time = TextStyle(fontFamily = Jakarta, fontWeight = FontWeight(600), fontSize = 12.sp, fontFeatureSettings = "tnum")
}

/** Bütün uygulamada üç hareket eğrisi kullanılır: giriş, çıkış, yay. */
object Motion {
    val Enter = CubicBezierEasing(0.16f, 1f, 0.3f, 1f)
    val Exit = CubicBezierEasing(0.4f, 0f, 1f, 1f)

    fun <T> spring(): FiniteAnimationSpec<T> = composeSpring(dampingRatio = 0.82f, stiffness = 380f)
    fun <T> enter(ms: Int = 360): FiniteAnimationSpec<T> = tween(ms, easing = Enter)
    fun <T> exit(ms: Int = 220): FiniteAnimationSpec<T> = tween(ms, easing = Exit)
}

@Composable
fun KameriTheme(theme: KTheme, content: @Composable () -> Unit) {
    val c = colorsOf(theme)
    val scheme = if (c.isDark) {
        darkColorScheme(
            primary = c.accent,
            secondary = c.gold,
            background = c.bg,
            surface = c.card,
            surfaceContainerLow = c.card,
            onBackground = c.text,
            onSurface = c.text,
            onPrimary = c.bg,
        )
    } else {
        lightColorScheme(
            primary = c.accent,
            secondary = c.gold,
            background = c.bg,
            surface = c.card,
            surfaceContainerLow = c.card,
            onBackground = c.text,
            onSurface = c.text,
            onPrimary = Color.White,
        )
    }
    CompositionLocalProvider(LocalKColors provides c) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
