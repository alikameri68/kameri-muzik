package com.hazar.kitaplik.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoStories
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.hazar.kitaplik.MainViewModel
import com.hazar.kitaplik.data.formatLeft
import com.hazar.kitaplik.ui.theme.KType
import com.hazar.kitaplik.ui.theme.LocalKColors
import com.hazar.kitaplik.ui.theme.Motion
import com.hazar.kitaplik.ui.theme.colorsOf
import com.hazar.kitaplik.ui.theme.KTheme

private data class Tab(val label: String, val icon: ImageVector)

private val Tabs = listOf(
    Tab("Kitaplık", Icons.Rounded.AutoStories),
    Tab("Dinle", Icons.Rounded.Headphones),
    Tab("Ayarlar", Icons.Rounded.Tune),
)

@Composable
fun AppRoot(vm: MainViewModel) {
    val c = LocalKColors.current
    val context = LocalContext.current
    val view = LocalView.current

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var detailId by rememberSaveable { mutableStateOf<String?>(null) }
    var readingId by rememberSaveable { mutableStateOf<String?>(null) }
    var playerOpen by rememberSaveable { mutableStateOf(false) }

    // çıkış canlandırması sürerken içerik boşalmasın diye son açılan kimlikler tutulur
    var lastDetail by remember { mutableStateOf<String?>(null) }
    var lastReading by remember { mutableStateOf<String?>(null) }
    if (detailId != null) lastDetail = detailId
    if (readingId != null) lastReading = readingId

    // Android 13+: kilit ekranında oynatma denetimi için bildirim izni (bir kez sorulur)
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    var askedNotif by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(vm.player.currentKey) {
        if (vm.player.currentKey != null && !askedNotif && Build.VERSION.SDK_INT >= 33) {
            askedNotif = true
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val readerDark = remember(vm.reader.theme) {
        colorsOf(runCatching { KTheme.valueOf(vm.reader.theme) }.getOrDefault(KTheme.CREAM)).isDark
    }
    SideEffect {
        context.findActivity()?.window?.let { window ->
            val dark = if (readingId != null) readerDark else (c.isDark || playerOpen)
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !dark
                isAppearanceLightNavigationBars = !dark
            }
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(c.bg),
    ) {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) {
                AnimatedContent(
                    targetState = tab,
                    transitionSpec = { fadeIn(Motion.enter(260)) togetherWith fadeOut(Motion.exit(140)) },
                    label = "tab",
                ) { t ->
                    when (t) {
                        0 -> LibraryScreen(vm, onOpen = { detailId = it }, onRead = { id ->
                            vm.markOpened(id)
                            readingId = id
                        })
                        1 -> ListenScreen(vm, onOpenPlayer = { playerOpen = true })
                        else -> SettingsScreen(vm)
                    }
                }
            }
            MiniPlayer(vm, onOpen = { playerOpen = true })
            BottomBar(tab) { tab = it }
        }

        AnimatedVisibility(
            visible = detailId != null && readingId == null,
            enter = fadeIn(Motion.enter(240)) + slideInVertically(Motion.enter(420)) { it / 8 },
            exit = fadeOut(Motion.exit(180)) + slideOutVertically(Motion.exit(220)) { it / 10 },
        ) {
            val b = vm.book(lastDetail)
            if (b != null) {
                BookDetail(
                    vm = vm,
                    book = b,
                    onClose = { detailId = null },
                    onRead = { ch ->
                        if (ch != null) vm.saveReadPos(b.id, ch, 0, b.progress)
                        vm.markOpened(b.id)
                        readingId = b.id
                    },
                )
            }
        }

        AnimatedVisibility(
            visible = readingId != null,
            enter = fadeIn(Motion.enter(300)) + scaleIn(Motion.enter(420), initialScale = 0.94f),
            exit = fadeOut(Motion.exit(200)),
        ) {
            val b = vm.book(lastReading)
            if (b != null) ReaderScreen(vm, b, onClose = { readingId = null })
        }

        AnimatedVisibility(
            visible = playerOpen,
            enter = slideInVertically(Motion.enter(460)) { it } + fadeIn(Motion.enter(200)),
            exit = slideOutVertically(Motion.exit(260)) { it } + fadeOut(Motion.exit(260)),
        ) {
            PlayerScreen(vm, onClose = { playerOpen = false })
        }

        ToastHost(vm.toast, vm.toastSeq, bottomPadding = if (readingId != null) 24.dp else 150.dp) { vm.toast = null }
        BusyOverlay(vm.busy)
    }

    BackHandler(enabled = tab != 0 && detailId == null && readingId == null && !playerOpen) { tab = 0 }
    BackHandler(enabled = detailId != null && readingId == null && !playerOpen) { detailId = null }
    BackHandler(enabled = playerOpen) { playerOpen = false }
}

@Composable
private fun BottomBar(selected: Int, onSelect: (Int) -> Unit) {
    val c = LocalKColors.current
    Box(
        Modifier
            .fillMaxWidth()
            .background(c.card)
            .border(0.5.dp, c.border.copy(alpha = 0.6f))
            .navigationBarsPadding(),
    ) {
        BoxWithConstraints(
            Modifier
                .fillMaxWidth()
                .height(64.dp)
                .padding(horizontal = 10.dp),
        ) {
            val w = maxWidth / Tabs.size
            val x by animateDpAsState(w * selected, Motion.spring(), label = "ind")
            Box(
                Modifier
                    .offset(x = x + w * 0.18f, y = 8.dp)
                    .width(w * 0.64f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(c.accentSoft),
            )
            Row(Modifier.fillMaxSize()) {
                Tabs.forEachIndexed { i, t ->
                    val on = i == selected
                    val fg by animateColorAsState(if (on) c.accent else c.textSecondary, Motion.enter(240), label = "tabFg")
                    Column(
                        Modifier
                            .weight(1f)
                            .fillMaxSize()
                            .pressable({ onSelect(i) }, 0.92f),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        Icon(t.icon, null, tint = fg, modifier = Modifier.size(23.dp))
                        Spacer(Modifier.height(3.dp))
                        Text(t.label, style = KType.Small, color = fg)
                    }
                }
            }
        }
    }
}

/** Bütün sekmelerde alt çubuğun üstünde duran küçük oynatıcı. */
@Composable
private fun MiniPlayer(vm: MainViewModel, onOpen: () -> Unit) {
    val p = vm.shownPod
    AnimatedVisibility(
        visible = p != null,
        enter = slideInVertically(Motion.enter(420)) { it } + fadeIn(Motion.enter(200)),
        exit = slideOutVertically(Motion.exit(220)) { it } + fadeOut(Motion.exit(200)),
    ) {
        if (p == null) return@AnimatedVisibility
        val (top, bottom) = tintOf(p.id)
        val playing = vm.player.isPlaying && vm.player.currentKey == p.id
        val pos = rememberPodPosition(vm, p)
        val dur = if (vm.player.currentKey == p.id && vm.player.durationMs > 0) vm.player.durationMs else p.durationMs
        Box(
            Modifier
                .padding(horizontal = 10.dp, vertical = 8.dp)
                .fillMaxWidth()
                .shadow(16.dp, RoundedCornerShape(18.dp))
                .clip(RoundedCornerShape(18.dp))
                .background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(top, bottom)))
                .pressable(onOpen, 0.98f),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .padding(start = 8.dp, end = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                PodArt(p, vm.coverOfPod(p), Modifier.size(44.dp), corner = 12.dp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(p.title, style = KType.RowTitle, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        (if (p.artist.isNotEmpty()) p.artist + " · " else "") +
                            (if (playing) "çalıyor" else if (dur > 0) formatLeft(dur - pos) else "dinlemeye hazır"),
                        style = KType.Small,
                        color = Color.White.copy(alpha = 0.78f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                RoundIcon(
                    if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    if (playing) "Duraklat" else "Oynat",
                    size = 42.dp,
                    background = Color.White.copy(alpha = 0.16f),
                    tint = Color.White,
                ) { vm.togglePod() }
                RoundIcon(Icons.Rounded.Close, "Kapat", size = 36.dp, background = Color.Transparent, tint = Color.White.copy(alpha = 0.7f)) {
                    vm.closePlayer()
                }
            }
            Box(
                Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth(if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f)
                    .height(3.dp)
                    .background(Color.White.copy(alpha = 0.85f), CircleShape),
            )
        }
    }
}
