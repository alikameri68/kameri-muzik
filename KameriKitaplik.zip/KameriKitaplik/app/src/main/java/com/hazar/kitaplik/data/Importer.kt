package com.hazar.kitaplik.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import org.jsoup.nodes.Node
import org.jsoup.nodes.TextNode
import org.jsoup.parser.Parser
import java.io.File
import java.io.FileOutputStream
import java.net.URLDecoder
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.util.zip.ZipFile

class ImportError(message: String) : Exception(message)

/** Dosyaları kitaplığa ve Dinle listesine alır. Bütün işler arka planda yapılır. */
object Importer {

    fun displayName(ctx: Context, uri: Uri): String {
        var name: String? = null
        try {
            val c = ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            if (c != null) {
                try {
                    if (c.moveToFirst()) name = c.getString(0)
                } finally {
                    c.close()
                }
            }
        } catch (e: Exception) {
            name = null
        }
        if (!name.isNullOrBlank()) return name
        return uri.lastPathSegment?.substringAfterLast('/') ?: "dosya"
    }

    private fun copy(ctx: Context, uri: Uri, dest: File) {
        val input = ctx.contentResolver.openInputStream(uri) ?: throw ImportError("Dosya açılamadı")
        input.use { i -> FileOutputStream(dest).use { o -> i.copyTo(o, 64 * 1024) } }
    }

    suspend fun importBook(ctx: Context, store: Store, uri: Uri): Book = withContext(Dispatchers.IO) {
        val name = displayName(ctx, uri)
        val lower = name.lowercase(TR)
        val mime = ctx.contentResolver.getType(uri) ?: ""
        val id = newId("b")
        when {
            lower.endsWith(".epub") || mime == "application/epub+zip" -> importEpub(ctx, store, uri, id, name)
            lower.endsWith(".pdf") || mime == "application/pdf" -> importPdf(ctx, store, uri, id, name)
            lower.endsWith(".txt") || mime.startsWith("text/") -> importTxt(ctx, store, uri, id, name)
            else -> throw ImportError("“$name” desteklenmiyor; EPUB, PDF ya da TXT seç")
        }
    }

    // ---------- TXT ----------

    private fun decode(b: ByteArray): String {
        if (b.size >= 3 && b[0] == 0xEF.toByte() && b[1] == 0xBB.toByte() && b[2] == 0xBF.toByte()) {
            return String(b, 3, b.size - 3, Charsets.UTF_8)
        }
        if (b.size >= 2 && b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte()) return String(b, 2, b.size - 2, Charsets.UTF_16LE)
        if (b.size >= 2 && b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte()) return String(b, 2, b.size - 2, Charsets.UTF_16BE)
        val dec = Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
        return try {
            dec.decode(ByteBuffer.wrap(b)).toString()
        } catch (e: CharacterCodingException) {
            String(b, Charset.forName("windows-1254"))
        }
    }

    private val headingRe = Regex(
        "^(BÖLÜM|Bölüm|KISIM|Kısım|FASIL|Fasıl|BAP|Bap|CHAPTER|Chapter|PART|Part|ÖNSÖZ|Önsöz|GİRİŞ|Giriş|SONSÖZ|Sonsöz)\\b.{0,70}$|^[IVXLC]+\\.?\\s.{0,60}$|^\\d{1,3}\\.\\s?[A-ZÇĞİÖŞÜÂÎÛ].{0,60}$"
    )

    private fun isHeading(line: String): Boolean {
        val t = line.trim()
        if (t.length < 2 || t.length > 80) return false
        if (headingRe.matches(t)) return true
        val letters = t.count { it.isLetter() }
        return letters >= 3 && t.length <= 60 && t == t.uppercase(TR) && t.any { it.isLetter() && it.isUpperCase() } &&
            !t.endsWith(".") && !t.endsWith(",")
    }

    fun parseTxt(raw: String): BookText {
        val s = raw.replace("\r\n", "\n").replace('\r', '\n')
        val lines = s.split('\n')
        val blank = lines.count { it.isBlank() }
        val blocks: List<String> = (if (blank >= lines.size / 12) {
            // boş satırla ayrılmış paragraflar; paragraf içindeki satır sonları korunur (şiir için)
            s.split(Regex("\\n\\s*\\n")).map { b -> b.split('\n').joinToString("\n") { it.trim() }.trim() }
        } else {
            lines.map { it.trim() }
        }).filter { it.isNotEmpty() }

        val chapters = ArrayList<Chapter>()
        var cur = ArrayList<Para>()
        var title = ""
        for (b in blocks) {
            if (!b.contains('\n') && isHeading(b)) {
                if (cur.count { !it.heading } >= 2) {
                    chapters += Chapter(title.ifEmpty { "Bölüm ${chapters.size + 1}" }, cur)
                    cur = ArrayList()
                    title = ""
                }
                if (title.isEmpty()) title = b
                cur += Para(b, true)
            } else {
                // satırları birleştir: düz yazıda satır sonu boşluk olur, kısa satırlı şiirde kalır
                val ls = b.split('\n')
                val poem = ls.size > 1 && ls.all { it.length < 70 }
                cur += Para(if (poem) b else ls.joinToString(" "), false)
            }
        }
        if (cur.isNotEmpty()) chapters += Chapter(title.ifEmpty { "Bölüm ${chapters.size + 1}" }, cur)

        // hiç başlık yoksa uzun metni kısımlara böl
        if (chapters.size == 1 && chapters[0].paras.size > 80) {
            val all = chapters[0].paras
            chapters.clear()
            all.chunked(50).forEachIndexed { i, ps -> chapters += Chapter("Kısım ${i + 1}", ps) }
        }
        if (chapters.isEmpty()) throw ImportError("Dosyada okunabilir metin yok")
        return BookText(chapters)
    }

    private fun importTxt(ctx: Context, store: Store, uri: Uri, id: String, name: String): Book {
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw ImportError("Dosya açılamadı")
        val text = parseTxt(decode(bytes))
        store.saveText(id, text)
        val (title, author) = splitName(name)
        return Book(id, title, author, "txt", System.currentTimeMillis(), chapters = text.chapters.size, chars = text.chars)
    }

    // ---------- EPUB ----------

    private fun resolve(base: String, href: String): String {
        val clean = runCatching { URLDecoder.decode(href.substringBefore('#'), "UTF-8") }.getOrDefault(href.substringBefore('#'))
        val parts = (if (base.isEmpty()) clean else "$base/$clean").split('/')
        val out = ArrayList<String>()
        for (p in parts) {
            when (p) {
                "", "." -> {}
                ".." -> if (out.isNotEmpty()) out.removeAt(out.size - 1)
                else -> out.add(p)
            }
        }
        return out.joinToString("/")
    }

    private class Item(val id: String, val href: String, val type: String, val props: String) {
        val isImage: Boolean get() = type.startsWith("image/") || Regex("\\.(jpe?g|png|webp|gif)$", RegexOption.IGNORE_CASE).containsMatchIn(href)
    }

    private fun importEpub(ctx: Context, store: Store, uri: Uri, id: String, name: String): Book {
        val tmp = File(ctx.cacheDir, "in-$id.epub")
        copy(ctx, uri, tmp)
        try {
            return ZipFile(tmp).use { zip ->
                fun read(path: String): ByteArray? {
                    val e = zip.getEntry(path) ?: zip.entries().asSequence().firstOrNull { it.name.equals(path, true) } ?: return null
                    return zip.getInputStream(e).use { it.readBytes() }
                }
                fun text(path: String): String? = read(path)?.toString(Charsets.UTF_8)

                val container = text("META-INF/container.xml") ?: throw ImportError("EPUB dosyası bozuk görünüyor")
                val opfPath = Jsoup.parse(container, "", Parser.xmlParser())
                    .getElementsByTag("rootfile").firstOrNull()?.attr("full-path")
                    ?.takeIf { it.isNotBlank() } ?: throw ImportError("EPUB dosyası bozuk görünüyor")
                val opf = Jsoup.parse(text(opfPath) ?: throw ImportError("EPUB dosyası bozuk görünüyor"), "", Parser.xmlParser())
                val base = opfPath.substringBeforeLast('/', "")

                val items = opf.getElementsByTag("item").map {
                    Item(it.attr("id"), it.attr("href"), it.attr("media-type"), it.attr("properties"))
                }
                val byId = items.associateBy { it.id }
                val spine = opf.getElementsByTag("itemref").mapNotNull { byId[it.attr("idref")] }

                val chapters = ArrayList<Chapter>()
                for (item in spine) {
                    val isHtml = item.type.contains("html") || item.href.endsWith(".htm", true) ||
                        item.href.endsWith(".html", true) || item.href.endsWith(".xhtml", true)
                    if (!isHtml) continue
                    val html = text(resolve(base, item.href)) ?: continue
                    val doc = Jsoup.parse(html)
                    val body: Element = doc.body() ?: continue
                    val paras = HtmlText.extract(body)
                    if (paras.isEmpty()) continue
                    val t = paras.firstOrNull { it.heading }?.text
                        ?: doc.title().takeIf { it.isNotBlank() }
                        ?: "Bölüm ${chapters.size + 1}"
                    chapters += Chapter(t.replace('\n', ' ').take(90), paras)
                }
                if (chapters.isEmpty()) throw ImportError("Bu EPUB'da okunabilir metin bulunamadı")
                val bt = BookText(chapters)
                store.saveText(id, bt)

                // kapak: EPUB 3 "cover-image", EPUB 2 <meta name="cover">, ya da adında "cover" geçen resim
                val coverId = opf.getElementsByTag("meta").firstOrNull { it.attr("name") == "cover" }?.attr("content")
                val coverItem = items.firstOrNull { it.props.contains("cover-image") && it.isImage }
                    ?: coverId?.let { byId[it] }?.takeIf { it.isImage }
                    ?: items.firstOrNull { it.isImage && (it.id.contains("cover", true) || it.href.contains("cover", true) || it.href.contains("kapak", true)) }
                val hasCover = coverItem?.let { ci -> read(resolve(base, ci.href))?.let { saveCover(it, store.coverFile(id)) } } ?: false

                val title = opf.getElementsByTag("dc:title").firstOrNull()?.text()?.trim().orEmpty()
                val author = opf.getElementsByTag("dc:creator").firstOrNull()?.text()?.trim().orEmpty()
                val (fTitle, fAuthor) = splitName(name)
                Book(
                    id, title.ifEmpty { fTitle }, author.ifEmpty { fAuthor }, "epub", System.currentTimeMillis(),
                    chapters = chapters.size, chars = bt.chars, hasCover = hasCover,
                )
            }
        } finally {
            tmp.delete()
        }
    }

    fun saveCover(bytes: ByteArray, dest: File): Boolean {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            if (bounds.outWidth < 40 || bounds.outHeight < 40) return false
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 600) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return false
            FileOutputStream(dest).use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            bmp.recycle()
            true
        } catch (e: Exception) {
            false
        }
    }

    // ---------- PDF ----------

    private fun importPdf(ctx: Context, store: Store, uri: Uri, id: String, name: String): Book {
        val f = store.pdfFile(id)
        copy(ctx, uri, f)
        var pages = 0
        var hasCover = false
        try {
            val pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
            try {
                val r = PdfRenderer(pfd)
                try {
                    pages = r.pageCount
                    if (pages > 0) {
                        val page = r.openPage(0)
                        try {
                            val w = 420
                            val h = (w * page.height.toFloat() / page.width.coerceAtLeast(1)).toInt().coerceIn(200, 900)
                            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                            bmp.eraseColor(Color.WHITE)
                            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            FileOutputStream(store.coverFile(id)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 86, it) }
                            bmp.recycle()
                            hasCover = true
                        } finally {
                            page.close()
                        }
                    }
                } finally {
                    r.close()
                }
            } finally {
                pfd.close()
            }
        } catch (e: Exception) {
            f.delete()
            store.coverFile(id).delete()
            throw ImportError("Bu PDF açılamadı (şifreli ya da bozuk olabilir)")
        }
        if (pages == 0) {
            f.delete()
            throw ImportError("Bu PDF'te sayfa yok")
        }
        val (title, author) = splitName(name)
        return Book(id, title, author, "pdf", System.currentTimeMillis(), pages = pages, hasCover = hasCover)
    }

    // ---------- SES ----------

    suspend fun importAudio(ctx: Context, store: Store, uri: Uri): Pod = withContext(Dispatchers.IO) {
        val name = displayName(ctx, uri)
        val ext = name.substringAfterLast('.', "mp3").lowercase(TR).filter { it.isLetterOrDigit() }.take(5).ifEmpty { "mp3" }
        val id = newId("p")
        val f = File(store.audioDir, "$id.$ext")
        copy(ctx, uri, f)
        val mmr = MediaMetadataRetriever()
        var title: String? = null
        var artist: String? = null
        var dur = 0L
        var pic: ByteArray? = null
        try {
            mmr.setDataSource(f.absolutePath)
            title = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
            artist = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                ?: mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST)
                ?: mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)
            dur = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val hasAudio = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)
            if (hasAudio != "yes" && dur <= 0L) throw ImportError("“$name” ses dosyası değil")
            pic = mmr.embeddedPicture
        } catch (e: ImportError) {
            f.delete()
            throw e
        } catch (e: Exception) {
            f.delete()
            throw ImportError("“$name” okunamadı; bu ses biçimi desteklenmiyor olabilir")
        } finally {
            runCatching { mmr.release() }
        }
        val hasCover = pic?.let { saveCover(it, store.coverFile(id)) } ?: false
        val (fTitle, fArtist) = splitName(name)
        Pod(
            id = id,
            title = title?.trim().takeUnless { it.isNullOrEmpty() } ?: fTitle,
            artist = artist?.trim().takeUnless { it.isNullOrEmpty() } ?: fArtist,
            durationMs = dur,
            file = f.name,
            added = System.currentTimeMillis(),
            hasCover = hasCover,
        )
    }
}

/** HTML gövdesinden paragrafları sırasıyla çıkarır; <br> satır sonu olarak korunur. */
object HtmlText {
    private val BLOCK = setOf(
        "p", "div", "h1", "h2", "h3", "h4", "h5", "h6", "li", "blockquote", "pre", "section", "article",
        "td", "th", "dd", "dt", "tr", "table", "ul", "ol", "header", "footer", "aside", "figure",
        "figcaption", "center", "dl", "nav", "main", "hr",
    )
    private val SKIP = setOf("script", "style", "head", "title", "svg", "math", "img", "sup")
    private val spaces = Regex("[ \\t\\u00A0\\u2007\\u202F]+")

    fun extract(root: Element): List<Para> {
        val out = ArrayList<Para>()
        val buf = StringBuilder()

        fun flush(heading: Boolean) {
            val t = buf.toString().replace(spaces, " ").split('\n').map { it.trim() }.filter { it.isNotEmpty() }.joinToString("\n")
            buf.setLength(0)
            if (t.isNotEmpty()) out += Para(t, heading && t.length <= 160)
        }

        fun walk(node: Node, heading: Boolean) {
            when (node) {
                is TextNode -> buf.append(node.wholeText.replace('\n', ' ').replace('\r', ' '))
                is Element -> {
                    val tag = node.normalName()
                    if (tag in SKIP) return
                    if (tag == "br") {
                        buf.append('\n')
                        return
                    }
                    val isH = tag.length == 2 && tag[0] == 'h' && tag[1] in '1'..'6'
                    val h = heading || isH
                    val block = tag in BLOCK
                    if (block) flush(false)
                    for (c in node.childNodes()) walk(c, h)
                    if (block) flush(h)
                }
                else -> {}
            }
        }

        walk(root, false)
        flush(false)
        return out
    }
}
